/**
 * SIH26118 – Passive Colorimetric H2S Exposure-Dosimeter Wristband
 * Global Type Definitions
 */

export type ShiftType = 'Morning' | 'Afternoon' | 'Night';

export type RiskLevel = 'LOW' | 'MODERATE' | 'HIGH';

export type BadgeValidity = 'VALID' | 'NEAR_EXPIRY' | 'EXPIRED' | 'UNDETERMINED';

export type ImageQuality = 'GOOD' | 'MODERATE' | 'POOR';

export interface CalibrationPoint {
  colorIndex: number; // 0.0 to 1.0 (darkening / delta E metric)
  dose: number; // ppm·h cumulative exposure
}

export interface ReferenceColorTarget {
  id: string;
  name: string;
  expectedRgb: [number, number, number];
  hex: string;
  description: string;
}

export interface DetectedColorPatch {
  name: string;
  expectedRgb: [number, number, number];
  measuredRgb: [number, number, number];
  normalizedRgb: [number, number, number];
  hex: string;
  deltaE: number;
}

export interface SensingStripAnalysis {
  rawRgb: [number, number, number];
  normalizedRgb: [number, number, number];
  hex: string;
  hsv: [number, number, number]; // [H 0-360, S 0-1, V 0-1]
  lab: [number, number, number]; // [L*, a*, b*]
  deltaEFromBaseline: number;
  absorbanceRatio: number;
}

export interface LightingCorrectionResult {
  rGain: number;
  gGain: number;
  bGain: number;
  ambientLuxProxy: number;
  uniformityScore: number; // 0-100
  colorTemperatureEstimate: number; // in Kelvin approx (e.g. 5500K)
}

export interface ColorimetricAnalysis {
  colorIndex: number; // 0.0 to 1.0
  estimatedDose: number; // in ppm·h
  confidence: number; // 0 to 100%
  imageQuality: ImageQuality;
  qualityScore: number; // 0 to 100
  qualityIssues: string[];
  riskLevel: RiskLevel;
  badgeValidity: BadgeValidity;
  badgeShelfLifeDaysRemaining?: number;
  
  // Detailed Spectral Data
  detectedPatches: DetectedColorPatch[];
  sensingStrip: SensingStripAnalysis;
  expiryPatch: {
    rawRgb: [number, number, number];
    normalizedRgb: [number, number, number];
    status: BadgeValidity;
    colorScore: number;
  };
  lightingCorrection: LightingCorrectionResult;
  
  // Environmental compensation
  envCompensationApplied: boolean;
  temperature?: number; // °C
  humidity?: number; // % RH
  tempCorrectionFactor: number;
  humidityCorrectionFactor: number;

  // Metadata
  engineUsed: 'CANVAS_CV_HYBRID' | 'GEMINI_VISION_AI';
  timestamp: string;
  rawFeaturesSummary?: string;
}

export interface ExposureScanRecord {
  id: string;
  workerId: string;
  workerName: string;
  department: string;
  shift: ShiftType;
  timestamp: string;
  estimatedDose: number; // ppm·h
  riskLevel: RiskLevel;
  confidence: number; // percentage
  badgeValidity: BadgeValidity;
  imageQuality: ImageQuality;
  temperature?: number;
  humidity?: number;
  imageDataUrl?: string; // thumbnail / canvas snapshot
  isDemo: boolean;
  notes?: string;
  analysisDetails?: ColorimetricAnalysis;
}

export interface WorkerProfile {
  id: string;
  name: string;
  department: string;
  role: string;
  shift: ShiftType;
  assignedBadgeId: string;
  badgeActivationDate: string;
  shelfLifeDays: number;
  totalScans: number;
  cumulativeExposurePpmH: number;
  lastScanDate?: string;
  status: 'ACTIVE' | 'ON_LEAVE' | 'RESTRICTED';
}

export interface AdminCalibrationConfig {
  calibrationPoints: CalibrationPoint[];
  referenceColors: ReferenceColorTarget[];
  riskThresholds: {
    lowMax: number; // default e.g. 10 ppm·h
    moderateMax: number; // default e.g. 25 ppm·h
  };
  defaultShelfLifeDays: number;
  tempCoefficient: number; // diffusion rate change per degree C
  humidityCoefficient: number; // relative humidity impact factor
  baseReferenceTemp: number; // standard 25 °C
  baseReferenceHumidity: number; // standard 50 % RH
  enableGeminiVerification: boolean;
  version: string;
  lastUpdated: string;
}

export type ActiveTab = 'home' | 'scan' | 'history' | 'dashboard' | 'workers' | 'calibration' | 'about';
