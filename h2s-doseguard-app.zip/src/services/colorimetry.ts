/**
 * Colorimetry Mathematics & Optical Space Conversions
 * Implements sRGB, HSV, CIE XYZ, CIE L*a*b*, and CIEDE2000 color difference
 */

export function clamp(value: number, min: number, max: number): number {
  return Math.min(Math.max(value, min), max);
}

export function rgbToHex(r: number, g: number, b: number): string {
  const toHex = (n: number) => {
    const clamped = Math.round(clamp(n, 0, 255));
    return clamped.toString(16).padStart(2, '0');
  };
  return `#${toHex(r)}${toHex(g)}${toHex(b)}`.toUpperCase();
}

export function hexToRgb(hex: string): [number, number, number] {
  let clean = hex.replace('#', '');
  if (clean.length === 3) {
    clean = clean.split('').map(c => c + c).join('');
  }
  const num = parseInt(clean, 16);
  return [(num >> 16) & 255, (num >> 8) & 255, num & 255];
}

/**
 * Converts RGB [0-255] to HSV [H: 0-360, S: 0-1, V: 0-1]
 */
export function rgbToHsv(r: number, g: number, b: number): [number, number, number] {
  const rNorm = r / 255;
  const gNorm = g / 255;
  const bNorm = b / 255;

  const max = Math.max(rNorm, gNorm, bNorm);
  const min = Math.min(rNorm, gNorm, bNorm);
  const diff = max - min;

  let h = 0;
  if (diff !== 0) {
    if (max === rNorm) {
      h = ((gNorm - bNorm) / diff) % 6;
    } else if (max === gNorm) {
      h = (bNorm - rNorm) / diff + 2;
    } else {
      h = (rNorm - gNorm) / diff + 4;
    }
    h = Math.round(h * 60);
    if (h < 0) h += 360;
  }

  const s = max === 0 ? 0 : diff / max;
  const v = max;

  return [h, parseFloat(s.toFixed(4)), parseFloat(v.toFixed(4))];
}

/**
 * Gamma correction for sRGB to linear RGB
 */
function srgbToLinear(c: number): number {
  const norm = c / 255;
  return norm <= 0.04045 ? norm / 12.92 : Math.pow((norm + 0.055) / 1.055, 2.4);
}

/**
 * Converts sRGB [0-255] to CIE XYZ (under D65 standard illuminant, 2-degree observer)
 */
export function rgbToXyz(r: number, g: number, b: number): [number, number, number] {
  const lr = srgbToLinear(r);
  const lg = srgbToLinear(g);
  const lb = srgbToLinear(b);

  // sRGB D65 matrix
  const x = lr * 0.4124564 + lg * 0.3575761 + lb * 0.1804375;
  const y = lr * 0.2126729 + lg * 0.7151522 + lb * 0.0721750;
  const z = lr * 0.0193339 + lg * 0.1191920 + lb * 0.9503041;

  return [x * 100, y * 100, z * 100];
}

/**
 * Converts CIE XYZ to CIE L*a*b*
 */
export function xyzToLab(x: number, y: number, z: number): [number, number, number] {
  // D65 Reference White
  const refX = 95.047;
  const refY = 100.000;
  const refZ = 108.883;

  const f = (t: number) => {
    const delta = 6 / 29;
    return t > Math.pow(delta, 3) ? Math.cbrt(t) : t / (3 * Math.pow(delta, 2)) + 4 / 29;
  };

  const fx = f(x / refX);
  const fy = f(y / refY);
  const fz = f(z / refZ);

  const L = 116 * fy - 16;
  const a = 500 * (fx - fy);
  const b = 200 * (fy - fz);

  return [parseFloat(L.toFixed(2)), parseFloat(a.toFixed(2)), parseFloat(b.toFixed(2))];
}

export function rgbToLab(r: number, g: number, b: number): [number, number, number] {
  const [x, y, z] = rgbToXyz(r, g, b);
  return xyzToLab(x, y, z);
}

/**
 * Standard CIE76 Delta E (Euclidean distance in Lab space)
 */
export function deltaE76(lab1: [number, number, number], lab2: [number, number, number]): number {
  const dL = lab1[0] - lab2[0];
  const da = lab1[1] - lab2[1];
  const db = lab1[2] - lab2[2];
  return Math.sqrt(dL * dL + da * da + db * db);
}

/**
 * Standard CIEDE2000 Color Difference Formula for accurate human perception
 */
export function deltaE2000(lab1: [number, number, number], lab2: [number, number, number]): number {
  const [L1, a1, b1] = lab1;
  const [L2, a2, b2] = lab2;

  const avgL = (L1 + L2) / 2;
  const C1 = Math.sqrt(a1 * a1 + b1 * b1);
  const C2 = Math.sqrt(a2 * a2 + b2 * b2);
  const avgC = (C1 + C2) / 2;

  const G = 0.5 * (1 - Math.sqrt(Math.pow(avgC, 7) / (Math.pow(avgC, 7) + Math.pow(25, 7))));

  const a1Prime = (1 + G) * a1;
  const a2Prime = (1 + G) * a2;

  const C1Prime = Math.sqrt(a1Prime * a1Prime + b1 * b1);
  const C2Prime = Math.sqrt(a2Prime * a2Prime + b2 * b2);
  const avgCPrime = (C1Prime + C2Prime) / 2;

  const radToDeg = (rad: number) => (rad * 180) / Math.PI;
  const degToRad = (deg: number) => (deg * Math.PI) / 180;

  let h1Prime = radToDeg(Math.atan2(b1, a1Prime));
  if (h1Prime < 0) h1Prime += 360;

  let h2Prime = radToDeg(Math.atan2(b2, a2Prime));
  if (h2Prime < 0) h2Prime += 360;

  let dhPrime = 0;
  if (C1Prime * C2Prime !== 0) {
    if (Math.abs(h1Prime - h2Prime) <= 180) {
      dhPrime = h2Prime - h1Prime;
    } else if (h2Prime <= h1Prime) {
      dhPrime = h2Prime - h1Prime + 360;
    } else {
      dhPrime = h2Prime - h1Prime - 360;
    }
  }

  let avgHPrime = 0;
  if (C1Prime * C2Prime !== 0) {
    if (Math.abs(h1Prime - h2Prime) <= 180) {
      avgHPrime = (h1Prime + h2Prime) / 2;
    } else if (h1Prime + h2Prime < 360) {
      avgHPrime = (h1Prime + h2Prime + 360) / 2;
    } else {
      avgHPrime = (h1Prime + h2Prime - 360) / 2;
    }
  } else {
    avgHPrime = h1Prime + h2Prime;
  }

  const dLPrime = L2 - L1;
  const dCPrime = C2Prime - C1Prime;
  const dHPrime = 2 * Math.sqrt(C1Prime * C2Prime) * Math.sin(degToRad(dhPrime / 2));

  const T =
    1 -
    0.17 * Math.cos(degToRad(avgHPrime - 30)) +
    0.24 * Math.cos(degToRad(2 * avgHPrime)) +
    0.32 * Math.cos(degToRad(3 * avgHPrime + 6)) -
    0.20 * Math.cos(degToRad(4 * avgHPrime - 63));

  const SL = 1 + (0.015 * Math.pow(avgL - 50, 2)) / Math.sqrt(20 + Math.pow(avgL - 50, 2));
  const SC = 1 + 0.045 * avgCPrime;
  const SH = 1 + 0.015 * avgCPrime * T;

  const dTheta = 30 * Math.exp(-Math.pow((avgHPrime - 275) / 25, 2));
  const RC = 2 * Math.sqrt(Math.pow(avgCPrime, 7) / (Math.pow(avgCPrime, 7) + Math.pow(25, 7)));
  const RT = -Math.sin(degToRad(2 * dTheta)) * RC;

  const kL = 1;
  const kC = 1;
  const kH = 1;

  const deltaE = Math.sqrt(
    Math.pow(dLPrime / (kL * SL), 2) +
    Math.pow(dCPrime / (kC * SC), 2) +
    Math.pow(dHPrime / (kH * SH), 2) +
    RT * (dCPrime / (kC * SC)) * (dHPrime / (kH * SH))
  );

  return parseFloat(deltaE.toFixed(2));
}

/**
 * Lighting correction & Color balance using Von Kries diagonal matrix transform
 */
export function applyVonKriesCorrection(
  targetRgb: [number, number, number],
  measuredWhite: [number, number, number],
  targetWhite: [number, number, number] = [240, 240, 240]
): [number, number, number] {
  // Avoid division by zero
  const mwR = Math.max(measuredWhite[0], 10);
  const mwG = Math.max(measuredWhite[1], 10);
  const mwB = Math.max(measuredWhite[2], 10);

  const gainR = targetWhite[0] / mwR;
  const gainG = targetWhite[1] / mwG;
  const gainB = targetWhite[2] / mwB;

  const correctedR = clamp(targetRgb[0] * gainR, 0, 255);
  const correctedG = clamp(targetRgb[1] * gainG, 0, 255);
  const correctedB = clamp(targetRgb[2] * gainB, 0, 255);

  return [Math.round(correctedR), Math.round(correctedG), Math.round(correctedB)];
}
