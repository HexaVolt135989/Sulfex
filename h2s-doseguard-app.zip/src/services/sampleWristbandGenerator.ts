/**
 * Sample Dosimeter Wristband Generator
 * Renders standardized realistic passive colorimetric dosimeter wristband images onto canvas.
 */

export interface SampleBadgeSpec {
  id: string;
  name: string;
  badgeCode: string;
  dosePpmH: number; // nominal simulated dose
  stripColorRgb: [number, number, number];
  expiryStatus: 'VALID' | 'EXPIRED' | 'NEAR_EXPIRY';
  expiryColorRgb: [number, number, number];
  description: string;
  lightingArtifact?: 'normal' | 'low_light' | 'glare';
}

export const SAMPLE_BADGES: SampleBadgeSpec[] = [
  {
    id: 'sample_fresh_0',
    name: '0.0 ppm·h — Baseline (Unexposed)',
    badgeCode: 'BDG-2026-001',
    dosePpmH: 0.0,
    stripColorRgb: [246, 240, 218], // Pale cream/yellow baseline
    expiryStatus: 'VALID',
    expiryColorRgb: [34, 197, 94], // Active Emerald
    description: 'Pristine chemical dosimeter prior to hazardous atmosphere entry.',
    lightingArtifact: 'normal',
  },
  {
    id: 'sample_low_5',
    name: '4.8 ppm·h — Low Exposure (Safe)',
    badgeCode: 'BDG-2026-042',
    dosePpmH: 4.8,
    stripColorRgb: [214, 192, 142], // Light tan
    expiryStatus: 'VALID',
    expiryColorRgb: [34, 197, 94],
    description: 'Minor background H2S presence below typical 8-hr shift TWA action level.',
    lightingArtifact: 'normal',
  },
  {
    id: 'sample_mod_14',
    name: '13.5 ppm·h — Moderate Exposure',
    badgeCode: 'BDG-2026-109',
    dosePpmH: 13.5,
    stripColorRgb: [156, 118, 72], // Amber brown PbS formation
    expiryStatus: 'VALID',
    expiryColorRgb: [34, 197, 94],
    description: 'Approaching industrial safety threshold. Investigation recommended.',
    lightingArtifact: 'normal',
  },
  {
    id: 'sample_high_32',
    name: '32.0 ppm·h — High Exposure (Alert)',
    badgeCode: 'BDG-2026-218',
    dosePpmH: 32.0,
    stripColorRgb: [82, 54, 32], // Dark walnut brown
    expiryStatus: 'VALID',
    expiryColorRgb: [34, 197, 94],
    description: 'Exceeds prototype safety limits. High cumulative H2S exposure alert.',
    lightingArtifact: 'normal',
  },
  {
    id: 'sample_crit_60',
    name: '64.0 ppm·h — Critical Saturated',
    badgeCode: 'BDG-2026-301',
    dosePpmH: 64.0,
    stripColorRgb: [30, 24, 20], // Near pitch black PbS precipitate
    expiryStatus: 'VALID',
    expiryColorRgb: [34, 197, 94],
    description: 'Dense lead sulfide saturation. Severe industrial exposure event.',
    lightingArtifact: 'normal',
  },
  {
    id: 'sample_expired',
    name: 'Expired Badge — Shelf Life End',
    badgeCode: 'BDG-2026-EXP',
    dosePpmH: 2.5,
    stripColorRgb: [230, 215, 175],
    expiryStatus: 'EXPIRED',
    expiryColorRgb: [239, 68, 68], // Pinkish red degraded expiry patch
    description: 'Expiry indicator patch degraded. Badge must be replaced immediately.',
    lightingArtifact: 'normal',
  },
  {
    id: 'sample_low_light',
    name: 'Challenging Low-Light Capture',
    badgeCode: 'BDG-2026-LL4',
    dosePpmH: 18.0,
    stripColorRgb: [90, 65, 40],
    expiryStatus: 'VALID',
    expiryColorRgb: [20, 140, 60],
    description: 'Simulates evening shift poor plant illumination and shadow falloff.',
    lightingArtifact: 'low_light',
  },
];

/**
 * Draws a photorealistic dosimeter wristband onto a target canvas
 */
export function drawDosimeterBadge(
  ctx: CanvasRenderingContext2D,
  width: number,
  height: number,
  spec: SampleBadgeSpec
): void {
  // Clear canvas
  ctx.clearRect(0, 0, width, height);

  // Background industrial table/bench surface
  const bgGrad = ctx.createLinearGradient(0, 0, width, height);
  if (spec.lightingArtifact === 'low_light') {
    bgGrad.addColorStop(0, '#111827');
    bgGrad.addColorStop(1, '#0b0f17');
  } else {
    bgGrad.addColorStop(0, '#1e293b');
    bgGrad.addColorStop(1, '#0f172a');
  }
  ctx.fillStyle = bgGrad;
  ctx.fillRect(0, 0, width, height);

  // Draw wristband strap (silicone industrial band)
  const bandMarginX = width * 0.06;
  const bandMarginY = height * 0.08;
  const bandW = width - bandMarginX * 2;
  const bandH = height - bandMarginY * 2;

  // Band shadow
  ctx.fillStyle = 'rgba(0, 0, 0, 0.5)';
  ctx.beginPath();
  ctx.roundRect(bandMarginX + 6, bandMarginY + 8, bandW, bandH, 18);
  ctx.fill();

  // Band body (High-visibility Safety Charcoal / Orange Accent)
  const strapGrad = ctx.createLinearGradient(bandMarginX, 0, bandMarginX + bandW, 0);
  strapGrad.addColorStop(0, '#1c1917');
  strapGrad.addColorStop(0.5, '#292524');
  strapGrad.addColorStop(1, '#1c1917');
  ctx.fillStyle = strapGrad;
  ctx.beginPath();
  ctx.roundRect(bandMarginX, bandMarginY, bandW, bandH, 16);
  ctx.fill();

  // Band border
  ctx.strokeStyle = '#f97316'; // Safety orange border
  ctx.lineWidth = 2.5;
  ctx.stroke();

  // White Card / Dosimeter Badge Faceplate
  const badgeX = width * 0.12;
  const badgeY = height * 0.12;
  const badgeW = width * 0.76;
  const badgeH = height * 0.76;

  // Faceplate background
  ctx.fillStyle = '#FFFFFF';
  ctx.beginPath();
  ctx.roundRect(badgeX, badgeY, badgeW, badgeH, 10);
  ctx.fill();
  ctx.strokeStyle = '#cbd5e1';
  ctx.lineWidth = 1.5;
  ctx.stroke();

  // --- Header Area ---
  // Industrial Branding Banner
  ctx.fillStyle = '#0f172a';
  ctx.fillRect(badgeX, badgeY, badgeW, badgeH * 0.14);

  ctx.fillStyle = '#f97316';
  ctx.font = `bold ${Math.round(badgeH * 0.065)}px sans-serif`;
  ctx.textAlign = 'left';
  ctx.fillText('SULFEX H2S', badgeX + badgeW * 0.05, badgeY + badgeH * 0.095);

  ctx.fillStyle = '#94a3b8';
  ctx.font = `${Math.round(badgeH * 0.04)}px monospace`;
  ctx.textAlign = 'right';
  ctx.fillText(spec.badgeCode, badgeX + badgeW * 0.95, badgeY + badgeH * 0.095);

  // --- 1. Chemical Sensing Strip (Top ROI) ---
  const stripX = badgeX + badgeW * 0.12;
  const stripY = badgeY + badgeH * 0.20;
  const stripW = badgeW * 0.76;
  const stripH = badgeH * 0.32;

  // Strip recessed housing
  ctx.fillStyle = '#f1f5f9';
  ctx.beginPath();
  ctx.roundRect(stripX - 4, stripY - 4, stripW + 8, stripH + 8, 6);
  ctx.fill();
  ctx.strokeStyle = '#94a3b8';
  ctx.lineWidth = 1;
  ctx.stroke();

  // Chemical Substrate Strip
  const [sR, sG, sB] = spec.stripColorRgb;
  const stripGrad = ctx.createLinearGradient(stripX, stripY, stripX, stripY + stripH);
  stripGrad.addColorStop(0, `rgb(${sR}, ${sG}, ${sB})`);
  // Slight natural chemical reaction gradient
  stripGrad.addColorStop(1, `rgb(${Math.max(0, sR - 8)}, ${Math.max(0, sG - 8)}, ${Math.max(0, sB - 8)})`);
  ctx.fillStyle = stripGrad;
  ctx.fillRect(stripX, stripY, stripW, stripH);

  // Subtle porous matrix texture
  ctx.strokeStyle = 'rgba(0,0,0,0.05)';
  for (let i = stripX; i < stripX + stripW; i += 8) {
    ctx.beginPath();
    ctx.moveTo(i, stripY);
    ctx.lineTo(i, stripY + stripH);
    ctx.stroke();
  }

  // Label above strip
  ctx.fillStyle = '#475569';
  ctx.font = `600 ${Math.round(badgeH * 0.038)}px sans-serif`;
  ctx.textAlign = 'left';
  ctx.fillText('H2S SENSING REAGENT [LEAD ACETATE MATRIX]', stripX, stripY - 8);

  // --- 2. Printed Reference Scale (Middle ROI) ---
  const refY = badgeY + badgeH * 0.60;
  const refX = badgeX + badgeW * 0.06;
  const refW = badgeW * 0.88;
  const refH = badgeH * 0.16;

  ctx.fillStyle = '#334155';
  ctx.font = `bold ${Math.round(badgeH * 0.034)}px sans-serif`;
  ctx.fillText('CALIBRATION REFERENCE SCALE', refX, refY - 4);

  const patches = [
    { color: '#F0F0F0', label: 'W' },
    { color: '#00A0DC', label: 'C' },
    { color: '#DC1E78', label: 'M' },
    { color: '#FAD200', label: 'Y' },
    { color: '#191919', label: 'K' },
  ];

  const patchW = (refW - (patches.length - 1) * 4) / patches.length;
  patches.forEach((p, idx) => {
    const px = refX + idx * (patchW + 4);
    ctx.fillStyle = p.color;
    ctx.fillRect(px, refY, patchW, refH);
    ctx.strokeStyle = '#64748b';
    ctx.lineWidth = 1;
    ctx.strokeRect(px, refY, patchW, refH);

    // Label inside patch
    ctx.fillStyle = idx === 0 || idx === 3 ? '#000000' : '#FFFFFF';
    ctx.font = `bold ${Math.round(refH * 0.4)}px sans-serif`;
    ctx.textAlign = 'center';
    ctx.fillText(p.label, px + patchW / 2, refY + refH * 0.65);
  });

  // --- 3. Expiry / Shelf-Life Patch (Bottom Right ROI) ---
  const expiryX = badgeX + badgeW * 0.68;
  const expiryY = badgeY + badgeH * 0.82;
  const expiryW = badgeW * 0.26;
  const expiryH = badgeH * 0.13;

  ctx.fillStyle = '#475569';
  ctx.font = `600 ${Math.round(badgeH * 0.032)}px sans-serif`;
  ctx.textAlign = 'right';
  ctx.fillText('SHELF-LIFE:', expiryX - 6, expiryY + expiryH * 0.65);

  const [eR, eG, eB] = spec.expiryColorRgb;
  ctx.fillStyle = `rgb(${eR}, ${eG}, ${eB})`;
  ctx.beginPath();
  ctx.roundRect(expiryX, expiryY, expiryW, expiryH, 4);
  ctx.fill();
  ctx.strokeStyle = '#0f172a';
  ctx.lineWidth = 1.5;
  ctx.stroke();

  ctx.fillStyle = '#FFFFFF';
  ctx.font = `bold ${Math.round(expiryH * 0.5)}px sans-serif`;
  ctx.textAlign = 'center';
  ctx.fillText(spec.expiryStatus === 'EXPIRED' ? 'EXP' : 'OK', expiryX + expiryW / 2, expiryY + expiryH * 0.68);

  // Serial barcode lines at bottom left
  const barX = badgeX + badgeW * 0.06;
  const barY = badgeY + badgeH * 0.83;
  ctx.fillStyle = '#0f172a';
  for (let i = 0; i < 28; i++) {
    const bw = i % 3 === 0 ? 3 : 1.5;
    ctx.fillRect(barX + i * 4, barY, bw, badgeH * 0.11);
  }

  // --- Simulated Lighting Artifacts ---
  if (spec.lightingArtifact === 'low_light') {
    ctx.fillStyle = 'rgba(10, 15, 30, 0.45)';
    ctx.fillRect(0, 0, width, height);
  } else if (spec.lightingArtifact === 'glare') {
    const glare = ctx.createRadialGradient(width * 0.4, height * 0.35, 10, width * 0.4, height * 0.35, width * 0.4);
    glare.addColorStop(0, 'rgba(255, 255, 255, 0.5)');
    glare.addColorStop(1, 'rgba(255, 255, 255, 0)');
    ctx.fillStyle = glare;
    ctx.fillRect(0, 0, width, height);
  }
}

/**
 * Generates a data URL for a given sample badge specification
 */
export function generateSampleBadgeDataUrl(spec: SampleBadgeSpec, width = 640, height = 480): string {
  const canvas = document.createElement('canvas');
  canvas.width = width;
  canvas.height = height;
  const ctx = canvas.getContext('2d');
  if (!ctx) return '';
  drawDosimeterBadge(ctx, width, height, spec);
  return canvas.toDataURL('image/jpeg', 0.95);
}
