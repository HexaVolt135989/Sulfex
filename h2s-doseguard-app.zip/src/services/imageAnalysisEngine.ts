/**
 * SIH26118 – Passive Colorimetric H2S Dosimeter Image Analysis Engine
 * Modular Computer Vision & Photometric Calibration Pipeline
 */

import {
  ColorimetricAnalysis,
  DetectedColorPatch,
  ImageQuality,
  LightingCorrectionResult,
  ReferenceColorTarget,
  RiskLevel,
  BadgeValidity,
  AdminCalibrationConfig,
} from '../types';
import {
  applyVonKriesCorrection,
  clamp,
  deltaE2000,
  rgbToHex,
  rgbToHsv,
  rgbToLab,
} from './colorimetry';

export interface AnalysisOptions {
  config: AdminCalibrationConfig;
  workerId?: string;
  shift?: string;
  temperature?: number; // in °C
  humidity?: number; // in %
  cropRegion?: { x: number; y: number; width: number; height: number }; // normalized 0-1
}

/**
 * Standard 5-patch reference color palette expected on dosimeter wristband
 */
export const DEFAULT_REFERENCE_TARGETS: ReferenceColorTarget[] = [
  { id: 'ref_white', name: 'Ref White', expectedRgb: [240, 240, 240], hex: '#F0F0F0', description: 'Diffusive white target' },
  { id: 'ref_cyan', name: 'Ref Cyan', expectedRgb: [0, 160, 220], hex: '#00A0DC', description: 'Primary cyan calibration patch' },
  { id: 'ref_magenta', name: 'Ref Magenta', expectedRgb: [220, 30, 120], hex: '#DC1E78', description: 'Primary magenta calibration patch' },
  { id: 'ref_yellow', name: 'Ref Yellow', expectedRgb: [250, 210, 0], hex: '#FAD200', description: 'Primary yellow calibration patch' },
  { id: 'ref_black', name: 'Ref Black', expectedRgb: [25, 25, 25], hex: '#191919', description: 'Deep black target' },
];

/**
 * Extracts average RGB from a specified region of an ImageData buffer
 * Includes optional robust outlier rejection (filters out printed text letters or glare)
 */
export function getAverageRgbFromRegion(
  ctx: CanvasRenderingContext2D,
  x: number,
  y: number,
  w: number,
  h: number,
  rejectOutliers = true
): [number, number, number] {
  const clampX = Math.floor(clamp(x, 0, ctx.canvas.width - 1));
  const clampY = Math.floor(clamp(y, 0, ctx.canvas.height - 1));
  const clampW = Math.max(1, Math.min(Math.floor(w), ctx.canvas.width - clampX));
  const clampH = Math.max(1, Math.min(Math.floor(h), ctx.canvas.height - clampY));

  const imgData = ctx.getImageData(clampX, clampY, clampW, clampH);
  const data = imgData.data;
  const pixelCount = clampW * clampH;

  if (pixelCount === 0) return [128, 128, 128];

  if (!rejectOutliers || pixelCount < 16) {
    let totalR = 0;
    let totalG = 0;
    let totalB = 0;
    for (let i = 0; i < data.length; i += 4) {
      totalR += data[i];
      totalG += data[i + 1];
      totalB += data[i + 2];
    }
    return [
      Math.round(totalR / pixelCount),
      Math.round(totalG / pixelCount),
      Math.round(totalB / pixelCount),
    ];
  }

  // Robust pixel sampling: compute median luminance and reject outliers (e.g. black/white printed labels)
  const lums: number[] = [];
  for (let i = 0; i < data.length; i += 4) {
    const lum = 0.299 * data[i] + 0.587 * data[i + 1] + 0.114 * data[i + 2];
    lums.push(lum);
  }
  const sortedLums = [...lums].sort((a, b) => a - b);
  const medianLum = sortedLums[Math.floor(sortedLums.length / 2)];
  const lumTolerance = Math.max(22, medianLum * 0.28);

  let filteredR = 0;
  let filteredG = 0;
  let filteredB = 0;
  let validCount = 0;

  for (let i = 0; i < data.length; i += 4) {
    const lum = lums[i / 4];
    if (Math.abs(lum - medianLum) <= lumTolerance) {
      filteredR += data[i];
      filteredG += data[i + 1];
      filteredB += data[i + 2];
      validCount++;
    }
  }

  if (validCount === 0) {
    return [
      Math.round(data[0]),
      Math.round(data[1]),
      Math.round(data[2]),
    ];
  }

  return [
    Math.round(filteredR / validCount),
    Math.round(filteredG / validCount),
    Math.round(filteredB / validCount),
  ];
}

/**
 * Computes image sharpness proxy using gradient difference (Laplacian variance approximation)
 */
export function calculateSharpnessScore(ctx: CanvasRenderingContext2D): number {
  const w = ctx.canvas.width;
  const h = ctx.canvas.height;
  const sampleW = Math.min(160, w);
  const sampleH = Math.min(120, h);

  const imgData = ctx.getImageData(
    Math.floor((w - sampleW) / 2),
    Math.floor((h - sampleH) / 2),
    sampleW,
    sampleH
  );
  const data = imgData.data;

  let variance = 0;
  let prevLum = 0;

  for (let i = 0; i < data.length; i += 4) {
    const lum = 0.299 * data[i] + 0.587 * data[i + 1] + 0.114 * data[i + 2];
    if (i > 0) {
      variance += Math.abs(lum - prevLum);
    }
    prevLum = lum;
  }

  const normalizedSharpness = clamp((variance / (sampleW * sampleH)) * 4, 10, 100);
  return Math.round(normalizedSharpness);
}

/**
 * Validates optical quality of wristband capture
 */
export function validateImageQuality(
  ctx: CanvasRenderingContext2D,
  lightingResult: LightingCorrectionResult
): { quality: ImageQuality; score: number; issues: string[] } {
  const issues: string[] = [];
  const sharpness = calculateSharpnessScore(ctx);

  const avgBrightness = lightingResult.ambientLuxProxy;
  let score = 100;

  if (avgBrightness < 45) {
    issues.push('Low ambient lighting detected. May cause color calibration drift.');
    score -= 30;
  } else if (avgBrightness > 225) {
    issues.push('Excessive brightness or specular glare on badge surface.');
    score -= 25;
  }

  if (sharpness < 25) {
    issues.push('Image appears blurry. Hold camera steady.');
    score -= 30;
  }

  if (lightingResult.uniformityScore < 50) {
    issues.push('Uneven lighting across reference scale (shadows detected).');
    score -= 20;
  }

  score = clamp(score, 10, 100);

  let quality: ImageQuality = 'GOOD';
  if (score < 50) {
    quality = 'POOR';
  } else if (score < 75) {
    quality = 'MODERATE';
  }

  return { quality, score, issues };
}

/**
 * Detects reference color patches across the printed reference bar
 */
export function detectReferenceColors(
  ctx: CanvasRenderingContext2D,
  targetPalette: ReferenceColorTarget[],
  bounds: { x: number; y: number; width: number; height: number }
): DetectedColorPatch[] {
  const detected: DetectedColorPatch[] = [];
  const patchCount = targetPalette.length;
  const patchW = bounds.width / patchCount;

  for (let i = 0; i < patchCount; i++) {
    const patchX = bounds.x + i * patchW + patchW * 0.15;
    const patchY = bounds.y + bounds.height * 0.15;
    const sampleW = patchW * 0.7;
    const sampleH = bounds.height * 0.7;

    const measuredRgb = getAverageRgbFromRegion(ctx, patchX, patchY, sampleW, sampleH);
    const expected = targetPalette[i];

    // Compute delta E against expected target
    const measuredLab = rgbToLab(...measuredRgb);
    const expectedLab = rgbToLab(...expected.expectedRgb);
    const deltaE = deltaE2000(measuredLab, expectedLab);

    detected.push({
      name: expected.name,
      expectedRgb: expected.expectedRgb,
      measuredRgb,
      normalizedRgb: measuredRgb, // will be updated after lighting correction
      hex: rgbToHex(...measuredRgb),
      deltaE,
    });
  }

  return detected;
}

/**
 * Calculates lighting correction factors from detected reference patches
 */
export function calculateLightingCorrection(
  detectedPatches: DetectedColorPatch[],
  fullWidth: number,
  fullHeight: number,
  ctx: CanvasRenderingContext2D
): LightingCorrectionResult {
  // Find white reference patch (index 0) or brightest patch
  const whitePatch = detectedPatches.find(p => p.name.includes('White')) || detectedPatches[0];
  const measuredWhite = whitePatch ? whitePatch.measuredRgb : [200, 200, 200];
  const targetWhite = whitePatch ? whitePatch.expectedRgb : [240, 240, 240];

  const rGain = targetWhite[0] / Math.max(measuredWhite[0], 15);
  const gGain = targetWhite[1] / Math.max(measuredWhite[1], 15);
  const bGain = targetWhite[2] / Math.max(measuredWhite[2], 15);

  // Measure ambient brightness proxy
  const centerRgb = getAverageRgbFromRegion(ctx, fullWidth * 0.25, fullHeight * 0.25, fullWidth * 0.5, fullHeight * 0.5);
  const ambientLuxProxy = Math.round(0.299 * centerRgb[0] + 0.587 * centerRgb[1] + 0.114 * centerRgb[2]);

  // Measure lighting uniformity across corners
  const tl = getAverageRgbFromRegion(ctx, 10, 10, 30, 30);
  const br = getAverageRgbFromRegion(ctx, fullWidth - 40, fullHeight - 40, 30, 30);
  const lumTL = 0.299 * tl[0] + 0.587 * tl[1] + 0.114 * tl[2];
  const lumBR = 0.299 * br[0] + 0.587 * br[1] + 0.114 * br[2];
  const diffLum = Math.abs(lumTL - lumBR);
  const uniformityScore = clamp(Math.round(100 - diffLum * 0.8), 20, 100);

  // Correlated Color Temperature estimate proxy
  const colorTemperatureEstimate = Math.round(5500 * (rGain / Math.max(bGain, 0.1)));

  return {
    rGain: parseFloat(rGain.toFixed(3)),
    gGain: parseFloat(gGain.toFixed(3)),
    bGain: parseFloat(bGain.toFixed(3)),
    ambientLuxProxy,
    uniformityScore,
    colorTemperatureEstimate,
  };
}

/**
 * Calculates quantitative color darkening index (0.0 to 1.0)
 * Baseline unexposed strip is pale beige/white/yellow (e.g. L* ~88, a* ~-2, b* ~18).
 * Saturated exposure turns deep lead sulfide (PbS) brown/black (e.g. L* ~22, a* ~6, b* ~8).
 */
export function calculateColorIndex(
  normalizedRgb: [number, number, number],
  sensingLab: [number, number, number]
): { colorIndex: number; deltaEFromBaseline: number; absorbanceRatio: number } {
  // Pristine unexposed strip reference in Lab (matching pale cream/yellow substrate rgb(246, 240, 218))
  const baselineLab: [number, number, number] = [94.5, -2.0, 12.5];
  // Fully saturated strip reference in Lab (dense lead sulfide PbS precipitate)
  const saturatedLab: [number, number, number] = [18.0, 4.0, 5.0];

  const deltaEFromBaseline = deltaE2000(sensingLab, baselineLab);
  const maxPossibleDeltaE = deltaE2000(saturatedLab, baselineLab); // ~75.0

  // Optical absorbance proxy: A = log10(I_0 / I)
  const baselineIntensity = 0.299 * 246 + 0.587 * 240 + 0.114 * 218; // ~239
  const currentIntensity = Math.max(1, 0.299 * normalizedRgb[0] + 0.587 * normalizedRgb[1] + 0.114 * normalizedRgb[2]);
  const absorbanceRatio = parseFloat(Math.log10(baselineIntensity / currentIntensity).toFixed(3));

  // If color difference from unexposed baseline is negligible (< 1.8 ΔE), lock colorIndex to 0.0
  const normalizedIndex = deltaEFromBaseline < 1.8 ? 0 : clamp(deltaEFromBaseline / maxPossibleDeltaE, 0, 1.0);
  const colorIndex = parseFloat(normalizedIndex.toFixed(3));

  return {
    colorIndex,
    deltaEFromBaseline: parseFloat(deltaEFromBaseline.toFixed(2)),
    absorbanceRatio,
  };
}

/**
 * Modular dose estimation engine with piece-wise calibration interpolation
 * and environmental (Temperature & Humidity) diffusion compensation
 */
export function estimateDose(
  colorIndex: number,
  config: AdminCalibrationConfig,
  temperature?: number,
  humidity?: number
): { estimatedDose: number; tempCorrectionFactor: number; humidityCorrectionFactor: number; envApplied: boolean } {
  const points = [...config.calibrationPoints].sort((a, b) => a.colorIndex - b.colorIndex);

  if (points.length === 0) {
    return {
      estimatedDose: parseFloat((colorIndex * 50).toFixed(1)),
      tempCorrectionFactor: 1.0,
      humidityCorrectionFactor: 1.0,
      envApplied: false,
    };
  }

  // Piecewise linear interpolation
  let rawDose = 0;
  if (colorIndex <= points[0].colorIndex) {
    rawDose = points[0].dose;
  } else if (colorIndex >= points[points.length - 1].colorIndex) {
    rawDose = points[points.length - 1].dose;
  } else {
    for (let i = 0; i < points.length - 1; i++) {
      const p1 = points[i];
      const p2 = points[i + 1];
      if (colorIndex >= p1.colorIndex && colorIndex <= p2.colorIndex) {
        const t = (colorIndex - p1.colorIndex) / (p2.colorIndex - p1.colorIndex);
        rawDose = p1.dose + t * (p2.dose - p1.dose);
        break;
      }
    }
  }

  // Environmental compensation: Fickian diffusion rate varies with temperature and relative humidity
  let tempCorrectionFactor = 1.0;
  let humidityCorrectionFactor = 1.0;
  let envApplied = false;

  if (temperature !== undefined && !isNaN(temperature)) {
    // Temperature effect (approx 2% per degree C deviation from 25°C baseline)
    const deltaT = temperature - config.baseReferenceTemp;
    tempCorrectionFactor = 1.0 + deltaT * config.tempCoefficient;
    envApplied = true;
  }

  if (humidity !== undefined && !isNaN(humidity)) {
    // Humidity effect (approx 0.5% per %RH deviation from 50% baseline)
    const deltaH = humidity - config.baseReferenceHumidity;
    humidityCorrectionFactor = 1.0 + deltaH * config.humidityCoefficient;
    envApplied = true;
  }

  // Adjusted dose = Raw dose / (TempFactor * HumidityFactor)
  const totalEnvFactor = Math.max(0.5, tempCorrectionFactor * humidityCorrectionFactor);
  const calibratedDose = rawDose / totalEnvFactor;

  return {
    estimatedDose: parseFloat(Math.max(0, calibratedDose).toFixed(1)),
    tempCorrectionFactor: parseFloat(tempCorrectionFactor.toFixed(3)),
    humidityCorrectionFactor: parseFloat(humidityCorrectionFactor.toFixed(3)),
    envApplied,
  };
}

/**
 * Checks separate expiry / shelf-life indicator patch
 * Fresh patch = Emerald/Blue-green (Hue ~140-180)
 * Expired patch = Pink/Reddish degradation (Hue ~340-360 or <20)
 */
export function checkBadgeExpiry(
  rawRgb: [number, number, number],
  normalizedRgb: [number, number, number]
): { status: BadgeValidity; colorScore: number } {
  const [h, s, v] = rgbToHsv(...normalizedRgb);

  // In active dosimeters, expiry patch is formulated with an oxygen/UV barrier that shifts from green (120-180) to pink/red (<30 or >320)
  let status: BadgeValidity = 'VALID';
  let colorScore = 95;

  if ((h >= 320 || h <= 30) && s > 0.25) {
    status = 'EXPIRED';
    colorScore = 15;
  } else if (h >= 40 && h <= 100) {
    status = 'NEAR_EXPIRY';
    colorScore = 55;
  } else if (h >= 110 && h <= 200 && v > 0.3) {
    status = 'VALID';
    colorScore = 90;
  } else {
    // Fallback based on red vs green ratio
    const redGreenRatio = normalizedRgb[0] / Math.max(normalizedRgb[1], 1);
    if (redGreenRatio > 1.4) {
      status = 'EXPIRED';
      colorScore = 20;
    } else {
      status = 'VALID';
      colorScore = 80;
    }
  }

  return { status, colorScore };
}

/**
 * Computes analysis confidence percentage based on image sharpness, reference patch match, and lighting
 */
export function calculateConfidence(
  qualityScore: number,
  detectedPatches: DetectedColorPatch[],
  lighting: LightingCorrectionResult
): number {
  let refFitScore = 100;
  const avgDeltaE = detectedPatches.reduce((acc, p) => acc + p.deltaE, 0) / Math.max(1, detectedPatches.length);

  // If average deltaE is large, reference colors are skewed
  if (avgDeltaE > 25) {
    refFitScore -= 40;
  } else if (avgDeltaE > 15) {
    refFitScore -= 20;
  }

  const confidence = 0.45 * qualityScore + 0.35 * refFitScore + 0.20 * lighting.uniformityScore;
  return clamp(Math.round(confidence), 15, 98);
}

/**
 * Classifies risk level according to configurable prototype thresholds
 */
export function classifyRisk(dose: number, thresholds: { lowMax: number; moderateMax: number }): RiskLevel {
  if (dose < thresholds.lowMax) {
    return 'LOW';
  } else if (dose <= thresholds.moderateMax) {
    return 'MODERATE';
  } else {
    return 'HIGH';
  }
}

/**
 * Main entry point: Analyzes dosimeter wristband canvas image
 */
export async function analyzeWristbandImage(
  canvas: HTMLCanvasElement,
  options: AnalysisOptions
): Promise<ColorimetricAnalysis> {
  const ctx = canvas.getContext('2d', { willReadFrequently: true });
  if (!ctx) {
    throw new Error('Could not get 2D rendering context from canvas');
  }

  const width = canvas.width;
  const height = canvas.height;

  // Regions of Interest on the standardized dosimeter badge layout:
  // Badge is formatted with:
  // Top: Sensing strip (Y: 28% - 48%, X: 24% - 76%)
  // Middle: Reference color scale (Y: 58% - 70%, X: 16% - 84%)
  // Bottom Right: Expiry indicator (Y: 76% - 86%, X: 64% - 84%)
  const sensingRoi = {
    x: width * 0.24,
    y: height * 0.28,
    width: width * 0.52,
    height: height * 0.20,
  };

  const refScaleRoi = {
    x: width * 0.16,
    y: height * 0.58,
    width: width * 0.68,
    height: height * 0.12,
  };

  const expiryRoi = {
    x: width * 0.64,
    y: height * 0.76,
    width: width * 0.20,
    height: height * 0.10,
  };

  // 1. Detect Reference Colors
  const detectedPatches = detectReferenceColors(ctx, options.config.referenceColors, refScaleRoi);

  // 2. Compute Lighting Correction
  const lighting = calculateLightingCorrection(detectedPatches, width, height, ctx);

  // Apply lighting normalization to reference patches
  for (const patch of detectedPatches) {
    patch.normalizedRgb = applyVonKriesCorrection(patch.measuredRgb, detectedPatches[0].measuredRgb, detectedPatches[0].expectedRgb);
  }

  // 3. Extract Chemical Sensing Strip Color
  const rawSensingRgb = getAverageRgbFromRegion(ctx, sensingRoi.x, sensingRoi.y, sensingRoi.width, sensingRoi.height);
  const normalizedSensingRgb = applyVonKriesCorrection(
    rawSensingRgb,
    detectedPatches[0].measuredRgb,
    detectedPatches[0].expectedRgb
  );

  const sensingHsv = rgbToHsv(...normalizedSensingRgb);
  const sensingLab = rgbToLab(...normalizedSensingRgb);
  const { colorIndex, deltaEFromBaseline, absorbanceRatio } = calculateColorIndex(normalizedSensingRgb, sensingLab);

  // 4. Extract Expiry Indicator Patch
  const rawExpiryRgb = getAverageRgbFromRegion(ctx, expiryRoi.x, expiryRoi.y, expiryRoi.width, expiryRoi.height);
  const normalizedExpiryRgb = applyVonKriesCorrection(
    rawExpiryRgb,
    detectedPatches[0].measuredRgb,
    detectedPatches[0].expectedRgb
  );
  const expiryAnalysis = checkBadgeExpiry(rawExpiryRgb, normalizedExpiryRgb);

  // 5. Optical Quality & Sharpness Assessment
  const { quality, score: qualityScore, issues } = validateImageQuality(ctx, lighting);

  // 6. Dose Estimation & Environmental Compensation
  const { estimatedDose, tempCorrectionFactor, humidityCorrectionFactor, envApplied } = estimateDose(
    colorIndex,
    options.config,
    options.temperature,
    options.humidity
  );

  // 7. Confidence & Risk Classification
  const confidence = calculateConfidence(qualityScore, detectedPatches, lighting);
  const riskLevel = classifyRisk(estimatedDose, options.config.riskThresholds);

  return {
    colorIndex,
    estimatedDose,
    confidence,
    imageQuality: quality,
    qualityScore,
    qualityIssues: issues,
    riskLevel,
    badgeValidity: expiryAnalysis.status,
    detectedPatches,
    sensingStrip: {
      rawRgb: rawSensingRgb,
      normalizedRgb: normalizedSensingRgb,
      hex: rgbToHex(...normalizedSensingRgb),
      hsv: sensingHsv,
      lab: sensingLab,
      deltaEFromBaseline,
      absorbanceRatio,
    },
    expiryPatch: {
      rawRgb: rawExpiryRgb,
      normalizedRgb: normalizedExpiryRgb,
      status: expiryAnalysis.status,
      colorScore: expiryAnalysis.colorScore,
    },
    lightingCorrection: lighting,
    envCompensationApplied: envApplied,
    temperature: options.temperature,
    humidity: options.humidity,
    tempCorrectionFactor,
    humidityCorrectionFactor,
    engineUsed: 'CANVAS_CV_HYBRID',
    timestamp: new Date().toISOString(),
    rawFeaturesSummary: `CIEDE2000 ΔE=${deltaEFromBaseline} | R/G/B Gain=[${lighting.rGain}/${lighting.gGain}/${lighting.bGain}] | Ambient=${lighting.ambientLuxProxy} lux`,
  };
}
