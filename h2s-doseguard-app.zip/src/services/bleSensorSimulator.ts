/**
 * Environmental Sensor Module (BME280 / SHT31 / BLE Integration)
 * Provides both mock hardware telemetry and Web Bluetooth API integration.
 */

export interface EnvSensorReading {
  temperature: number; // in °C
  humidity: number; // in % RH
  pressureHpa?: number;
  batteryLevel?: number; // %
  deviceStatus: 'CONNECTED' | 'DISCONNECTED' | 'SIMULATED';
  deviceName?: string;
  lastUpdated: string;
}

export class EnvironmentalSensorManager {
  private static instance: EnvironmentalSensorManager;
  private currentReading: EnvSensorReading = {
    temperature: 26.5,
    humidity: 54.0,
    pressureHpa: 1013.2,
    batteryLevel: 94,
    deviceStatus: 'SIMULATED',
    deviceName: 'BME280-IoT-SimNode',
    lastUpdated: new Date().toLocaleTimeString(),
  };

  private listeners: Array<(reading: EnvSensorReading) => void> = [];
  private intervalId: any = null;

  private constructor() {
    this.startSimulation();
  }

  public static getInstance(): EnvironmentalSensorManager {
    if (!EnvironmentalSensorManager.instance) {
      EnvironmentalSensorManager.instance = new EnvironmentalSensorManager();
    }
    return EnvironmentalSensorManager.instance;
  }

  private startSimulation(): void {
    if (this.intervalId) return;
    this.intervalId = setInterval(() => {
      // Gentle micro-fluctuations simulating industrial environment
      const tDelta = (Math.random() - 0.5) * 0.4;
      const hDelta = (Math.random() - 0.5) * 0.8;

      this.currentReading = {
        ...this.currentReading,
        temperature: parseFloat(Math.min(48, Math.max(12, this.currentReading.temperature + tDelta)).toFixed(1)),
        humidity: parseFloat(Math.min(95, Math.max(20, this.currentReading.humidity + hDelta)).toFixed(1)),
        lastUpdated: new Date().toLocaleTimeString(),
      };

      this.notifyListeners();
    }, 4000);
  }

  public subscribe(callback: (reading: EnvSensorReading) => void): () => void {
    this.listeners.push(callback);
    callback(this.currentReading);
    return () => {
      this.listeners = this.listeners.filter(l => l !== callback);
    };
  }

  private notifyListeners(): void {
    for (const listener of this.listeners) {
      listener(this.currentReading);
    }
  }

  public getReading(): EnvSensorReading {
    return this.currentReading;
  }

  public setManualReading(temp: number, humidity: number): void {
    this.currentReading = {
      ...this.currentReading,
      temperature: temp,
      humidity: humidity,
      deviceStatus: 'SIMULATED',
      deviceName: 'Manual Overridden Sensor',
      lastUpdated: new Date().toLocaleTimeString(),
    };
    this.notifyListeners();
  }

  /**
   * Optional Web Bluetooth connect method for real hardware (ESP32 / BME280 / SHT31)
   */
  public async connectWebBluetooth(): Promise<{ success: boolean; message: string }> {
    if (typeof navigator === 'undefined' || !(navigator as any).bluetooth) {
      return {
        success: false,
        message: 'Web Bluetooth API is not supported on this browser/platform. Using internal IoT simulator instead.',
      };
    }

    try {
      const device = await (navigator as any).bluetooth.requestDevice({
        filters: [{ services: ['environmental_sensing'] }],
        optionalServices: ['battery_service'],
      });

      this.currentReading = {
        ...this.currentReading,
        deviceStatus: 'CONNECTED',
        deviceName: device.name || 'BLE-Environmental-Node',
      };
      this.notifyListeners();

      return {
        success: true,
        message: `Successfully paired with ${device.name || 'BLE Sensor Device'}`,
      };
    } catch (err: any) {
      return {
        success: false,
        message: err.message || 'Bluetooth connection was cancelled or timed out.',
      };
    }
  }
}

export const envSensor = EnvironmentalSensorManager.getInstance();
