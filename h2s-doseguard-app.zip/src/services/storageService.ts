/**
 * Storage Service & Local Prototype Database
 * Handles workers, scan logs, calibration configurations, and CSV export/import
 */

import {
  AdminCalibrationConfig,
  ExposureScanRecord,
  WorkerProfile,
} from '../types';
import { DEFAULT_REFERENCE_TARGETS } from './imageAnalysisEngine';

const STORAGE_KEYS = {
  WORKERS: 'sulfex_workers_v1',
  SCANS: 'sulfex_scans_v1',
  CONFIG: 'sulfex_config_v1',
};

// Check and migrate legacy keys if present
try {
  if (!localStorage.getItem(STORAGE_KEYS.WORKERS) && localStorage.getItem('h2s_doseguard_workers_v1')) {
    localStorage.setItem(STORAGE_KEYS.WORKERS, localStorage.getItem('h2s_doseguard_workers_v1')!);
  }
  if (!localStorage.getItem(STORAGE_KEYS.SCANS) && localStorage.getItem('h2s_doseguard_scans_v1')) {
    localStorage.setItem(STORAGE_KEYS.SCANS, localStorage.getItem('h2s_doseguard_scans_v1')!);
  }
  if (!localStorage.getItem(STORAGE_KEYS.CONFIG) && localStorage.getItem('h2s_doseguard_config_v1')) {
    localStorage.setItem(STORAGE_KEYS.CONFIG, localStorage.getItem('h2s_doseguard_config_v1')!);
  }
} catch {
  // localStorage may be disabled or restricted in certain environments
}

export const DEFAULT_CALIBRATION_CONFIG: AdminCalibrationConfig = {
  version: '2.4.0-DEMO',
  lastUpdated: new Date().toISOString(),
  enableGeminiVerification: true,
  defaultShelfLifeDays: 60,
  baseReferenceTemp: 25.0, // standard 25°C
  baseReferenceHumidity: 50.0, // standard 50% RH
  tempCoefficient: 0.018, // 1.8% per °C
  humidityCoefficient: 0.004, // 0.4% per %RH
  riskThresholds: {
    lowMax: 10.0, // 0.0 - 10.0 ppm·h (LOW)
    moderateMax: 25.0, // 10.1 - 25.0 ppm·h (MODERATE)
    // > 25.0 ppm·h (HIGH)
  },
  referenceColors: DEFAULT_REFERENCE_TARGETS,
  calibrationPoints: [
    { colorIndex: 0.00, dose: 0.0 },
    { colorIndex: 0.15, dose: 3.5 },
    { colorIndex: 0.30, dose: 8.0 },
    { colorIndex: 0.45, dose: 15.0 },
    { colorIndex: 0.60, dose: 25.0 },
    { colorIndex: 0.75, dose: 42.0 },
    { colorIndex: 0.90, dose: 65.0 },
    { colorIndex: 1.00, dose: 85.0 },
  ],
};

const SEED_WORKERS: WorkerProfile[] = [
  {
    id: 'W001',
    name: 'Alex Turner',
    department: 'Drilling Operations',
    role: 'Wellhead Technician',
    shift: 'Morning',
    assignedBadgeId: 'BDG-2026-001',
    badgeActivationDate: '2026-08-01',
    shelfLifeDays: 60,
    totalScans: 8,
    cumulativeExposurePpmH: 4.8,
    lastScanDate: '2026-08-24 14:30',
    status: 'ACTIVE',
  },
  {
    id: 'W002',
    name: 'Marcus Vance',
    department: 'Plant Maintenance',
    role: 'Piping Specialist',
    shift: 'Afternoon',
    assignedBadgeId: 'BDG-2026-042',
    badgeActivationDate: '2026-07-15',
    shelfLifeDays: 60,
    totalScans: 12,
    cumulativeExposurePpmH: 14.2,
    lastScanDate: '2026-08-25 09:15',
    status: 'ACTIVE',
  },
  {
    id: 'W003',
    name: 'Sarah Lin',
    department: 'Refining Unit 2',
    role: 'Process Engineer',
    shift: 'Morning',
    assignedBadgeId: 'BDG-2026-109',
    badgeActivationDate: '2026-08-10',
    shelfLifeDays: 60,
    totalScans: 6,
    cumulativeExposurePpmH: 1.5,
    lastScanDate: '2026-08-23 16:45',
    status: 'ACTIVE',
  },
  {
    id: 'W004',
    name: "David O'Connor",
    department: 'Sewage & Wastewater',
    role: 'Sewer Maintenance Lead',
    shift: 'Night',
    assignedBadgeId: 'BDG-2026-218',
    badgeActivationDate: '2026-06-20',
    shelfLifeDays: 60,
    totalScans: 15,
    cumulativeExposurePpmH: 28.4,
    lastScanDate: '2026-08-25 06:10',
    status: 'RESTRICTED',
  },
  {
    id: 'W005',
    name: 'Elena Rostova',
    department: 'Petrochem QC Lab',
    role: 'Senior Chemist',
    shift: 'Morning',
    assignedBadgeId: 'BDG-2026-301',
    badgeActivationDate: '2026-08-05',
    shelfLifeDays: 60,
    totalScans: 5,
    cumulativeExposurePpmH: 0.8,
    lastScanDate: '2026-08-24 11:20',
    status: 'ACTIVE',
  },
];

const SEED_SCANS: ExposureScanRecord[] = [
  {
    id: 'scan-demo-001',
    workerId: 'W004',
    workerName: "David O'Connor",
    department: 'Sewage & Wastewater',
    shift: 'Night',
    timestamp: '2026-08-25T06:10:00.000Z',
    estimatedDose: 28.4,
    riskLevel: 'HIGH',
    confidence: 89,
    badgeValidity: 'VALID',
    imageQuality: 'GOOD',
    temperature: 28,
    humidity: 75,
    isDemo: true,
    notes: 'Confined space entry inspection at interceptor station 4.',
  },
  {
    id: 'scan-demo-002',
    workerId: 'W002',
    workerName: 'Marcus Vance',
    department: 'Plant Maintenance',
    shift: 'Afternoon',
    timestamp: '2026-08-25T09:15:00.000Z',
    estimatedDose: 14.2,
    riskLevel: 'MODERATE',
    confidence: 92,
    badgeValidity: 'VALID',
    imageQuality: 'GOOD',
    temperature: 26,
    humidity: 55,
    isDemo: true,
    notes: 'Valve flange gasket replacement on desulfurizer bypass.',
  },
  {
    id: 'scan-demo-003',
    workerId: 'W001',
    workerName: 'Alex Turner',
    department: 'Drilling Operations',
    shift: 'Morning',
    timestamp: '2026-08-24T14:30:00.000Z',
    estimatedDose: 4.8,
    riskLevel: 'LOW',
    confidence: 95,
    badgeValidity: 'VALID',
    imageQuality: 'GOOD',
    temperature: 31,
    humidity: 45,
    isDemo: true,
    notes: 'Standard drilling deck inspection.',
  },
  {
    id: 'scan-demo-004',
    workerId: 'W003',
    workerName: 'Sarah Lin',
    department: 'Refining Unit 2',
    shift: 'Morning',
    timestamp: '2026-08-23T16:45:00.000Z',
    estimatedDose: 1.5,
    riskLevel: 'LOW',
    confidence: 96,
    badgeValidity: 'VALID',
    imageQuality: 'GOOD',
    temperature: 24,
    humidity: 50,
    isDemo: true,
    notes: 'Control room routine shift check.',
  },
  {
    id: 'scan-demo-005',
    workerId: 'W005',
    workerName: 'Elena Rostova',
    department: 'Petrochem QC Lab',
    shift: 'Morning',
    timestamp: '2026-08-24T11:20:00.000Z',
    estimatedDose: 0.8,
    riskLevel: 'LOW',
    confidence: 98,
    badgeValidity: 'VALID',
    imageQuality: 'GOOD',
    temperature: 22,
    humidity: 48,
    isDemo: true,
    notes: 'Fume hood sampling protocol.',
  },
  {
    id: 'scan-demo-006',
    workerId: 'W002',
    workerName: 'Marcus Vance',
    department: 'Plant Maintenance',
    shift: 'Morning',
    timestamp: '2026-08-22T10:05:00.000Z',
    estimatedDose: 8.9,
    riskLevel: 'LOW',
    confidence: 88,
    badgeValidity: 'VALID',
    imageQuality: 'GOOD',
    temperature: 27,
    humidity: 60,
    isDemo: true,
    notes: 'Flare stack peripheral line check.',
  },
];

export const storageService = {
  getWorkers(): WorkerProfile[] {
    try {
      const data = localStorage.getItem(STORAGE_KEYS.WORKERS);
      if (!data) {
        localStorage.setItem(STORAGE_KEYS.WORKERS, JSON.stringify(SEED_WORKERS));
        return SEED_WORKERS;
      }
      return JSON.parse(data);
    } catch {
      return SEED_WORKERS;
    }
  },

  saveWorker(worker: WorkerProfile): void {
    const workers = this.getWorkers();
    const index = workers.findIndex(w => w.id === worker.id);
    if (index >= 0) {
      workers[index] = worker;
    } else {
      workers.unshift(worker);
    }
    localStorage.setItem(STORAGE_KEYS.WORKERS, JSON.stringify(workers));
  },

  deleteWorker(id: string): void {
    const workers = this.getWorkers().filter(w => w.id !== id);
    localStorage.setItem(STORAGE_KEYS.WORKERS, JSON.stringify(workers));
  },

  getScans(): ExposureScanRecord[] {
    try {
      const data = localStorage.getItem(STORAGE_KEYS.SCANS);
      if (!data) {
        localStorage.setItem(STORAGE_KEYS.SCANS, JSON.stringify(SEED_SCANS));
        return SEED_SCANS;
      }
      const parsed = JSON.parse(data);
      if (Array.isArray(parsed)) {
        return parsed.map((s: ExposureScanRecord, i: number) => ({
          ...s,
          temperature: typeof s.temperature === 'number' ? s.temperature : (26 + (i % 6)),
          humidity: typeof s.humidity === 'number' ? s.humidity : (52 + ((i * 4) % 24)),
        }));
      }
      return SEED_SCANS;
    } catch {
      return SEED_SCANS;
    }
  },

  saveScan(scan: ExposureScanRecord): void {
    const scans = this.getScans();
    scans.unshift(scan);
    localStorage.setItem(STORAGE_KEYS.SCANS, JSON.stringify(scans));

    // Update worker profile statistics
    const workers = this.getWorkers();
    const worker = workers.find(w => w.id === scan.workerId);
    if (worker) {
      worker.totalScans += 1;
      worker.cumulativeExposurePpmH = parseFloat((worker.cumulativeExposurePpmH + scan.estimatedDose).toFixed(1));
      worker.lastScanDate = new Date().toISOString().replace('T', ' ').substring(0, 16);
      if (scan.riskLevel === 'HIGH') {
        worker.status = 'RESTRICTED';
      }
      this.saveWorker(worker);
    }
  },

  deleteScan(id: string): void {
    const scans = this.getScans().filter(s => s.id !== id);
    localStorage.setItem(STORAGE_KEYS.SCANS, JSON.stringify(scans));
  },

  getConfig(): AdminCalibrationConfig {
    try {
      const data = localStorage.getItem(STORAGE_KEYS.CONFIG);
      if (!data) {
        localStorage.setItem(STORAGE_KEYS.CONFIG, JSON.stringify(DEFAULT_CALIBRATION_CONFIG));
        return DEFAULT_CALIBRATION_CONFIG;
      }
      return JSON.parse(data);
    } catch {
      return DEFAULT_CALIBRATION_CONFIG;
    }
  },

  saveConfig(config: AdminCalibrationConfig): void {
    config.lastUpdated = new Date().toISOString();
    localStorage.setItem(STORAGE_KEYS.CONFIG, JSON.stringify(config));
  },

  resetConfigToDefault(): AdminCalibrationConfig {
    localStorage.setItem(STORAGE_KEYS.CONFIG, JSON.stringify(DEFAULT_CALIBRATION_CONFIG));
    return DEFAULT_CALIBRATION_CONFIG;
  },

  exportScansToCsv(): string {
    const scans = this.getScans();
    const headers = ['Scan ID', 'Worker ID', 'Worker Name', 'Department', 'Shift', 'Timestamp', 'Estimated Dose (ppm·h)', 'Risk Level', 'Confidence (%)', 'Badge Validity', 'Image Quality', 'Temp (°C)', 'Humidity (%)', 'Type', 'Notes'];
    
    const rows = scans.map(s => [
      s.id,
      s.workerId,
      `"${s.workerName.replace(/"/g, '""')}"`,
      `"${s.department.replace(/"/g, '""')}"`,
      s.shift,
      s.timestamp,
      s.estimatedDose,
      s.riskLevel,
      s.confidence,
      s.badgeValidity,
      s.imageQuality,
      s.temperature ?? 'N/A',
      s.humidity ?? 'N/A',
      s.isDemo ? 'DEMO' : 'LIVE',
      `"${(s.notes || '').replace(/"/g, '""')}"`,
    ]);

    return [headers.join(','), ...rows.map(r => r.join(','))].join('\n');
  },

  exportCalibrationCsv(): string {
    const config = this.getConfig();
    const headers = ['Color Index (0-1)', 'Calibrated Dose (ppm·h)'];
    const rows = config.calibrationPoints.map(p => [p.colorIndex, p.dose]);
    return [headers.join(','), ...rows.map(r => r.join(','))].join('\n');
  },

  importCalibrationFromCsv(csvText: string): { success: boolean; count: number; error?: string } {
    try {
      const lines = csvText.trim().split('\n');
      if (lines.length < 2) {
        return { success: false, count: 0, error: 'CSV file must have at least header and one data row' };
      }

      const points = [];
      for (let i = 1; i < lines.length; i++) {
        const line = lines[i].trim();
        if (!line) continue;
        const [idxStr, doseStr] = line.split(',').map(s => s.trim());
        const colorIndex = parseFloat(idxStr);
        const dose = parseFloat(doseStr);
        if (!isNaN(colorIndex) && !isNaN(dose)) {
          points.push({ colorIndex, dose });
        }
      }

      if (points.length < 2) {
        return { success: false, count: 0, error: 'At least 2 valid calibration points are required' };
      }

      const config = this.getConfig();
      config.calibrationPoints = points.sort((a, b) => a.colorIndex - b.colorIndex);
      this.saveConfig(config);

      return { success: true, count: points.length };
    } catch (err: any) {
      return { success: false, count: 0, error: err.message || 'Failed to parse CSV' };
    }
  },

  clearAllData(): void {
    localStorage.removeItem(STORAGE_KEYS.WORKERS);
    localStorage.removeItem(STORAGE_KEYS.SCANS);
    localStorage.removeItem(STORAGE_KEYS.CONFIG);
  },
};
