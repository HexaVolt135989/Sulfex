import React, { useState, useEffect, useCallback } from 'react';
import { ActiveTab, AdminCalibrationConfig, ExposureScanRecord, WorkerProfile } from './types';
import { storageService } from './services/storageService';
import { envSensor, EnvSensorReading } from './services/bleSensorSimulator';
import { SampleBadgeSpec } from './services/sampleWristbandGenerator';
import { Navbar } from './components/Navbar';
import { BottomNavigation } from './components/BottomNavigation';
import { HomeScreen } from './components/HomeScreen';
import { ScannerView } from './components/ScannerView';
import { HistoryView } from './components/HistoryView';
import { DashboardView } from './components/DashboardView';
import { WorkerProfilesView } from './components/WorkerProfilesView';
import { AdminCalibrationView } from './components/AdminCalibrationView';
import { BadgeGeneratorModal } from './components/BadgeGeneratorModal';
import { AboutModal } from './components/AboutModal';
import { HexavoltDevModal } from './components/HexavoltDevModal';

export default function App() {
  const [activeTab, setActiveTab] = useState<ActiveTab>('home');
  const [workers, setWorkers] = useState<WorkerProfile[]>([]);
  const [scans, setScans] = useState<ExposureScanRecord[]>([]);
  const [calibrationConfig, setCalibrationConfig] = useState<AdminCalibrationConfig>(
    storageService.getConfig()
  );

  // Environmental Sensor Telemetry
  const [sensorData, setSensorData] = useState<EnvSensorReading>(envSensor.getReading());

  // Modals & Demo Badge Handlers
  const [isSampleModalOpen, setIsSampleModalOpen] = useState<boolean>(false);
  const [isAboutModalOpen, setIsAboutModalOpen] = useState<boolean>(false);
  const [isDevModalOpen, setIsDevModalOpen] = useState<boolean>(false);
  const [preSelectedSample, setPreSelectedSample] = useState<SampleBadgeSpec | null>(null);
  const [navHistory, setNavHistory] = useState<ActiveTab[]>(['home']);

  const handleNavigate = useCallback((tab: ActiveTab) => {
    setActiveTab((current) => {
      if (tab !== current) {
        setNavHistory((prev) => [...prev, tab]);
        return tab;
      }
      return current;
    });
  }, []);

  const handleBack = useCallback(() => {
    setNavHistory((prev) => {
      if (prev.length > 1) {
        const nextHistory = [...prev];
        nextHistory.pop();
        const previousTab = nextHistory[nextHistory.length - 1] || 'home';
        setActiveTab(previousTab);
        return nextHistory;
      } else {
        setActiveTab('home');
        return ['home'];
      }
    });
  }, []);

  // Initial Load from Storage & Sensor Subscription
  useEffect(() => {
    setWorkers(storageService.getWorkers());
    setScans(storageService.getScans());
    setCalibrationConfig(storageService.getConfig());

    const unsubscribeSensor = envSensor.subscribe((reading) => {
      setSensorData(reading);
    });

    return () => {
      unsubscribeSensor();
    };
  }, []);

  // Handlers for Scans
  const handleSaveScan = useCallback((newScan: ExposureScanRecord) => {
    storageService.saveScan(newScan);
    setScans(storageService.getScans());
    setWorkers(storageService.getWorkers());
  }, []);

  const handleDeleteScan = useCallback((id: string) => {
    storageService.deleteScan(id);
    setScans(storageService.getScans());
  }, []);

  // Handlers for Workers
  const handleAddWorker = useCallback((newWorker: WorkerProfile) => {
    storageService.saveWorker(newWorker);
    setWorkers(storageService.getWorkers());
  }, []);

  const handleUpdateWorker = useCallback((updatedWorker: WorkerProfile) => {
    storageService.saveWorker(updatedWorker);
    setWorkers(storageService.getWorkers());
  }, []);

  const handleDeleteWorker = useCallback((id: string) => {
    storageService.deleteWorker(id);
    setWorkers(storageService.getWorkers());
  }, []);

  // Handlers for Calibration
  const handleSaveConfig = useCallback((newConfig: AdminCalibrationConfig) => {
    storageService.saveConfig(newConfig);
    setCalibrationConfig(newConfig);
  }, []);

  const handleResetConfig = useCallback(() => {
    const fresh = storageService.resetConfigToDefault();
    setCalibrationConfig(fresh);
  }, []);

  // Quick Demo Badge Launcher
  const handleSelectSampleBadge = useCallback((spec: SampleBadgeSpec) => {
    setPreSelectedSample(spec);
    handleNavigate('scan');
  }, [handleNavigate]);

  const handleOpenAbout = useCallback(() => setIsAboutModalOpen(true), []);
  const handleCloseAbout = useCallback(() => setIsAboutModalOpen(false), []);
  const handleOpenDev = useCallback(() => setIsDevModalOpen(true), []);
  const handleCloseDev = useCallback(() => setIsDevModalOpen(false), []);
  const handleOpenSampleModal = useCallback(() => setIsSampleModalOpen(true), []);
  const handleCloseSampleModal = useCallback(() => setIsSampleModalOpen(false), []);
  const handleClearPreSelectedSample = useCallback(() => setPreSelectedSample(null), []);

  return (
    <div className="min-h-screen bg-gradient-to-b from-[#C4B5FD]/40 via-[#E0E7FF]/35 to-[#F1F3FB] text-slate-900 flex flex-col font-['Plus_Jakarta_Sans',sans-serif] selection:bg-black selection:text-white">
      {/* Top Header */}
      <Navbar
        activeTab={activeTab}
        setActiveTab={handleNavigate}
        onBack={handleBack}
        onOpenSampleBadges={handleOpenSampleModal}
        onOpenAbout={handleOpenAbout}
        onOpenDev={handleOpenDev}
        envTemp={sensorData.temperature}
        envHumidity={sensorData.humidity}
      />

      {/* Main Content Area */}
      <main className="flex-1 max-w-4xl w-full mx-auto px-3 sm:px-4 py-4 pb-28">
        {activeTab === 'home' && (
          <HomeScreen
            setActiveTab={handleNavigate}
            workers={workers}
            scans={scans}
            onSelectSampleBadge={handleSelectSampleBadge}
            onOpenAbout={handleOpenAbout}
          />
        )}

        {activeTab === 'scan' && (
          <ScannerView
            workers={workers}
            config={calibrationConfig}
            onSaveScan={handleSaveScan}
            setActiveTab={handleNavigate}
            onBack={handleBack}
            preSelectedSample={preSelectedSample}
            onClearPreSelectedSample={handleClearPreSelectedSample}
            envTemp={sensorData.temperature}
            envHumidity={sensorData.humidity}
          />
        )}

        {activeTab === 'history' && (
          <HistoryView
            scans={scans}
            onDeleteScan={handleDeleteScan}
            onBack={handleBack}
          />
        )}

        {activeTab === 'dashboard' && (
          <DashboardView
            workers={workers}
            scans={scans}
            onBack={handleBack}
          />
        )}

        {activeTab === 'workers' && (
          <WorkerProfilesView
            workers={workers}
            scans={scans}
            onAddWorker={handleAddWorker}
            onUpdateWorker={handleUpdateWorker}
            onDeleteWorker={handleDeleteWorker}
            onBack={handleBack}
            envTemp={sensorData.temperature}
            envHumidity={sensorData.humidity}
            onOpenScan={() => handleNavigate('scan')}
          />
        )}

        {activeTab === 'calibration' && (
          <AdminCalibrationView
            config={calibrationConfig}
            onSaveConfig={handleSaveConfig}
            onResetConfig={handleResetConfig}
            onBack={handleBack}
          />
        )}
      </main>

      {/* Bottom Navigation for Mobile Devices */}
      <BottomNavigation
        activeTab={activeTab}
        setActiveTab={handleNavigate}
      />

      {/* Synthetic Badge Generator Modal */}
      <BadgeGeneratorModal
        isOpen={isSampleModalOpen}
        onClose={handleCloseSampleModal}
        onSelectBadgeForScan={handleSelectSampleBadge}
      />

      {/* User Manual & About Modal */}
      <AboutModal
        isOpen={isAboutModalOpen}
        onClose={handleCloseAbout}
      />

      {/* Hexavolt Developer Modal */}
      <HexavoltDevModal
        isOpen={isDevModalOpen}
        onClose={handleCloseDev}
      />
    </div>
  );
}
