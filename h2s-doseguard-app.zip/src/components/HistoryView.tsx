import React, { useState, useMemo, memo } from 'react';
import {
  Download,
  Trash2,
  Eye,
  FileText,
  X,
  ArrowLeft,
  Plus,
  SlidersHorizontal,
  CheckCircle2,
  AlertTriangle,
  Thermometer,
  Droplets,
} from 'lucide-react';
import { ExposureScanRecord, RiskLevel, ShiftType } from '../types';
import { storageService } from '../services/storageService';
import { ImageAnalysisOverlay } from './ImageAnalysisOverlay';

interface HistoryViewProps {
  scans: ExposureScanRecord[];
  onDeleteScan: (id: string) => void;
  onBack?: () => void;
  onOpenScan?: () => void;
}

export const HistoryView: React.FC<HistoryViewProps> = memo(({ scans, onDeleteScan, onBack, onOpenScan }) => {
  const [activeSegment, setActiveSegment] = useState<'ALL' | 'HIGH' | 'SAFE'>('ALL');
  const [selectedScan, setSelectedScan] = useState<ExposureScanRecord | null>(null);
  const [scanToDelete, setScanToDelete] = useState<ExposureScanRecord | null>(null);

  // Filtered list based on segmented filter
  const filteredScans = useMemo(() => {
    return scans
      .filter((scan) => {
        if (activeSegment === 'HIGH') return scan.riskLevel === 'HIGH';
        if (activeSegment === 'SAFE') return scan.riskLevel === 'LOW';
        return true;
      })
      .sort((a, b) => new Date(b.timestamp).getTime() - new Date(a.timestamp).getTime());
  }, [scans, activeSegment]);

  const handleExportCsv = () => {
    const csvData = storageService.exportScansToCsv();
    const blob = new Blob([csvData], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.setAttribute('href', url);
    link.setAttribute('download', `Sulfex_Exposure_Logs_${new Date().toISOString().slice(0, 10)}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  return (
    <div className="space-y-4 max-w-xl mx-auto pb-24">
      {/* 1. Top Header Bar (Matching Center Phone "< Later + filter") */}
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-2.5">
          {onBack && (
            <button
              id="history-back-btn"
              onClick={onBack}
              className="w-9 h-9 rounded-full bg-white/70 hover:bg-white border border-white/90 text-slate-800 flex items-center justify-center shadow-xs active:scale-95 transition-all cursor-pointer"
              title="Back"
            >
              <ArrowLeft className="w-4 h-4 text-slate-800" />
            </button>
          )}
          <h2 className="text-xl sm:text-2xl font-black text-slate-900 tracking-tight">
            Exposure Feed
          </h2>
        </div>

        <div className="flex items-center gap-1.5">
          {onOpenScan && (
            <button
              id="history-add-btn"
              onClick={onOpenScan}
              className="w-9 h-9 rounded-full bg-white/70 hover:bg-white border border-white/90 text-slate-800 flex items-center justify-center shadow-xs active:scale-95 transition-all cursor-pointer"
              title="New Scan"
            >
              <Plus className="w-4 h-4 text-slate-800" />
            </button>
          )}

          <button
            id="history-export-btn"
            onClick={handleExportCsv}
            disabled={scans.length === 0}
            className="w-9 h-9 rounded-full bg-white/70 hover:bg-white border border-white/90 text-slate-800 flex items-center justify-center shadow-xs active:scale-95 transition-all cursor-pointer disabled:opacity-40"
            title="Download CSV Log"
          >
            <Download className="w-4 h-4 text-slate-800" />
          </button>
        </div>
      </div>

      {/* 2. Segmented Pill Filter (Matching "Ongoing 1", "Archived", "Completed") */}
      <div className="flex items-center gap-1.5 bg-white/50 backdrop-blur-xl p-1 rounded-full border border-white/80 shadow-xs">
        <button
          id="filter-segment-all"
          onClick={() => setActiveSegment('ALL')}
          className={`flex-1 py-2 px-3 rounded-full text-xs font-black transition-all cursor-pointer text-center ${
            activeSegment === 'ALL'
              ? 'bg-black text-white shadow-sm'
              : 'text-slate-600 hover:text-slate-900'
          }`}
        >
          All Scans ({scans.length})
        </button>

        <button
          id="filter-segment-high"
          onClick={() => setActiveSegment('HIGH')}
          className={`flex-1 py-2 px-3 rounded-full text-xs font-black transition-all cursor-pointer text-center ${
            activeSegment === 'HIGH'
              ? 'bg-black text-white shadow-sm'
              : 'text-slate-600 hover:text-slate-900'
          }`}
        >
          High Risk
        </button>

        <button
          id="filter-segment-safe"
          onClick={() => setActiveSegment('SAFE')}
          className={`flex-1 py-2 px-3 rounded-full text-xs font-black transition-all cursor-pointer text-center ${
            activeSegment === 'SAFE'
              ? 'bg-black text-white shadow-sm'
              : 'text-slate-600 hover:text-slate-900'
          }`}
        >
          Safe Baseline
        </button>
      </div>

      {/* 3. Gradient Cards Feed (Matching Center Phone in Reference Design) */}
      <div className="space-y-3.5 pt-1">
        {filteredScans.length === 0 ? (
          <div className="bg-white rounded-[32px] p-8 text-center border border-white/80 shadow-sm">
            <CheckCircle2 className="w-10 h-10 text-emerald-500 mx-auto mb-2" />
            <h4 className="text-base font-black text-slate-900">No Exposure Records Found</h4>
            <p className="text-xs text-slate-500 mt-1 max-w-xs mx-auto">
              {activeSegment === 'HIGH'
                ? 'Great news! No high-risk exposure incidents logged.'
                : 'Scan a dosimeter badge to log colorimetric results in this feed.'}
            </p>
          </div>
        ) : (
          filteredScans.map((scan) => {
            const isHigh = scan.riskLevel === 'HIGH';
            const isModerate = scan.riskLevel === 'MODERATE';

            const timeFormatted = new Date(scan.timestamp).toLocaleTimeString([], {
              hour: '2-digit',
              minute: '2-digit',
            });

            return (
              <div
                key={scan.id}
                className="relative rounded-[32px] p-5 sm:p-6 text-slate-900 shadow-[0_8px_30px_rgba(0,0,0,0.06)] bg-white/95 backdrop-blur-xl border border-slate-200/90 transition-transform duration-200 hover:scale-[1.005]"
              >
                {/* Header Tag */}
                <div className="text-xs sm:text-sm font-semibold text-slate-500 tracking-wide mb-2.5 flex items-center justify-between">
                  <span># {scan.department} • {scan.shift} Shift</span>
                  <span className="font-mono text-slate-900 font-bold">{timeFormatted}</span>
                </div>

                {/* Worker Avatar & Name Row */}
                <div className="flex items-center justify-between gap-3">
                  <div className="flex items-center gap-3.5">
                    {/* Circle Avatar with Online Dot */}
                    <div className="relative w-12 h-12 rounded-full bg-slate-100 border-2 border-slate-200 flex items-center justify-center font-black text-slate-900 text-sm shadow-inner shrink-0">
                      {scan.workerName.split(' ').map((n) => n[0]).join('')}
                      <span className="absolute bottom-0 right-0 w-3.5 h-3.5 rounded-full bg-emerald-500 border-2 border-white" />
                    </div>

                    <div>
                      <h4 className="text-lg sm:text-xl font-bold text-slate-950 leading-snug tracking-tight">
                        {scan.workerName}
                      </h4>
                      <p className="text-xs sm:text-sm text-slate-500 font-medium">
                        Worker ID: <span className="font-mono font-semibold text-slate-900">{scan.workerId}</span>
                      </p>
                    </div>
                  </div>

                  {/* Status Pill */}
                  <span className={`px-3.5 py-1.5 rounded-full text-xs font-black uppercase tracking-wider shadow-2xs shrink-0 ${
                    isHigh
                      ? 'bg-rose-100 text-rose-800 border border-rose-200'
                      : isModerate
                      ? 'bg-amber-100 text-amber-900 border border-amber-200'
                      : 'bg-emerald-100 text-emerald-900 border border-emerald-200'
                  }`}>
                    {isHigh ? 'High Risk' : isModerate ? 'Moderate' : 'Safe'}
                  </span>
                </div>

                {/* Environmental Readout: Temperature, Humidity, and Confidence */}
                <div className="flex items-center gap-2 mt-3.5">
                  <div className="inline-flex items-center gap-2.5 px-3 py-1.5 rounded-xl bg-slate-50/90 border border-slate-200/80 font-mono text-xs shadow-2xs">
                    <span className="flex items-center gap-1 font-bold text-slate-900">
                      <Thermometer className="w-3.5 h-3.5 text-amber-600 shrink-0" />
                      {Number(scan.temperature ?? 28).toFixed(1)}°C
                    </span>
                    <span className="text-slate-300">·</span>
                    <span className="flex items-center gap-1 font-bold text-slate-900">
                      <Droplets className="w-3.5 h-3.5 text-sky-600 shrink-0" />
                      {Number(scan.humidity ?? 55).toFixed(1)}% RH
                    </span>
                    <span className="text-slate-300">·</span>
                    <span className="text-slate-500 font-medium">
                      {scan.confidence}% Fit
                    </span>
                  </div>
                </div>

                {/* Scan Summary Message Text */}
                <p className="text-sm text-slate-700 font-normal leading-relaxed mt-3">
                  Dosimeter analysis recorded <strong className="text-slate-950 font-bold">{scan.estimatedDose} ppm·h</strong> cumulative exposure calibrated at <strong className="text-slate-950 font-bold">{scan.temperature ?? 28}°C</strong> ambient temperature and <strong className="text-slate-950 font-bold">{scan.humidity ?? 55}% RH</strong> relative humidity.
                </p>

                {/* Attachment Pill Card */}
                <div
                  onClick={() => setSelectedScan(scan)}
                  className="mt-3.5 p-3.5 rounded-2xl bg-slate-50 hover:bg-slate-100/90 border border-slate-200/90 flex items-center justify-between cursor-pointer transition-colors shadow-2xs"
                >
                  <div className="flex items-center gap-3 overflow-hidden">
                    <div className="w-9 h-9 rounded-xl bg-black text-white flex items-center justify-center shrink-0 shadow-xs font-black text-xs">
                      PDF
                    </div>
                    <div className="truncate">
                      <p className="text-sm font-bold text-slate-900 truncate">
                        Dosimeter_Scan_{scan.id.slice(0, 8)}.pdf
                      </p>
                      <p className="text-xs text-slate-500 font-mono font-medium">
                        {scan.estimatedDose} ppm·h • 🌡️ {scan.temperature ?? 28}°C • 💧 {scan.humidity ?? 55}% RH
                      </p>
                    </div>
                  </div>

                  <div className="flex items-center gap-1.5 shrink-0 ml-2">
                    <button
                      type="button"
                      onClick={(e) => {
                        e.stopPropagation();
                        setScanToDelete(scan);
                      }}
                      className="p-2 rounded-full hover:bg-slate-200 text-slate-400 hover:text-rose-600 transition-colors cursor-pointer"
                      title="Delete log"
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                    <div className="p-2 rounded-full bg-slate-200/80 text-slate-900">
                      <Eye className="w-4 h-4" />
                    </div>
                  </div>
                </div>
              </div>
            );
          })
        )}
      </div>

      {/* Modal: Full Analysis Details */}
      {selectedScan && (
        <div className="fixed inset-0 z-50 bg-slate-900/60 backdrop-blur-xs overflow-y-auto p-3 sm:p-6 flex justify-center items-center">
          <div className="bg-white rounded-[32px] max-w-lg w-full p-5 sm:p-6 space-y-4 shadow-2xl border border-slate-100 animate-in fade-in zoom-in duration-150">
            <div className="flex items-center justify-between">
              <div>
                <h3 className="text-lg font-black text-slate-900">
                  Dosimeter Optical Report
                </h3>
                <p className="text-xs text-slate-500 font-medium">
                  {selectedScan.workerName} • ID {selectedScan.workerId}
                </p>
              </div>
              <button
                onClick={() => setSelectedScan(null)}
                className="w-8 h-8 rounded-full bg-slate-100 hover:bg-slate-200 text-slate-700 flex items-center justify-center transition-colors cursor-pointer"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            {selectedScan.imageDataUrl && (
              <div className="aspect-[4/3] rounded-2xl overflow-hidden bg-slate-950 border border-slate-200 flex items-center justify-center max-h-52 mx-auto">
                <img
                  src={selectedScan.imageDataUrl}
                  alt="Captured dosimeter"
                  className="w-full h-full object-contain"
                />
              </div>
            )}

            <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 text-xs">
              <div className="bg-slate-50 p-2.5 rounded-2xl border border-slate-100">
                <span className="text-[10px] text-slate-400 font-bold uppercase block">Dose</span>
                <span className="text-sm font-black text-slate-900 font-mono">{selectedScan.estimatedDose} ppm·h</span>
              </div>
              <div className="bg-slate-50 p-2.5 rounded-2xl border border-slate-100">
                <span className="text-[10px] text-slate-400 font-bold uppercase block">Risk</span>
                <span className="text-sm font-black text-slate-900 uppercase">{selectedScan.riskLevel}</span>
              </div>
              <div className="bg-amber-50/80 p-2.5 rounded-2xl border border-amber-100">
                <span className="text-[10px] text-amber-700 font-bold uppercase flex items-center gap-1">
                  <Thermometer className="w-3 h-3 text-amber-600" />
                  Temp
                </span>
                <span className="text-sm font-black text-amber-950 font-mono">{selectedScan.temperature ?? 28}°C</span>
              </div>
              <div className="bg-sky-50/80 p-2.5 rounded-2xl border border-sky-100">
                <span className="text-[10px] text-sky-700 font-bold uppercase flex items-center gap-1">
                  <Droplets className="w-3 h-3 text-sky-600" />
                  Humidity
                </span>
                <span className="text-sm font-black text-sky-950 font-mono">{selectedScan.humidity ?? 55}% RH</span>
              </div>
            </div>

            {selectedScan.analysisDetails && (
              <ImageAnalysisOverlay analysis={selectedScan.analysisDetails} />
            )}

            <button
              onClick={() => setSelectedScan(null)}
              className="w-full py-3 bg-black text-white font-bold rounded-2xl text-xs hover:bg-slate-900 transition-colors cursor-pointer"
            >
              Done
            </button>
          </div>
        </div>
      )}

      {/* Modal: Delete Confirmation */}
      {scanToDelete && (
        <div className="fixed inset-0 z-50 bg-slate-900/60 backdrop-blur-xs p-4 flex justify-center items-center">
          <div className="bg-white rounded-[32px] max-w-sm w-full p-5 space-y-3 shadow-2xl border border-slate-100">
            <h4 className="text-base font-black text-slate-900">Delete Scan Record?</h4>
            <p className="text-xs text-slate-600">
              Permanently delete dosimeter record for <strong className="text-slate-900">{scanToDelete.workerName}</strong>?
            </p>
            <div className="flex gap-2 pt-2">
              <button
                type="button"
                onClick={() => setScanToDelete(null)}
                className="flex-1 py-2.5 rounded-full bg-slate-100 text-slate-700 font-bold text-xs hover:bg-slate-200"
              >
                Cancel
              </button>
              <button
                type="button"
                onClick={() => {
                  onDeleteScan(scanToDelete.id);
                  if (selectedScan?.id === scanToDelete.id) setSelectedScan(null);
                  setScanToDelete(null);
                }}
                className="flex-1 py-2.5 rounded-full bg-rose-600 text-white font-bold text-xs hover:bg-rose-700 shadow-sm"
              >
                Delete
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
});
