import React from 'react';
import {
  X,
  Scan,
  Sparkles,
  Users,
  ShieldAlert,
  FileSpreadsheet,
  CheckCircle2,
  BookOpen,
  ArrowRight,
  Cpu,
  Shield,
  Code2,
  Zap,
} from 'lucide-react';
import { DoseGuardLogo } from './DoseGuardLogo';
import { HexavoltLogo } from './HexavoltLogo';

interface AboutModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const AboutModal: React.FC<AboutModalProps> = ({ isOpen, onClose }) => {
  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 bg-slate-950/65 backdrop-blur-sm overflow-y-auto p-3 sm:p-5 flex justify-center items-start sm:items-center animate-fade-in">
      <div className="bg-white rounded-[32px] max-w-2xl w-full p-5 sm:p-7 space-y-6 shadow-2xl border border-slate-100 my-4 sm:my-6 relative overflow-hidden text-slate-900">
        {/* Subtle Ambient Background Gradients */}
        <div className="absolute -top-24 -right-24 w-60 h-60 bg-purple-500/10 rounded-full blur-3xl pointer-events-none" />
        <div className="absolute top-1/2 -left-24 w-60 h-60 bg-blue-500/10 rounded-full blur-3xl pointer-events-none" />

        {/* 1. Modal Header */}
        <div className="flex items-center justify-between pb-3 border-b border-slate-100">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-2xl bg-black text-white flex items-center justify-center shadow-sm shrink-0">
              <BookOpen className="w-5 h-5 text-white" />
            </div>
            <div>
              <h3 className="text-base sm:text-lg font-black text-slate-900 tracking-tight leading-tight">
                Sulfex — User Manual
              </h3>
              <p className="text-xs text-slate-500 font-medium mt-0.5">
                Quick Start Guide &amp; Operational Procedures
              </p>
            </div>
          </div>

          <button
            id="about-modal-close-btn"
            onClick={onClose}
            className="w-9 h-9 rounded-full bg-slate-100 hover:bg-slate-200 text-slate-600 hover:text-slate-950 flex items-center justify-center transition-colors cursor-pointer shrink-0"
            title="Close modal"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Scrollable Container */}
        <div className="space-y-6 max-h-[68vh] overflow-y-auto pr-1 no-scrollbar text-xs sm:text-sm text-slate-700 leading-relaxed">
          {/* Introduction Card */}
          <div className="rounded-2xl bg-slate-50 border border-slate-200/80 p-4 space-y-1.5">
            <h4 className="text-xs font-black uppercase tracking-wider text-slate-900 flex items-center gap-1.5">
              <Sparkles className="w-3.5 h-3.5 text-amber-600" />
              Welcome to Sulfex
            </h4>
            <p className="text-xs text-slate-600 leading-relaxed">
              Sulfex converts your smartphone or field tablet into an intelligent optical reader for disposable, zero-power colorimetric dosimeter badges. Follow the step-by-step instructions below to ensure accurate personal exposure tracking across your workforce.
            </p>
          </div>

          {/* 5-Step User Manual */}
          <div className="space-y-3">
            <h4 className="text-xs font-black uppercase tracking-wider text-slate-800 px-1">
              Step-by-Step Operating Instructions
            </h4>

            {/* Step 1 */}
            <div className="rounded-2xl bg-white border border-slate-200/80 p-4 shadow-2xs space-y-2 hover:border-slate-300 transition-colors">
              <div className="flex items-center gap-2.5">
                <div className="w-6 h-6 rounded-full bg-black text-white text-[11px] font-black flex items-center justify-center shrink-0">
                  1
                </div>
                <h5 className="text-xs sm:text-sm font-black text-slate-900">
                  Position &amp; Scan the Dosimeter Badge
                </h5>
              </div>
              <p className="text-xs text-slate-600 pl-8">
                Navigate to <strong>Activity (Scan)</strong> and place the worker&apos;s dosimeter wristband within the camera viewfinder alignment frame. Ensure good framing so that both the central chemical sensing patch and the printed 5-color reference scale are fully visible.
              </p>
            </div>

            {/* Step 2 */}
            <div className="rounded-2xl bg-white border border-slate-200/80 p-4 shadow-2xs space-y-2 hover:border-slate-300 transition-colors">
              <div className="flex items-center gap-2.5">
                <div className="w-6 h-6 rounded-full bg-black text-white text-[11px] font-black flex items-center justify-center shrink-0">
                  2
                </div>
                <h5 className="text-xs sm:text-sm font-black text-slate-900">
                  Instant Photometric Lighting Normalization
                </h5>
              </div>
              <p className="text-xs text-slate-600 pl-8">
                The embedded CV vision engine reads the 5 reference color patches (White, Cyan, Magenta, Yellow, Black) to calculate chromatic gains. This automatically eliminates variable lighting interference (direct sunlight, fluorescent tubes, or low-light industrial bulbs).
              </p>
            </div>

            {/* Step 3 */}
            <div className="rounded-2xl bg-white border border-slate-200/80 p-4 shadow-2xs space-y-2 hover:border-slate-300 transition-colors">
              <div className="flex items-center gap-2.5">
                <div className="w-6 h-6 rounded-full bg-black text-white text-[11px] font-black flex items-center justify-center shrink-0">
                  3
                </div>
                <h5 className="text-xs sm:text-sm font-black text-slate-900">
                  Assign to Worker &amp; Verify Shift Limits
                </h5>
              </div>
              <p className="text-xs text-slate-600 pl-8">
                Select the worker profile from the dropdown before confirming the scan. The app automatically calculates cumulative 8-hour Time-Weighted Average (TWA) dose against the regulatory 10.0 ppm·h shift limit.
              </p>
            </div>

            {/* Step 4 */}
            <div className="rounded-2xl bg-white border border-slate-200/80 p-4 shadow-2xs space-y-2 hover:border-slate-300 transition-colors">
              <div className="flex items-center gap-2.5">
                <div className="w-6 h-6 rounded-full bg-black text-white text-[11px] font-black flex items-center justify-center shrink-0">
                  4
                </div>
                <h5 className="text-xs sm:text-sm font-black text-slate-900">
                  Understand Hazard Classification Indicators
                </h5>
              </div>
              <div className="pl-8 grid grid-cols-1 sm:grid-cols-3 gap-2 pt-1">
                <div className="p-2.5 rounded-xl bg-emerald-50 border border-emerald-200 text-emerald-950">
                  <span className="text-[10px] font-black uppercase text-emerald-700 block">Safe (&lt;5 ppm·h)</span>
                  <span className="text-xs font-semibold">Routine operations continue normally.</span>
                </div>
                <div className="p-2.5 rounded-xl bg-amber-50 border border-amber-200 text-amber-950">
                  <span className="text-[10px] font-black uppercase text-amber-700 block">Moderate (5–10 ppm·h)</span>
                  <span className="text-xs font-semibold">Precautionary rotation suggested.</span>
                </div>
                <div className="p-2.5 rounded-xl bg-rose-50 border border-rose-200 text-rose-950">
                  <span className="text-[10px] font-black uppercase text-rose-700 block">High Risk (&gt;10 ppm·h)</span>
                  <span className="text-xs font-semibold">Immediate evacuation &amp; medical review.</span>
                </div>
              </div>
            </div>

            {/* Step 5 */}
            <div className="rounded-2xl bg-white border border-slate-200/80 p-4 shadow-2xs space-y-2 hover:border-slate-300 transition-colors">
              <div className="flex items-center gap-2.5">
                <div className="w-6 h-6 rounded-full bg-black text-white text-[11px] font-black flex items-center justify-center shrink-0">
                  5
                </div>
                <h5 className="text-xs sm:text-sm font-black text-slate-900">
                  Audit Logs &amp; Regulatory Compliance Reports
                </h5>
              </div>
              <p className="text-xs text-slate-600 pl-8">
                Every scan is stored in the <strong>Feed</strong> with optical photos and environmental telemetry. Tap the <strong>Download CSV</strong> button in the Exposure Feed to generate compliant occupational safety audit reports.
              </p>
            </div>
          </div>

          {/* Divider */}
          <div className="border-t border-slate-200 pt-6">
            {/* DEVELOPER SECTION (Matching Reference Image 2) */}
            <div className="flex flex-col items-center text-center space-y-4">
              {/* Hexavolt Logo in Rounded Container */}
              <div className="relative p-5 rounded-3xl bg-white border border-purple-100 shadow-[0_10px_35px_rgba(124,58,237,0.08)] flex items-center justify-center">
                <HexavoltLogo size={145} showText={true} className="drop-shadow-xs" />
              </div>

              {/* Developer Tag */}
              <div className="inline-flex items-center gap-1.5 px-3.5 py-1 rounded-full bg-purple-100/80 text-purple-900 border border-purple-200 text-xs font-bold uppercase tracking-wider shadow-2xs">
                <Zap className="w-3.5 h-3.5 text-purple-700 fill-purple-700" />
                <span>DEVELOPED BY HEXAVOLT</span>
              </div>

              {/* Company Mission Statement */}
              <p className="text-xs sm:text-sm text-slate-600 max-w-md font-medium leading-relaxed">
                Pioneering smart industrial safety systems, intelligent environmental dosimeters, and cutting-edge sensor telemetry software.
              </p>

              {/* Tech Matrix 2x2 (CV Vision Engine, H2S Dosimetry, Real-time Telemetry, High-FPS UI) */}
              <div className="w-full grid grid-cols-1 sm:grid-cols-2 gap-2.5 text-left pt-1">
                <div className="p-3 rounded-2xl bg-slate-50 border border-slate-200/70 flex items-start gap-2.5">
                  <div className="w-8 h-8 rounded-xl bg-purple-100 text-purple-700 flex items-center justify-center shrink-0 mt-0.5">
                    <Cpu className="w-4 h-4" />
                  </div>
                  <div>
                    <h5 className="text-xs font-bold text-slate-900 font-mono">CV Vision Engine</h5>
                    <p className="text-[11px] text-slate-500">Photometric colorimetric analysis</p>
                  </div>
                </div>

                <div className="p-3 rounded-2xl bg-slate-50 border border-slate-200/70 flex items-start gap-2.5">
                  <div className="w-8 h-8 rounded-xl bg-indigo-100 text-indigo-700 flex items-center justify-center shrink-0 mt-0.5">
                    <Shield className="w-4 h-4" />
                  </div>
                  <div>
                    <h5 className="text-xs font-bold text-slate-900 font-mono">H₂S Dosimetry</h5>
                    <p className="text-[11px] text-slate-500">Fick&apos;s diffusion modeling</p>
                  </div>
                </div>

                <div className="p-3 rounded-2xl bg-slate-50 border border-slate-200/70 flex items-start gap-2.5">
                  <div className="w-8 h-8 rounded-xl bg-blue-100 text-blue-700 flex items-center justify-center shrink-0 mt-0.5">
                    <Sparkles className="w-4 h-4" />
                  </div>
                  <div>
                    <h5 className="text-xs font-bold text-slate-900 font-mono">Real-time Telemetry</h5>
                    <p className="text-[11px] text-slate-500">Zero-power sensor syncing</p>
                  </div>
                </div>

                <div className="p-3 rounded-2xl bg-slate-50 border border-slate-200/70 flex items-start gap-2.5">
                  <div className="w-8 h-8 rounded-xl bg-emerald-100 text-emerald-700 flex items-center justify-center shrink-0 mt-0.5">
                    <Code2 className="w-4 h-4" />
                  </div>
                  <div>
                    <h5 className="text-xs font-bold text-slate-900 font-mono">High-FPS UI</h5>
                    <p className="text-[11px] text-slate-500">Mobile-optimized GPU rendering</p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Modal Action Button */}
        <div className="pt-2">
          <button
            id="about-modal-continue-btn"
            onClick={onClose}
            type="button"
            className="w-full py-3.5 px-4 rounded-2xl bg-gradient-to-r from-blue-600 to-indigo-600 hover:from-blue-700 hover:to-indigo-700 text-white font-bold text-xs sm:text-sm shadow-md active:scale-[0.98] transition-all cursor-pointer"
          >
            CONTINUE
          </button>
        </div>
      </div>
    </div>
  );
};
