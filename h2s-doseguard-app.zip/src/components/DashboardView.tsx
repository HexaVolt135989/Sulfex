import React, { useMemo, memo } from 'react';
import {
  LayoutDashboard,
  Users,
  Activity,
  AlertTriangle,
  Clock,
  TrendingUp,
  ShieldAlert,
  ShieldCheck,
  CheckCircle2,
  FileSpreadsheet,
  ArrowLeft,
} from 'lucide-react';
import {
  LineChart,
  Line,
  BarChart,
  Bar,
  PieChart,
  Pie,
  Cell,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
  ResponsiveContainer,
} from 'recharts';
import { ExposureScanRecord, WorkerProfile } from '../types';

interface DashboardViewProps {
  workers: WorkerProfile[];
  scans: ExposureScanRecord[];
  onBack?: () => void;
}

export const DashboardView: React.FC<DashboardViewProps> = memo(({ workers, scans, onBack }) => {
  // Aggregate Metrics memoized
  const {
    totalScans,
    activeWorkers,
    highExposureCases,
    moderateExposureCases,
    lowExposureCases,
    avgEstimatedExposure,
  } = useMemo(() => {
    const total = scans.length;
    const active = workers.length;
    const high = scans.filter((s) => s.riskLevel === 'HIGH').length;
    const moderate = scans.filter((s) => s.riskLevel === 'MODERATE').length;
    const low = scans.filter((s) => s.riskLevel === 'LOW').length;
    const avg = total > 0
      ? (scans.reduce((sum, s) => sum + s.estimatedDose, 0) / total).toFixed(1)
      : '0.0';

    return {
      totalScans: total,
      activeWorkers: active,
      highExposureCases: high,
      moderateExposureCases: moderate,
      lowExposureCases: low,
      avgEstimatedExposure: avg,
    };
  }, [scans, workers]);

  // 1. Chart Data: Exposure vs Date (Chronological)
  const exposureVsDateData = useMemo(() => {
    const sorted = [...scans].sort(
      (a, b) => new Date(a.timestamp).getTime() - new Date(b.timestamp).getTime()
    );
    return sorted.map((s) => ({
      date: new Date(s.timestamp).toLocaleDateString('en-GB', { day: '2-digit', month: 'short' }),
      dose: s.estimatedDose,
      worker: s.workerId,
      risk: s.riskLevel,
    }));
  }, [scans]);

  // 2. Chart Data: Exposure by Worker
  const exposureByWorkerData = useMemo(() => {
    return workers.map((w) => {
      const workerScans = scans.filter((s) => s.workerId === w.id);
      const maxDose = workerScans.length > 0 ? Math.max(...workerScans.map((s) => s.estimatedDose)) : 0;
      const avgDose = workerScans.length > 0
        ? parseFloat((workerScans.reduce((acc, s) => acc + s.estimatedDose, 0) / workerScans.length).toFixed(1))
        : 0;

      return {
        workerId: w.id,
        name: w.name.split(' ')[0], // first name for clean axis
        cumulative: w.cumulativeExposurePpmH,
        maxScan: maxDose,
        avgScan: avgDose,
        scansCount: workerScans.length,
      };
    });
  }, [workers, scans]);

  // 3. Chart Data: Risk Distribution (Donut)
  const riskDistributionData = useMemo(() => {
    return [
      { name: 'Low Risk (<10 ppm·h)', value: lowExposureCases, color: '#10b981' },
      { name: 'Moderate Risk (10-25 ppm·h)', value: moderateExposureCases, color: '#f59e0b' },
      { name: 'High Risk (>25 ppm·h)', value: highExposureCases, color: '#ef4444' },
    ].filter((d) => d.value > 0);
  }, [lowExposureCases, moderateExposureCases, highExposureCases]);

  // 4. Shift Comparison Data
  const shiftData = useMemo(() => {
    return ['Morning', 'Afternoon', 'Night'].map((shiftName) => {
      const shiftScans = scans.filter((s) => s.shift === shiftName);
      const avgDose = shiftScans.length > 0
        ? parseFloat((shiftScans.reduce((acc, s) => acc + s.estimatedDose, 0) / shiftScans.length).toFixed(1))
        : 0;

      return {
        shift: shiftName,
        scans: shiftScans.length,
        avgExposure: avgDose,
      };
    });
  }, [scans]);

  return (
    <div className="space-y-6 pb-24 max-w-4xl mx-auto px-4 sm:px-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-xl sm:text-2xl font-black text-slate-900 tracking-tight">
            Safety Analytics
          </h2>
          <p className="text-xs font-medium text-slate-500">
            Real-time passive colorimetric H2S dosimeter exposure telemetry
          </p>
        </div>

        <span className="text-xs px-3 py-1.5 rounded-full bg-[#DCFCE7] text-emerald-900 border border-emerald-200/80 font-bold flex items-center gap-1.5 shadow-2xs">
          <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse" />
          Active Shift
        </span>
      </div>

      {/* Safety Alert Banner if High Risk Cases Detected */}
      {highExposureCases > 0 && (
        <div className="bg-[#FEE2E2] border border-rose-200 rounded-[28px] p-5 flex items-start gap-3.5 text-rose-950 shadow-2xs">
          <div className="w-10 h-10 rounded-full bg-rose-100 text-rose-600 flex items-center justify-center shrink-0">
            <AlertTriangle className="w-5 h-5" />
          </div>
          <div className="space-y-1">
            <h4 className="font-black text-rose-950 text-sm">
              Immediate Attention: {highExposureCases} High Exposure Incident(s)
            </h4>
            <p className="text-xs text-rose-900/80 leading-relaxed font-medium">
              One or more workers recorded cumulative H2S exposure exceeding prototype safety threshold (25.0 ppm·h). Initiate area gas verification.
            </p>
          </div>
        </div>
      )}

      {/* 5 Core Pastel KPI Cards (Matching Bento Grid Aesthetic) */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
        {/* Card 1: Sky Blue (Active Workers) */}
        <div className="bg-[#E0F2FE] border border-sky-200/60 rounded-[28px] p-4.5 shadow-[0_4px_16px_rgba(56,189,248,0.06)]">
          <div className="flex items-center justify-between text-sky-900 text-xs font-extrabold mb-1">
            <span>Workers</span>
            <Users className="w-4 h-4 text-sky-700" />
          </div>
          <div className="text-2xl font-black font-mono text-sky-950">{activeWorkers}</div>
          <div className="text-[11px] text-sky-800 font-semibold mt-0.5">Assigned badges</div>
        </div>

        {/* Card 2: Mint Green (Safe Cases) */}
        <div className="bg-[#DCFCE7] border border-emerald-200/60 rounded-[28px] p-4.5 shadow-[0_4px_16px_rgba(74,222,128,0.06)]">
          <div className="flex items-center justify-between text-emerald-900 text-xs font-extrabold mb-1">
            <span>Safe Doses</span>
            <ShieldCheck className="w-4 h-4 text-emerald-700" />
          </div>
          <div className="text-2xl font-black font-mono text-emerald-950">{lowExposureCases}</div>
          <div className="text-[11px] text-emerald-800 font-semibold mt-0.5">&lt;10 ppm·h limits</div>
        </div>

        {/* Card 3: Warm Peach (Avg Exposure) */}
        <div className="bg-[#FFEADC] border border-amber-200/60 rounded-[28px] p-4.5 shadow-[0_4px_16px_rgba(251,146,60,0.06)]">
          <div className="flex items-center justify-between text-amber-900 text-xs font-extrabold mb-1">
            <span>Avg Exposure</span>
            <TrendingUp className="w-4 h-4 text-amber-700" />
          </div>
          <div className="text-2xl font-black font-mono text-amber-950">{avgEstimatedExposure} <span className="text-xs font-semibold text-amber-800">ppm·h</span></div>
          <div className="text-[11px] text-amber-800 font-semibold mt-0.5">Plant-wide mean</div>
        </div>

        {/* Card 4: Soft Rose or White (High Alerts) */}
        <div className={`rounded-[28px] p-4.5 border shadow-[0_4px_16px_rgba(15,23,42,0.03)] ${
          highExposureCases > 0
            ? 'bg-[#FEE2E2] border-rose-200 text-rose-950'
            : 'bg-white border-slate-200/80 text-slate-900'
        }`}>
          <div className="flex items-center justify-between text-xs font-extrabold mb-1">
            <span>High Risk</span>
            <AlertTriangle className={`w-4 h-4 ${highExposureCases > 0 ? 'text-rose-600' : 'text-slate-400'}`} />
          </div>
          <div className={`text-2xl font-black font-mono ${highExposureCases > 0 ? 'text-rose-600' : 'text-slate-900'}`}>
            {highExposureCases}
          </div>
          <div className="text-[11px] text-slate-500 font-semibold mt-0.5">&gt;25 ppm·h cases</div>
        </div>
      </div>

      {/* Industrial Recharts Section */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* 1. Chart: Exposure vs Date */}
        <div className="bg-white border border-slate-200/80 rounded-[28px] p-5 shadow-[0_4px_20px_rgba(15,23,42,0.03)] space-y-3">
          <div className="flex items-center justify-between border-b border-slate-200 pb-2.5">
            <div>
              <h3 className="text-xs font-bold text-slate-900 uppercase tracking-wider">
                1. Cumulative Exposure vs. Date Trend
              </h3>
              <p className="text-[10px] text-slate-500 font-medium">Time-series tracking of worker dosimeter scans</p>
            </div>
            <span className="text-[10px] font-mono text-orange-700 bg-orange-50 px-2 py-0.5 rounded border border-orange-200 font-bold">
              Thresholds: 10 / 25 ppm·h
            </span>
          </div>

          <div className="h-64 w-full">
            {exposureVsDateData.length === 0 ? (
              <div className="h-full flex items-center justify-center text-xs text-slate-400 font-medium">
                No scan data available for timeline
              </div>
            ) : (
              <ResponsiveContainer width="100%" height="100%">
                <LineChart data={exposureVsDateData} margin={{ top: 10, right: 10, left: -20, bottom: 0 }}>
                  <CartesianGrid strokeDasharray="3 3" stroke="#e2e8f0" opacity={0.8} />
                  <XAxis dataKey="date" stroke="#64748b" fontSize={11} tickLine={false} />
                  <YAxis stroke="#64748b" fontSize={11} tickLine={false} />
                  <Tooltip
                    contentStyle={{ backgroundColor: '#ffffff', borderColor: '#cbd5e1', borderRadius: '8px', fontSize: '12px', boxShadow: '0 4px 6px -1px rgb(0 0 0 / 0.1)' }}
                    labelStyle={{ color: '#0f172a', fontWeight: 'bold' }}
                    formatter={(val: any) => [`${val} ppm·h`, 'Estimated Dose']}
                  />
                  <Line
                    type="monotone"
                    dataKey="dose"
                    name="Dose (ppm·h)"
                    stroke="#ea580c"
                    strokeWidth={2.5}
                    dot={{ fill: '#ea580c', r: 4 }}
                    activeDot={{ r: 6, stroke: '#ffffff', strokeWidth: 2 }}
                  />
                </LineChart>
              </ResponsiveContainer>
            )}
          </div>
        </div>

        {/* 2. Chart: Exposure by Worker */}
        <div className="bg-white border border-slate-200/80 rounded-[28px] p-5 shadow-[0_4px_20px_rgba(15,23,42,0.03)] space-y-3">
          <div className="flex items-center justify-between border-b border-slate-200 pb-2.5">
            <div>
              <h3 className="text-xs font-bold text-slate-900 uppercase tracking-wider">
                2. Cumulative Exposure by Worker
              </h3>
              <p className="text-[10px] text-slate-500 font-medium">Total cumulative dose comparison (ppm·h)</p>
            </div>
            <span className="text-[10px] text-slate-500 font-semibold">By Worker ID</span>
          </div>

          <div className="h-64 w-full">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={exposureByWorkerData} margin={{ top: 10, right: 10, left: -20, bottom: 0 }}>
                <CartesianGrid strokeDasharray="3 3" stroke="#e2e8f0" opacity={0.8} />
                <XAxis dataKey="workerId" stroke="#64748b" fontSize={11} tickLine={false} />
                <YAxis stroke="#64748b" fontSize={11} tickLine={false} />
                <Tooltip
                  contentStyle={{ backgroundColor: '#ffffff', borderColor: '#cbd5e1', borderRadius: '8px', fontSize: '12px', boxShadow: '0 4px 6px -1px rgb(0 0 0 / 0.1)' }}
                  labelStyle={{ color: '#0f172a', fontWeight: 'bold' }}
                  formatter={(val: any) => [`${val} ppm·h`, 'Cumulative Exposure']}
                />
                <Bar dataKey="cumulative" name="Cumulative Dose" fill="#0284c7" radius={[4, 4, 0, 0]}>
                  {exposureByWorkerData.map((entry, index) => (
                    <Cell
                      key={`cell-${index}`}
                      fill={entry.cumulative > 25 ? '#ef4444' : entry.cumulative > 10 ? '#f59e0b' : '#ea580c'}
                    />
                  ))}
                </Bar>
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* 3. Chart: Low / Moderate / High Risk Distribution */}
        <div className="bg-white border border-slate-200/80 rounded-[28px] p-5 shadow-[0_4px_20px_rgba(15,23,42,0.03)] space-y-3">
          <div className="flex items-center justify-between border-b border-slate-200 pb-2.5">
            <div>
              <h3 className="text-xs font-bold text-slate-900 uppercase tracking-wider">
                3. Risk Classification Distribution
              </h3>
              <p className="text-[10px] text-slate-500 font-medium">Proportion of scan results by severity tier</p>
            </div>
            <span className="text-[10px] text-slate-500 font-semibold">{totalScans} total scans</span>
          </div>

          <div className="h-64 w-full flex items-center justify-center">
            {riskDistributionData.length === 0 ? (
              <div className="text-xs text-slate-400 font-medium">No scans recorded</div>
            ) : (
              <ResponsiveContainer width="100%" height="100%">
                <PieChart>
                  <Pie
                    data={riskDistributionData}
                    cx="50%"
                    cy="50%"
                    innerRadius={60}
                    outerRadius={85}
                    paddingAngle={4}
                    dataKey="value"
                  >
                    {riskDistributionData.map((entry, index) => (
                      <Cell key={`cell-${index}`} fill={entry.color} />
                    ))}
                  </Pie>
                  <Tooltip
                    contentStyle={{ backgroundColor: '#ffffff', borderColor: '#cbd5e1', borderRadius: '8px', fontSize: '12px', boxShadow: '0 4px 6px -1px rgb(0 0 0 / 0.1)' }}
                  />
                  <Legend
                    verticalAlign="bottom"
                    height={36}
                    formatter={(value) => <span className="text-[11px] text-slate-700 font-medium">{value}</span>}
                  />
                </PieChart>
              </ResponsiveContainer>
            )}
          </div>
        </div>

        {/* 4. Chart: Shift Comparison */}
        <div className="bg-white border border-slate-200/80 rounded-[28px] p-5 shadow-[0_4px_20px_rgba(15,23,42,0.03)] space-y-3">
          <div className="flex items-center justify-between border-b border-slate-200 pb-2.5">
            <div>
              <h3 className="text-xs font-bold text-slate-900 uppercase tracking-wider">
                4. Shift Exposure Comparison
              </h3>
              <p className="text-[10px] text-slate-500 font-medium">Mean estimated exposure by work shift</p>
            </div>
            <span className="text-[10px] text-slate-500 font-semibold">Morning / Afternoon / Night</span>
          </div>

          <div className="h-64 w-full">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={shiftData} margin={{ top: 10, right: 10, left: -20, bottom: 0 }}>
                <CartesianGrid strokeDasharray="3 3" stroke="#e2e8f0" opacity={0.8} />
                <XAxis dataKey="shift" stroke="#64748b" fontSize={11} tickLine={false} />
                <YAxis stroke="#64748b" fontSize={11} tickLine={false} />
                <Tooltip
                  contentStyle={{ backgroundColor: '#ffffff', borderColor: '#cbd5e1', borderRadius: '8px', fontSize: '12px', boxShadow: '0 4px 6px -1px rgb(0 0 0 / 0.1)' }}
                  labelStyle={{ color: '#0f172a', fontWeight: 'bold' }}
                />
                <Bar dataKey="avgExposure" name="Avg Dose (ppm·h)" fill="#ea580c" radius={[4, 4, 0, 0]} />
                <Bar dataKey="scans" name="Scans Count" fill="#3B82F6" radius={[4, 4, 0, 0]} />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>
      </div>
    </div>
  );
});
