import React from 'react';
import { ColorimetricAnalysis } from '../types';
import { Sparkles, Sun, CheckCircle, AlertTriangle, Eye, ShieldCheck, Activity } from 'lucide-react';

interface ImageAnalysisOverlayProps {
  analysis: ColorimetricAnalysis;
  onClose?: () => void;
}

export const ImageAnalysisOverlay: React.FC<ImageAnalysisOverlayProps> = ({ analysis, onClose }) => {
  const {
    detectedPatches,
    sensingStrip,
    expiryPatch,
    lightingCorrection,
    qualityScore,
    qualityIssues,
    imageQuality,
    colorIndex,
    estimatedDose,
    tempCorrectionFactor,
    humidityCorrectionFactor,
  } = analysis;

  return (
    <div className="bg-white border border-slate-200 rounded-xl p-4 text-slate-800 space-y-4 shadow-md">
      {/* Title */}
      <div className="flex items-center justify-between border-b border-slate-200 pb-3">
        <div className="flex items-center gap-2">
          <Activity className="w-5 h-5 text-orange-600" />
          <h3 className="text-sm font-bold text-slate-900 uppercase tracking-wider font-mono">
            Colorimetry & Optical Analysis Breakdown
          </h3>
        </div>
        {onClose && (
          <button
            onClick={onClose}
            className="text-xs text-slate-600 hover:text-slate-900 font-semibold px-2.5 py-1 bg-slate-100 hover:bg-slate-200 border border-slate-300 rounded-lg transition-colors"
          >
            Close
          </button>
        )}
      </div>

      {/* 1. Chemical Sensing Strip Photometric Extraction */}
      <div className="space-y-2">
        <div className="flex items-center justify-between text-xs font-bold text-slate-700">
          <span>Chemical Sensing Strip Colorimetry</span>
          <span className="font-mono text-orange-600 font-bold">Index: {colorIndex.toFixed(3)}</span>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 bg-slate-50 p-3 rounded-lg border border-slate-200 text-xs">
          <div className="flex items-center gap-3">
            <div className="space-y-1">
              <span className="text-[10px] text-slate-500 uppercase font-bold block">Raw RGB</span>
              <div
                className="w-10 h-10 rounded border border-slate-300 shadow-inner"
                style={{ backgroundColor: `rgb(${sensingStrip.rawRgb.join(',')})` }}
              />
              <span className="text-[10px] font-mono text-slate-600 font-medium">
                [{sensingStrip.rawRgb.join(',')}]
              </span>
            </div>
            <div className="space-y-1">
              <span className="text-[10px] text-orange-700 uppercase block font-bold">Normalized RGB</span>
              <div
                className="w-10 h-10 rounded border border-orange-400 shadow-inner ring-2 ring-orange-200"
                style={{ backgroundColor: `rgb(${sensingStrip.normalizedRgb.join(',')})` }}
              />
              <span className="text-[10px] font-mono text-orange-700 font-bold">
                {sensingStrip.hex}
              </span>
            </div>
          </div>

          <div className="space-y-1 font-mono text-[11px] text-slate-700">
            <div>CIE L*a*b*: <span className="text-slate-900 font-bold">[{sensingStrip.lab.join(', ')}]</span></div>
            <div>CIEDE2000 ΔE: <span className="text-cyan-700 font-bold">{sensingStrip.deltaEFromBaseline}</span> (from base)</div>
            <div>Optical Absorbance: <span className="text-amber-800 font-bold">{sensingStrip.absorbanceRatio}</span></div>
            <div>HSV: <span className="text-slate-600">[{sensingStrip.hsv[0]}°, {(sensingStrip.hsv[1]*100).toFixed(0)}%, {(sensingStrip.hsv[2]*100).toFixed(0)}%]</span></div>
          </div>
        </div>
      </div>

      {/* 2. Detected 5 Reference Patches & Calibration Fit */}
      <div className="space-y-2">
        <div className="flex items-center justify-between text-xs font-bold text-slate-700">
          <span>Printed Reference Scale Calibration</span>
          <span className="text-[11px] text-slate-500 font-medium">Von Kries Photometric Matrix</span>
        </div>

        <div className="grid grid-cols-5 gap-1.5 bg-slate-50 p-2.5 rounded-lg border border-slate-200">
          {detectedPatches.map((p, idx) => (
            <div key={idx} className="flex flex-col items-center space-y-1 text-center">
              <span className="text-[10px] text-slate-600 font-bold truncate w-full">{p.name.replace('Ref ', '')}</span>
              <div
                className="w-full h-7 rounded border border-slate-300 shadow-inner"
                style={{ backgroundColor: `rgb(${p.measuredRgb.join(',')})` }}
                title={`Measured: rgb(${p.measuredRgb.join(',')}) | Expected: rgb(${p.expectedRgb.join(',')})`}
              />
              <span className="text-[9px] font-mono text-slate-600 font-medium">ΔE {p.deltaE}</span>
            </div>
          ))}
        </div>
      </div>

      {/* 3. Lighting & Optical Normalization Parameters */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 text-xs">
        <div className="bg-slate-50 p-2.5 rounded-lg border border-slate-200">
          <span className="text-[10px] text-slate-500 font-bold block">RGB Gains [R/G/B]</span>
          <span className="font-mono font-bold text-slate-900">
            {lightingCorrection.rGain} / {lightingCorrection.gGain} / {lightingCorrection.bGain}
          </span>
        </div>

        <div className="bg-slate-50 p-2.5 rounded-lg border border-slate-200">
          <span className="text-[10px] text-slate-500 font-bold block">Ambient Luminance</span>
          <span className="font-mono font-bold text-slate-900">
            ~{lightingCorrection.ambientLuxProxy} lux proxy
          </span>
        </div>

        <div className="bg-slate-50 p-2.5 rounded-lg border border-slate-200">
          <span className="text-[10px] text-slate-500 font-bold block">Color Temperature</span>
          <span className="font-mono font-bold text-cyan-700">
            ~{lightingCorrection.colorTemperatureEstimate} K
          </span>
        </div>

        <div className="bg-slate-50 p-2.5 rounded-lg border border-slate-200">
          <span className="text-[10px] text-slate-500 font-bold block">Lighting Uniformity</span>
          <span className="font-mono font-bold text-emerald-700">
            {lightingCorrection.uniformityScore}%
          </span>
        </div>
      </div>

      {/* 4. Expiry & Environmental Factor Adjustments */}
      <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 text-xs">
        <div className="bg-slate-50 p-2.5 rounded-lg border border-slate-200 flex items-center justify-between">
          <div>
            <span className="text-[10px] text-slate-500 font-bold block">Control Patch Integrity</span>
            <span className={`font-bold uppercase text-xs ${expiryPatch.status === 'EXPIRED' ? 'text-rose-700' : 'text-emerald-700'}`}>
              {expiryPatch.status}
            </span>
          </div>
          <div
            className="w-6 h-6 rounded border border-slate-300 shadow-inner"
            style={{ backgroundColor: `rgb(${expiryPatch.normalizedRgb.join(',')})` }}
          />
        </div>

        <div className="bg-slate-50 p-2.5 rounded-lg border border-slate-200">
          <span className="text-[10px] text-slate-500 font-bold block">Environmental Factors</span>
          <span className="font-mono text-slate-800 text-[11px] font-medium">
            Temp Factor: {tempCorrectionFactor}x | RH Factor: {humidityCorrectionFactor}x
          </span>
        </div>
      </div>

      {/* Quality Issues if any */}
      {qualityIssues.length > 0 && (
        <div className="bg-amber-50 border border-amber-300 rounded-lg p-2.5 text-xs text-amber-900 space-y-1">
          <span className="font-bold flex items-center gap-1 text-[11px] uppercase">
            <AlertTriangle className="w-3.5 h-3.5 text-amber-600" />
            Image Quality Advisory
          </span>
          <ul className="list-disc list-inside text-amber-800 text-[11px] space-y-0.5 font-medium">
            {qualityIssues.map((issue, idx) => (
              <li key={idx}>{issue}</li>
            ))}
          </ul>
        </div>
      )}
    </div>
  );
};
