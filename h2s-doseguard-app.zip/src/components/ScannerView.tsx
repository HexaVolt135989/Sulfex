import React, { useState, useRef, useEffect } from 'react';
import {
  Camera,
  Upload,
  RotateCcw,
  Sparkles,
  AlertTriangle,
  CheckCircle,
  User,
  Clock,
  Thermometer,
  Droplets,
  ScanLine,
  ArrowRight,
  ArrowLeft,
  RefreshCw,
  Zap,
  Info,
  SwitchCamera,
  Sliders,
  ChevronRight,
  Shield,
  Layers,
} from 'lucide-react';
import {
  ActiveTab,
  AdminCalibrationConfig,
  ExposureScanRecord,
  ShiftType,
  WorkerProfile,
} from '../types';
import { analyzeWristbandImage } from '../services/imageAnalysisEngine';
import { SAMPLE_BADGES, SampleBadgeSpec, generateSampleBadgeDataUrl } from '../services/sampleWristbandGenerator';
import { ResultCard } from './ResultCard';
import { SpecularButton } from './SpecularButton';

interface ScannerViewProps {
  workers: WorkerProfile[];
  config: AdminCalibrationConfig;
  onSaveScan: (scan: ExposureScanRecord) => void;
  setActiveTab: (tab: ActiveTab) => void;
  onBack?: () => void;
  preSelectedSample?: SampleBadgeSpec | null;
  onClearPreSelectedSample?: () => void;
  envTemp: number;
  envHumidity: number;
}

export const ScannerView: React.FC<ScannerViewProps> = ({
  workers,
  config,
  onSaveScan,
  setActiveTab,
  onBack,
  preSelectedSample,
  onClearPreSelectedSample,
  envTemp,
  envHumidity,
}) => {
  // Step State: Direct capture/upload by default (Step 3), Preview/Align (Step 4), Result (Step 5)
  const [step, setStep] = useState<1 | 2 | 3 | 4 | 5>(3);
  const [showWorkerConfig, setShowWorkerConfig] = useState<boolean>(false);

  // Form State
  const [selectedWorkerId, setSelectedWorkerId] = useState<string>(workers[0]?.id || 'W102');
  const [customWorkerId, setCustomWorkerId] = useState<string>('');
  const [workerName, setWorkerName] = useState<string>(workers[0]?.name || 'Marcus Vance');
  const [department, setDepartment] = useState<string>(workers[0]?.department || 'Plant Maintenance');
  const [shift, setShift] = useState<ShiftType>('Morning');
  
  // Environmental Settings
  const [useEnvCompensation, setUseEnvCompensation] = useState<boolean>(true);
  const [temperature, setTemperature] = useState<number>(envTemp);
  const [humidity, setHumidity] = useState<number>(envHumidity);

  // Camera & Image State
  const [isCameraActive, setIsCameraActive] = useState<boolean>(false);
  const [isVideoReady, setIsVideoReady] = useState<boolean>(false);
  const [facingMode, setFacingMode] = useState<'environment' | 'user'>('environment');
  const [capturedImageDataUrl, setCapturedImageDataUrl] = useState<string | null>(null);
  const [isAnalyzing, setIsAnalyzing] = useState<boolean>(false);
  const [analysisError, setAnalysisError] = useState<string | null>(null);
  const [currentResult, setCurrentResult] = useState<ExposureScanRecord | null>(null);
  const [isDemoBadge, setIsDemoBadge] = useState<boolean>(false);

  // Refs
  const videoRef = useRef<HTMLVideoElement | null>(null);
  const streamRef = useRef<MediaStream | null>(null);
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const fileInputRef = useRef<HTMLInputElement | null>(null);

  // Sync environmental prop changes if not manually edited
  useEffect(() => {
    if (useEnvCompensation) {
      setTemperature(envTemp);
      setHumidity(envHumidity);
    }
  }, [envTemp, envHumidity, useEnvCompensation]);

  // Handle worker selection
  const handleWorkerSelect = (id: string) => {
    setSelectedWorkerId(id);
    if (id === 'NEW') {
      setWorkerName('');
      setDepartment('General Operations');
    } else {
      const found = workers.find(w => w.id === id);
      if (found) {
        setWorkerName(found.name);
        setDepartment(found.department);
        setShift(found.shift);
      }
    }
  };

  // If a sample badge was selected from Home or Modal
  useEffect(() => {
    if (preSelectedSample) {
      const dataUrl = generateSampleBadgeDataUrl(preSelectedSample);
      setCapturedImageDataUrl(dataUrl);
      setIsDemoBadge(true);
      setStep(4);
      if (onClearPreSelectedSample) {
        onClearPreSelectedSample();
      }
    }
  }, [preSelectedSample, onClearPreSelectedSample]);

  // Stop camera stream helper
  const stopCameraStream = () => {
    if (streamRef.current) {
      streamRef.current.getTracks().forEach(track => {
        try {
          track.stop();
        } catch (e) {
          console.warn('Error stopping track:', e);
        }
      });
      streamRef.current = null;
    }
    if (videoRef.current) {
      videoRef.current.srcObject = null;
    }
    setIsCameraActive(false);
    setIsVideoReady(false);
  };

  const [hasTorch, setHasTorch] = useState<boolean>(false);
  const [isTorchOn, setIsTorchOn] = useState<boolean>(false);

  // Dedicated Effect to attach and run camera stream when isCameraActive or facingMode changes
  useEffect(() => {
    let cancelled = false;
    let currentStream: MediaStream | null = null;

    if (isCameraActive) {
      setIsVideoReady(false);
      setAnalysisError(null);

      const initCamera = async () => {
        try {
          // 1. Try rear/front facing mode with ideal resolution
          let stream: MediaStream | null = null;
          try {
            stream = await navigator.mediaDevices.getUserMedia({
              video: {
                facingMode: { ideal: facingMode },
                width: { ideal: 1280 },
                height: { ideal: 720 },
              },
              audio: false,
            });
          } catch (modeErr) {
            console.warn('Specific facingMode constraint failed, trying basic video:', modeErr);
            // 2. Fallback to any available video input
            stream = await navigator.mediaDevices.getUserMedia({
              video: true,
              audio: false,
            });
          }

          if (cancelled) {
            stream.getTracks().forEach(t => t.stop());
            return;
          }

          currentStream = stream;
          streamRef.current = stream;

          // Check torch capability
          try {
            const track = stream.getVideoTracks()[0];
            const capabilities = track?.getCapabilities?.() as any;
            setHasTorch(Boolean(capabilities?.torch));
          } catch {
            setHasTorch(false);
          }

          if (videoRef.current) {
            videoRef.current.srcObject = stream;
            // Play video stream
            const playPromise = videoRef.current.play();
            if (playPromise !== undefined) {
              playPromise
                .then(() => {
                  if (!cancelled) {
                    setIsVideoReady(true);
                  }
                })
                .catch(err => {
                  console.warn('Video play deferred or interrupted:', err);
                });
            }
          }
        } catch (err: any) {
          console.error('Camera access error:', err);
          if (!cancelled) {
            const isPermissionError =
              err.name === 'NotAllowedError' ||
              err.name === 'PermissionDeniedError' ||
              err.name === 'SecurityError';
            setAnalysisError(
              isPermissionError
                ? 'Camera access was blocked by browser permissions. Please allow camera access in the browser URL bar or upload a badge photo below.'
                : 'Could not access the camera device. Please check that no other application is using your webcam, or use photo upload.'
            );
            setIsCameraActive(false);
          }
        }
      };

      initCamera();
    }

    return () => {
      cancelled = true;
      if (currentStream) {
        currentStream.getTracks().forEach(t => t.stop());
      }
    };
  }, [isCameraActive, facingMode]);

  // Start Camera Trigger
  const startCamera = () => {
    setAnalysisError(null);
    setIsCameraActive(true);
  };

  // Switch between front/rear camera
  const toggleCameraFacing = () => {
    setFacingMode(prev => (prev === 'environment' ? 'user' : 'environment'));
  };

  // Toggle flashlight / torch on mobile
  const toggleTorch = async () => {
    if (!streamRef.current) return;
    try {
      const track = streamRef.current.getVideoTracks()[0];
      const nextTorch = !isTorchOn;
      await (track as any).applyConstraints({
        advanced: [{ torch: nextTorch }],
      });
      setIsTorchOn(nextTorch);
    } catch (e) {
      console.warn('Torch toggle not supported or error:', e);
    }
  };

  // Capture current video frame to canvas & data URL
  const captureFrame = () => {
    if (!videoRef.current) return;
    const video = videoRef.current;
    const canvas = document.createElement('canvas');
    const width = video.videoWidth || 640;
    const height = video.videoHeight || 480;
    canvas.width = width;
    canvas.height = height;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    // Flip horizontal if using user facing camera so snapshot is intuitive
    if (facingMode === 'user') {
      ctx.translate(width, 0);
      ctx.scale(-1, 1);
    }

    ctx.drawImage(video, 0, 0, width, height);
    const dataUrl = canvas.toDataURL('image/jpeg', 0.95);
    setCapturedImageDataUrl(dataUrl);
    setIsDemoBadge(false);
    stopCameraStream();
    // Fast instant analysis direct to verdict
    executeDirectAnalysis(dataUrl, false);
  };

  // Handle file upload
  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    if (!file.type.startsWith('image/')) {
      setAnalysisError('Please upload a valid image file (JPEG, PNG, WEBP).');
      return;
    }

    const reader = new FileReader();
    reader.onload = (event) => {
      const dataUrl = event.target?.result as string;
      setCapturedImageDataUrl(dataUrl);
      setIsDemoBadge(false);
      stopCameraStream();
      // Fast instant analysis direct to verdict
      executeDirectAnalysis(dataUrl, false);
    };
    reader.readAsDataURL(file);
  };

  // Handle selection of sample badge
  const handleSelectSample = (sample: SampleBadgeSpec) => {
    const dataUrl = generateSampleBadgeDataUrl(sample);
    setCapturedImageDataUrl(dataUrl);
    setIsDemoBadge(true);
    stopCameraStream();
    // Fast instant analysis direct to verdict
    executeDirectAnalysis(dataUrl, true);
  };

  // Core High-Speed Image Analysis Pipeline (<50ms execution)
  const executeDirectAnalysis = async (dataUrl: string, isDemo: boolean) => {
    setIsAnalyzing(true);
    setAnalysisError(null);

    try {
      // 1. Load image buffer into HTMLImageElement
      const img = new Image();
      img.crossOrigin = 'anonymous';

      await new Promise<void>((resolve, reject) => {
        img.onload = () => resolve();
        img.onerror = () => reject(new Error('Failed to load image buffer into canvas'));
        img.src = dataUrl;
      });

      // 2. Draw image to canvas with willReadFrequently & high-performance downsampling (max 1200px)
      let drawW = img.width || 640;
      let drawH = img.height || 480;
      const maxDim = 1200;
      if (drawW > maxDim || drawH > maxDim) {
        if (drawW > drawH) {
          drawH = Math.round((drawH * maxDim) / drawW);
          drawW = maxDim;
        } else {
          drawW = Math.round((drawW * maxDim) / drawH);
          drawH = maxDim;
        }
      }

      const canvas = document.createElement('canvas');
      canvas.width = drawW;
      canvas.height = drawH;
      const ctx = canvas.getContext('2d', { willReadFrequently: true });
      if (!ctx) throw new Error('Could not initialize canvas context');
      ctx.drawImage(img, 0, 0, drawW, drawH);

      // 3. Run client-side computer vision engine (<10ms)
      const analysis = await analyzeWristbandImage(canvas, {
        config,
        workerId: selectedWorkerId === 'NEW' ? customWorkerId : selectedWorkerId,
        shift,
        temperature: useEnvCompensation ? temperature : undefined,
        humidity: useEnvCompensation ? humidity : undefined,
      });

      // Brief 300ms transition to let the user see the optical scan HUD
      await new Promise(r => setTimeout(r, 320));

      // Check if image quality is severely degraded
      if (analysis.imageQuality === 'POOR' && analysis.confidence < 30) {
        setAnalysisError(
          'Image appears blurry or dark. Please retake photo with even lighting holding the strip steady.'
        );
        setIsAnalyzing(false);
        setStep(4);
        return;
      }

      const activeWorkerId = selectedWorkerId === 'NEW' ? (customWorkerId || 'W-UNASSIGNED') : selectedWorkerId;
      const activeWorkerName = workerName || 'Worker';

      const scanRecord: ExposureScanRecord = {
        id: `scan-${Date.now().toString().slice(-6)}`,
        workerId: activeWorkerId,
        workerName: activeWorkerName,
        department: department || 'Operations',
        shift,
        timestamp: new Date().toISOString(),
        estimatedDose: analysis.estimatedDose,
        riskLevel: analysis.riskLevel,
        confidence: analysis.confidence,
        badgeValidity: analysis.badgeValidity,
        imageQuality: analysis.imageQuality,
        temperature: typeof temperature === 'number' ? temperature : (envTemp ?? 28),
        humidity: typeof humidity === 'number' ? humidity : (envHumidity ?? 55),
        imageDataUrl: dataUrl,
        isDemo: isDemo,
        notes: analysis.rawFeaturesSummary,
        analysisDetails: analysis,
      };

      // Set result instantly and auto-save to ensure 100% data integrity
      setCurrentResult(scanRecord);
      onSaveScan(scanRecord);
      setStep(5);

      // Optional background Gemini enrichment if enabled (non-blocking)
      if (config.enableGeminiVerification && !isDemo) {
        fetch('/api/gemini/analyze-badge', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            imageBase64: dataUrl,
            workerId: activeWorkerId,
            shift,
            temp: useEnvCompensation ? temperature : undefined,
            humidity: useEnvCompensation ? humidity : undefined,
          }),
        })
          .then(res => res.json())
          .then(data => {
            if (data.success && data.data) {
              setCurrentResult(prev => {
                if (!prev) return prev;
                return {
                  ...prev,
                  estimatedDose: data.data.estimatedDose ?? prev.estimatedDose,
                  riskLevel: data.data.riskLevel ?? prev.riskLevel,
                  confidence: data.data.confidence ?? prev.confidence,
                  badgeValidity: data.data.badgeValidity ?? prev.badgeValidity,
                  notes: `AI Vision: ${data.data.summaryNotes || 'Verified'} | ${prev.notes}`,
                };
              });
            }
          })
          .catch(() => {});
      }
    } catch (err: any) {
      console.error('Fast analysis error:', err);
      setAnalysisError(err.message || 'Error during colorimetric analysis.');
      setStep(4);
    } finally {
      setIsAnalyzing(false);
    }
  };

  // Run Image Analysis Pipeline for Step 4 manual button
  const runAnalysis = async () => {
    if (!capturedImageDataUrl) return;
    executeDirectAnalysis(capturedImageDataUrl, isDemoBadge);
  };

  const handleRetake = () => {
    setCapturedImageDataUrl(null);
    setCurrentResult(null);
    setAnalysisError(null);
    setStep(3);
  };

  const handleScanAgain = () => {
    setCapturedImageDataUrl(null);
    setCurrentResult(null);
    setAnalysisError(null);
    setStep(3);
  };

  return (
    <div className="max-w-2xl mx-auto space-y-6 pb-12">
      {/* STEP 3: CAPTURE PHOTO OR UPLOAD OR SAMPLE BADGE */}
      {step === 3 && (
        <div className="bg-white/80 backdrop-blur-xl border border-white/90 shadow-[0_8px_30px_rgba(0,0,0,0.04)] rounded-[32px] p-5 sm:p-7 space-y-6">
          {/* Header */}
          <div className="flex items-center justify-between flex-wrap gap-2">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-2xl bg-black text-white flex items-center justify-center font-bold font-mono text-base shadow-sm">
                <Camera className="w-5 h-5 text-white" />
              </div>
              <div>
                <h2 className="text-base font-bold text-slate-900 font-mono">Scan Wristband / Upload Image</h2>
                <p className="text-xs text-slate-500 font-medium">Capture or upload photo to analyze lead acetate strip color</p>
              </div>
            </div>
          </div>

          {/* Quick Worker & Shift Profile Selector Bar */}
          <div className="p-3.5 bg-slate-50/80 backdrop-blur-md rounded-2xl border border-slate-200/80 space-y-3">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2 text-xs">
                <User className="w-4 h-4 text-slate-800" />
                <span className="text-slate-500 font-medium">Assigned Worker:</span>
                <span className="font-bold text-slate-900 font-mono">{selectedWorkerId}</span>
                <span className="text-slate-700 font-semibold">({workerName})</span>
                <span className="text-[11px] px-2 py-0.5 rounded-full bg-white text-slate-800 border border-slate-200 font-bold shadow-2xs">
                  {shift} Shift
                </span>
              </div>

              <button
                type="button"
                onClick={() => setShowWorkerConfig(!showWorkerConfig)}
                className="text-xs font-bold text-slate-900 hover:text-black flex items-center gap-1 cursor-pointer"
              >
                {showWorkerConfig ? 'Close' : 'Change Worker / Shift'}
              </button>
            </div>

            {/* Expandable Worker & Shift configuration */}
            {showWorkerConfig && (
              <div className="pt-3 border-t border-slate-200 space-y-3">
                <div>
                  <label className="block text-[11px] font-bold text-slate-700 uppercase tracking-wider mb-1.5">
                    Select Worker
                  </label>
                  <select
                    id="scanner-worker-select"
                    value={selectedWorkerId}
                    onChange={(e) => handleWorkerSelect(e.target.value)}
                    className="w-full bg-white border border-slate-300 text-slate-900 font-medium rounded-lg p-2 text-xs focus:outline-none focus:border-indigo-500"
                  >
                    {workers.map((w) => (
                      <option key={w.id} value={w.id}>
                        {w.id} — {w.name} ({w.department})
                      </option>
                    ))}
                    <option value="NEW">+ Enter Custom / New Worker ID</option>
                  </select>
                </div>

                {selectedWorkerId === 'NEW' && (
                  <div className="grid grid-cols-2 gap-2">
                    <input
                      type="text"
                      value={customWorkerId}
                      onChange={(e) => setCustomWorkerId(e.target.value)}
                      placeholder="Worker ID (e.g. W109)"
                      className="bg-white border border-slate-300 rounded-lg p-2 text-xs uppercase font-mono font-bold"
                    />
                    <input
                      type="text"
                      value={workerName}
                      onChange={(e) => setWorkerName(e.target.value)}
                      placeholder="Worker Full Name"
                      className="bg-white border border-slate-300 rounded-lg p-2 text-xs font-medium"
                    />
                  </div>
                )}

                <div>
                  <label className="block text-[11px] font-bold text-slate-700 uppercase tracking-wider mb-1.5">
                    Work Shift
                  </label>
                  <div className="grid grid-cols-3 gap-2">
                    {(['Morning', 'Afternoon', 'Night'] as ShiftType[]).map((s) => (
                      <button
                        key={s}
                        type="button"
                        onClick={() => setShift(s)}
                        className={`py-2 px-2.5 rounded-xl text-xs font-bold border transition-all cursor-pointer ${
                          shift === s
                            ? 'bg-black border-black text-white shadow-xs'
                            : 'bg-white border-slate-200 text-slate-700 hover:bg-slate-50'
                        }`}
                      >
                        {s}
                      </button>
                    ))}
                  </div>
                </div>
              </div>
            )}
          </div>

          {analysisError && (
            <div className="bg-rose-50 border border-rose-300 rounded-2xl p-3.5 text-xs text-rose-800 flex items-start gap-2.5 font-medium">
              <AlertTriangle className="w-4 h-4 text-rose-600 shrink-0 mt-0.5" />
              <span>{analysisError}</span>
            </div>
          )}

          {/* Active Camera Viewfinder */}
          {isCameraActive ? (
            <div className="space-y-3">
              <div className="relative overflow-hidden rounded-[26px] bg-black border border-white/20 shadow-2xl aspect-[4/3] flex items-center justify-center">
                <video
                  ref={videoRef}
                  autoPlay
                  playsInline
                  muted
                  onLoadedMetadata={() => {
                    if (videoRef.current) {
                      videoRef.current.play().catch(e => console.warn('Autoplay caught:', e));
                      setIsVideoReady(true);
                    }
                  }}
                  onCanPlay={() => setIsVideoReady(true)}
                  className={`w-full h-full object-cover transition-opacity duration-300 ${
                    isVideoReady ? 'opacity-100' : 'opacity-0'
                  } ${facingMode === 'user' ? '-scale-x-100' : ''}`}
                />

                {/* Loading state while camera initializes */}
                {!isVideoReady && (
                  <div className="absolute inset-0 flex flex-col items-center justify-center bg-slate-950 text-white gap-3 p-4">
                    <div className="w-10 h-10 border-3 border-white border-t-transparent rounded-full animate-spin" />
                    <div className="text-center">
                      <p className="text-sm font-bold font-mono text-white">CONNECTING CAMERA SENSOR</p>
                      <p className="text-xs text-slate-400 mt-0.5">Please allow camera permissions if prompted</p>
                    </div>
                  </div>
                )}

                {/* Rectangular Scan Guide Overlay matching user specification */}
                <div className="absolute inset-0 pointer-events-none flex items-center justify-center p-4">
                  <div className="w-[85%] h-[75%] border-2 border-dashed border-white/90 rounded-2xl bg-white/5 relative shadow-inner backdrop-blur-2xs">
                    {/* Corner Reticles */}
                    <div className="absolute -top-1 -left-1 w-4 h-4 border-t-4 border-l-4 border-white" />
                    <div className="absolute -top-1 -right-1 w-4 h-4 border-t-4 border-r-4 border-white" />
                    <div className="absolute -bottom-1 -left-1 w-4 h-4 border-b-4 border-l-4 border-white" />
                    <div className="absolute -bottom-1 -right-1 w-4 h-4 border-b-4 border-r-4 border-white" />

                    {/* Overlay Guidance Labels */}
                    <div className="absolute top-2 left-2 right-2 text-center text-[10px] font-bold text-white bg-black/85 py-1 px-2.5 rounded-full border border-white/20 backdrop-blur">
                      [ SENSING STRIP & REFERENCE SCALE INSIDE BOX ]
                    </div>

                    <div className="absolute bottom-2 left-2 right-2 flex justify-around text-[9px] font-semibold text-slate-200 bg-black/80 py-0.5 px-1 rounded backdrop-blur">
                      <span>• Keep Flat</span>
                      <span>• Even Light</span>
                      <span>• Hold Steady</span>
                    </div>
                  </div>
                </div>

                {/* Camera controls overlay (Torch & Flip) */}
                <div className="absolute top-3 right-3 flex items-center gap-2">
                  {hasTorch && (
                    <button
                      type="button"
                      onClick={toggleTorch}
                      className={`p-2.5 rounded-full border shadow-lg cursor-pointer transition-all hover:scale-105 active:scale-95 backdrop-blur-md ${
                        isTorchOn
                          ? 'bg-amber-400 text-slate-950 border-amber-300 shadow-amber-400/40'
                          : 'bg-black/75 hover:bg-black text-white border-white/30'
                      }`}
                      title={isTorchOn ? 'Turn flashlight off' : 'Turn flashlight on'}
                    >
                      <Zap className={`w-4 h-4 ${isTorchOn ? 'fill-slate-950' : 'text-white'}`} />
                    </button>
                  )}

                  <button
                    type="button"
                    onClick={toggleCameraFacing}
                    className="p-2.5 bg-black/75 hover:bg-black text-white rounded-full border border-white/30 shadow-lg cursor-pointer transition-all hover:scale-105 active:scale-95 backdrop-blur-md"
                    title="Switch front / rear camera"
                  >
                    <SwitchCamera className="w-4 h-4 text-white" />
                  </button>
                </div>
              </div>

              {/* Camera Trigger & Cancel */}
              <div className="flex gap-3">
                <SpecularButton
                  onClick={stopCameraStream}
                  size="sm"
                  radius={14}
                  tint="#ffffff"
                  tintOpacity={0.9}
                  textColor="#0f172a"
                  lineColor="#ffffff"
                  baseColor="#e2e8f0"
                  className="px-4 py-3 font-bold text-xs border border-slate-200/80 backdrop-blur-md shadow-2xs"
                >
                  Cancel Camera
                </SpecularButton>

                <SpecularButton
                  id="scanner-snap-btn"
                  onClick={captureFrame}
                  size="md"
                  radius={16}
                  tint="#000000"
                  tintOpacity={0.95}
                  textColor="#ffffff"
                  lineColor="#ffffff"
                  baseColor="#18181b"
                  intensity={1.3}
                  disabled={!isVideoReady}
                  className={`flex-1 py-3.5 font-bold text-sm shadow-xl shadow-black/20 ${
                    !isVideoReady ? 'opacity-50 cursor-not-allowed' : ''
                  }`}
                >
                  <Camera className="w-5 h-5 text-white" />
                  <span>SNAP PHOTO</span>
                </SpecularButton>
              </div>
            </div>
          ) : (
            <div className="space-y-4">
              {/* Primary Action Buttons: Open Camera & Upload Photo */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <SpecularButton
                  id="scanner-open-camera-btn"
                  onClick={startCamera}
                  size="lg"
                  radius={20}
                  tint="#000000"
                  tintOpacity={0.95}
                  textColor="#ffffff"
                  lineColor="#ffffff"
                  baseColor="#18181b"
                  intensity={1.3}
                  shineSize={14}
                  shineFade={45}
                  followMouse
                  className="w-full p-6 shadow-xl shadow-black/20 flex flex-col items-center justify-center gap-2 group backdrop-blur-md"
                >
                  <div className="w-12 h-12 rounded-2xl bg-white/10 border border-white/20 flex items-center justify-center group-hover:scale-110 transition-transform shadow-xs mb-1">
                    <Camera className="w-6 h-6 text-white" />
                  </div>
                  <span className="font-bold text-sm tracking-wide font-mono block">OPEN CAMERA</span>
                  <span className="text-xs text-slate-300 font-medium block">Live Mobile Capture</span>
                </SpecularButton>

                <SpecularButton
                  id="scanner-upload-photo-btn"
                  onClick={() => fileInputRef.current?.click()}
                  size="lg"
                  radius={20}
                  tint="#ffffff"
                  tintOpacity={0.9}
                  textColor="#0f172a"
                  lineColor="#ffffff"
                  baseColor="#f8fafc"
                  intensity={1.0}
                  followMouse
                  className="w-full p-6 border border-slate-200/90 shadow-sm flex flex-col items-center justify-center gap-2 group backdrop-blur-md"
                >
                  <div className="w-12 h-12 rounded-2xl bg-black flex items-center justify-center group-hover:scale-110 transition-transform shadow-xs mb-1">
                    <Upload className="w-6 h-6 text-white" />
                  </div>
                  <span className="font-bold text-sm tracking-wide font-mono text-slate-900 block">UPLOAD PHOTO</span>
                  <span className="text-xs text-slate-500 font-medium block">JPEG / PNG / WEBP</span>
                </SpecularButton>

                <input
                  ref={fileInputRef}
                  type="file"
                  accept="image/*"
                  onChange={handleFileUpload}
                  className="hidden"
                />
              </div>

              {/* Sample Badges Quick Selector for instant testing */}
              <div className="bg-slate-50/70 backdrop-blur-md p-4 rounded-2xl border border-slate-200/80 space-y-3">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2 text-xs font-bold text-slate-900 uppercase tracking-wider font-mono">
                    <Sparkles className="w-4 h-4 text-black" />
                    <span>Demo Mode: Select Sample Wristband</span>
                  </div>
                  <span className="text-xs text-slate-500 font-semibold">Instant test</span>
                </div>

                <div className="grid grid-cols-2 sm:grid-cols-3 gap-2">
                  {SAMPLE_BADGES.map((badge) => (
                    <button
                      key={badge.id}
                      onClick={() => handleSelectSample(badge)}
                      className="p-2.5 bg-white/90 hover:bg-slate-100/90 border border-slate-200 hover:border-slate-400 rounded-xl text-left transition-all shadow-2xs cursor-pointer"
                    >
                      <div className="flex items-center gap-1.5">
                        <div
                          className="w-4 h-4 rounded-sm border border-slate-300 shrink-0"
                          style={{ backgroundColor: `rgb(${badge.stripColorRgb.join(',')})` }}
                        />
                        <span className="text-xs font-bold text-slate-900 truncate font-mono">
                          {badge.dosePpmH > 0 ? `${badge.dosePpmH} ppm·h` : '0.0 (Clean)'}
                        </span>
                      </div>
                      <div className="text-[10px] text-slate-500 font-medium truncate mt-0.5">
                        {badge.expiryStatus === 'EXPIRED' ? 'Expired Badge' : badge.name.split('—')[1] || badge.name}
                      </div>
                    </button>
                  ))}
                </div>
              </div>
            </div>
          )}
        </div>
      )}

      {/* STEP 4: PREVIEW IMAGE, RECTANGULAR SCAN GUIDE & ANALYZE */}
      {step === 4 && capturedImageDataUrl && (
        <div className="bg-white/80 backdrop-blur-xl border border-white/90 shadow-[0_8px_30px_rgba(0,0,0,0.04)] rounded-[32px] p-5 sm:p-7 space-y-5">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-2xl bg-black text-white flex items-center justify-center font-bold font-mono text-base shadow-sm">
                4
              </div>
              <div>
                <h2 className="text-base font-bold text-slate-900 font-mono">Step 4: Confirm Alignment & Analyze</h2>
                <p className="text-xs text-slate-500 font-medium">Verify reference scale and sensing strip visibility</p>
              </div>
            </div>

            {isDemoBadge && (
              <span className="px-2.5 py-1 bg-black text-white border border-black/20 rounded-full text-[10px] font-bold uppercase tracking-wider shadow-2xs">
                DEMO BADGE
              </span>
            )}
          </div>

          {analysisError && (
            <div className="bg-rose-50 border border-rose-300 rounded-2xl p-3.5 text-xs text-rose-800 flex items-start gap-2.5 font-medium">
              <AlertTriangle className="w-4 h-4 text-rose-600 shrink-0 mt-0.5" />
              <span>{analysisError}</span>
            </div>
          )}

          {/* Captured Image Preview with Rectangular Scan Guide */}
          <div className="relative overflow-hidden rounded-[26px] bg-black border border-white/20 shadow-2xl aspect-[4/3] flex items-center justify-center">
            <img
              src={capturedImageDataUrl}
              alt="Wristband Preview"
              className="w-full h-full object-contain"
            />

            {/* Rectangular ROI Guide Overlay */}
            <div className="absolute inset-0 pointer-events-none flex items-center justify-center p-4">
              <div className="w-[85%] h-[75%] border-2 border-dashed border-white/90 rounded-2xl bg-white/5 relative shadow-inner backdrop-blur-2xs">
                {/* Target regions */}
                <div className="absolute top-[18%] left-[15%] right-[15%] h-[32%] border border-white/70 bg-white/10 rounded-xl flex items-center justify-center">
                  <span className="text-[10px] font-mono font-bold text-white bg-black/85 px-2 py-0.5 rounded-full border border-white/20 backdrop-blur">
                    [ CHEMICAL SENSING STRIP ]
                  </span>
                </div>

                <div className="absolute bottom-[24%] left-[10%] right-[10%] h-[18%] border border-white/50 bg-white/10 rounded-xl flex items-center justify-center">
                  <span className="text-[10px] font-mono font-bold text-white bg-black/85 px-2 py-0.5 rounded-full border border-white/20 backdrop-blur">
                    [ 5-PATCH REFERENCE SCALE ]
                  </span>
                </div>
              </div>
            </div>
          </div>

          {/* Guidelines Checklist */}
          <div className="bg-slate-50/70 backdrop-blur-md p-4 rounded-2xl border border-slate-200/80 grid grid-cols-2 gap-2 text-xs text-slate-700 font-medium">
            <div className="flex items-center gap-1.5">
              <CheckCircle className="w-4 h-4 text-slate-900 shrink-0" />
              <span>Keep wristband flat</span>
            </div>
            <div className="flex items-center gap-1.5">
              <CheckCircle className="w-4 h-4 text-slate-900 shrink-0" />
              <span>Use even lighting</span>
            </div>
            <div className="flex items-center gap-1.5">
              <CheckCircle className="w-4 h-4 text-slate-900 shrink-0" />
              <span>Reference scale visible</span>
            </div>
            <div className="flex items-center gap-1.5">
              <CheckCircle className="w-4 h-4 text-slate-900 shrink-0" />
              <span>Avoid heavy shadows</span>
            </div>
          </div>

          {/* Action Buttons: Back / Retake / Analyze */}
          <div className="flex gap-2 sm:gap-3">
            <SpecularButton
              id="scanner-step4-back-btn"
              onClick={() => setStep(3)}
              disabled={isAnalyzing}
              size="sm"
              radius={14}
              tint="#ffffff"
              tintOpacity={0.9}
              textColor="#0f172a"
              lineColor="#ffffff"
              baseColor="#e2e8f0"
              className="px-3 sm:px-4 py-3.5 font-bold text-xs border border-slate-200/80 backdrop-blur-md shadow-2xs"
            >
              <ArrowLeft className="w-4 h-4 text-black" />
              <span className="hidden sm:inline">Back</span>
            </SpecularButton>

            <SpecularButton
              id="scanner-retake-btn"
              onClick={handleRetake}
              disabled={isAnalyzing}
              size="sm"
              radius={14}
              tint="#ffffff"
              tintOpacity={0.9}
              textColor="#0f172a"
              lineColor="#ffffff"
              baseColor="#e2e8f0"
              className="px-3 sm:px-4 py-3.5 font-bold text-xs border border-slate-200/80 backdrop-blur-md shadow-2xs"
            >
              <RotateCcw className="w-4 h-4 text-slate-700" />
              <span>RETAKE</span>
            </SpecularButton>

            <SpecularButton
              id="scanner-analyze-btn"
              onClick={runAnalysis}
              disabled={isAnalyzing}
              size="md"
              radius={16}
              tint="#000000"
              tintOpacity={0.95}
              textColor="#ffffff"
              lineColor="#ffffff"
              baseColor="#18181b"
              intensity={1.3}
              className="flex-1 py-3.5 font-bold text-sm shadow-xl shadow-black/20"
            >
              {isAnalyzing ? (
                <>
                  <RefreshCw className="w-4 h-4 animate-spin text-white" />
                  <span className="truncate">SCANNING LEAD STRIP COLOR...</span>
                </>
              ) : (
                <>
                  <ScanLine className="w-5 h-5 text-white" />
                  <span>SCAN LEAD STRIP (SAFE / DANGER)</span>
                </>
              )}
            </SpecularButton>
          </div>
        </div>
      )}

      {/* STEP 5: EXPOSURE RESULT SCREEN */}
      {step === 5 && currentResult && (
        <ResultCard
          scanResult={currentResult}
          onSave={() => onSaveScan(currentResult)}
          onScanAgain={handleScanAgain}
          onViewHistory={() => setActiveTab('history')}
          isAlreadySaved={true}
        />
      )}

      {/* Optical Scanning HUD Overlay during active analysis */}
      {isAnalyzing && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/75 backdrop-blur-md animate-fade-in">
          <div className="bg-white/95 backdrop-blur-xl rounded-3xl border border-white/80 shadow-2xl p-6 sm:p-8 max-w-sm w-full text-center space-y-5 relative overflow-hidden">
            {/* Animated Laser Scanning Beam & Icon */}
            <div className="relative w-24 h-24 mx-auto rounded-2xl bg-slate-900 border border-slate-700 shadow-inner flex items-center justify-center overflow-hidden">
              <ScanLine className="w-10 h-10 text-cyan-400 animate-pulse" />
              <div className="absolute inset-x-0 h-1 bg-gradient-to-r from-transparent via-cyan-400 to-transparent shadow-[0_0_12px_#22d3ee] animate-bounce" />
            </div>

            <div className="space-y-1.5">
              <div className="text-[11px] font-black tracking-widest text-cyan-700 font-mono uppercase">
                OPTICAL COLORIMETRY ENGINE
              </div>
              <h3 className="text-lg font-black text-slate-900 font-mono">
                ANALYZING DOSIMETER
              </h3>
              <p className="text-xs text-slate-600 font-medium">
                Calibrating reference scale & measuring CIEDE2000 ΔE shift...
              </p>
            </div>

            {/* Glowing progress bar */}
            <div className="w-full bg-slate-100 rounded-full h-2 overflow-hidden border border-slate-200">
              <div className="bg-gradient-to-r from-cyan-500 via-indigo-500 to-emerald-500 h-full w-full animate-pulse" />
            </div>

            <div className="flex items-center justify-between text-[10px] font-mono font-bold text-slate-500 pt-1 border-t border-slate-100">
              <span>[ 1. LIGHTING ]</span>
              <span>[ 2. COLOR ΔE ]</span>
              <span>[ 3. VERDICT ]</span>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
