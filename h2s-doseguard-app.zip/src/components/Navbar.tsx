import React from 'react';
import { ArrowLeft, Info, Activity } from 'lucide-react';
import { ActiveTab } from '../types';

interface NavbarProps {
  activeTab: ActiveTab;
  setActiveTab: (tab: ActiveTab) => void;
  onBack?: () => void;
  onOpenAbout: () => void;
  onOpenSampleBadges?: () => void;
  onOpenDev?: () => void;
  envTemp?: number;
  envHumidity?: number;
}

export const Navbar: React.FC<NavbarProps> = ({
  activeTab,
  setActiveTab,
  onBack,
  onOpenAbout,
}) => {
  const getTabTitle = (tab: ActiveTab) => {
    switch (tab) {
      case 'scan':
        return 'Dosimeter Scanner';
      case 'history':
        return 'Exposure Feed';
      case 'dashboard':
        return 'Safety Analytics';
      case 'workers':
        return 'Worker Directory';
      case 'calibration':
        return 'Calibration Config';
      default:
        return 'Sulfex';
    }
  };

  return (
    <header className="sticky top-0 z-40 bg-white/40 backdrop-blur-xl border-b border-white/40 text-slate-900 px-4 sm:px-6 py-3 transition-all">
      <div className="max-w-4xl mx-auto flex items-center justify-between gap-3">
        {/* Left: Brand Icon + Title */}
        {activeTab === 'home' ? (
          <div
            onClick={() => setActiveTab('home')}
            className="flex items-center gap-2.5 cursor-pointer group"
          >
            <div className="w-9 h-9 rounded-full bg-black text-white flex items-center justify-center shadow-md group-hover:scale-105 transition-transform">
              <Activity className="w-4 h-4 text-white" />
            </div>
            <h1 className="text-base sm:text-lg font-black text-slate-900 tracking-tight">
              Sulfex
            </h1>
          </div>
        ) : (
          <div className="flex items-center gap-3">
            <button
              id="navbar-back-btn"
              onClick={onBack ? onBack : () => setActiveTab('home')}
              type="button"
              className="w-9 h-9 rounded-full bg-white/80 hover:bg-white border border-slate-200 text-slate-800 flex items-center justify-center shadow-2xs active:scale-95 transition-all cursor-pointer"
              title="Go back"
            >
              <ArrowLeft className="w-4 h-4 text-slate-800" />
            </button>
            <div>
              <h2 className="text-base sm:text-lg font-black text-slate-900 tracking-tight leading-none">
                {getTabTitle(activeTab)}
              </h2>
              <p className="text-[11px] text-slate-600 font-semibold mt-0.5">
                Passive Colorimetric Telemetry
              </p>
            </div>
          </div>
        )}

        {/* Right Section: User Manual & Info */}
        <div className="flex items-center gap-2">
          {/* User Manual & Guide */}
          <button
            id="nav-about-btn"
            onClick={onOpenAbout}
            type="button"
            className="w-9 h-9 rounded-full bg-white/70 hover:bg-white text-slate-700 hover:text-slate-900 border border-white/80 flex items-center justify-center shadow-xs transition-all cursor-pointer active:scale-95"
            title="User Manual & Info"
          >
            <Info className="w-4 h-4" />
          </button>
        </div>
      </div>
    </header>
  );
};
