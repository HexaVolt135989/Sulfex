import React from 'react';

interface HexavoltLogoProps {
  className?: string;
  size?: number | string;
  showText?: boolean;
}

/**
 * Authentic Hexavolt brand mark:
 * - Regular vertical hexagon wireframe in purple-to-blue gradient
 * - Intertwined "HV" speed monogram with lightning bolt & horizontal discharge spikes
 * - Modern techno-sans "Hexa volt" typography
 */
export const HexavoltLogo: React.FC<HexavoltLogoProps> = ({
  className = '',
  size = 140,
  showText = true,
}) => {
  const viewBox = showText ? '0 0 520 470' : '0 0 520 360';
  const height =
    typeof size === 'number'
      ? showText
        ? (size * 470) / 520
        : (size * 360) / 520
      : size;

  return (
    <svg
      viewBox={viewBox}
      width={size}
      height={height}
      className={`inline-block select-none ${className}`}
      fill="none"
      xmlns="http://www.w3.org/2000/svg"
      role="img"
      aria-label="Hexa volt"
    >
      <defs>
        {/* Hexagon Frame Gradient: Purple at top to Electric Blue at bottom */}
        <linearGradient id="hv-hex-grad" x1="50%" y1="0%" x2="50%" y2="100%">
          <stop offset="0%" stopColor="#a855f7" />
          <stop offset="35%" stopColor="#9333ea" />
          <stop offset="70%" stopColor="#4f46e5" />
          <stop offset="100%" stopColor="#2563eb" />
        </linearGradient>

        {/* Monogram Gradient: Electric Blue (bottom-left) to Vivid Violet/Magenta (top-right) */}
        <linearGradient id="hv-monogram-grad" x1="12%" y1="88%" x2="88%" y2="12%">
          <stop offset="0%" stopColor="#1d4ed8" />
          <stop offset="18%" stopColor="#2563eb" />
          <stop offset="42%" stopColor="#4f46e5" />
          <stop offset="68%" stopColor="#7c3aed" />
          <stop offset="85%" stopColor="#9333ea" />
          <stop offset="100%" stopColor="#c026d3" />
        </linearGradient>

        {/* Wordmark Gradient: Violet to Electric Blue */}
        <linearGradient id="hv-text-grad" x1="0%" y1="0%" x2="100%" y2="0%">
          <stop offset="0%" stopColor="#7c3aed" />
          <stop offset="30%" stopColor="#6d28d9" />
          <stop offset="65%" stopColor="#4f46e5" />
          <stop offset="100%" stopColor="#2563eb" />
        </linearGradient>

        {/* Crisp Ambient Drop Shadow */}
        <filter id="hv-clean-glow" x="-15%" y="-15%" width="130%" height="130%">
          <feDropShadow dx="0" dy="6" stdDeviation="10" floodColor="#7c3aed" floodOpacity="0.22" />
        </filter>
      </defs>

      <g filter="url(#hv-clean-glow)">
        {/* ======================================================== */}
        {/* 1. REGULAR VERTICAL HEXAGON OUTLINE                      */}
        {/* ======================================================== */}
        {/* Center: (260, 190), Radius: 135 */}
        {/* Top: (260, 55), Top-R: (377, 122.5), Bot-R: (377, 257.5), Bot: (260, 325), Bot-L: (143, 257.5), Top-L: (143, 122.5) */}
        <polygon
          points="260,55 377,122.5 377,257.5 260,325 143,257.5 143,122.5"
          fill="none"
          stroke="url(#hv-hex-grad)"
          strokeWidth="5"
          strokeLinejoin="round"
          strokeLinecap="round"
        />

        {/* ======================================================== */}
        {/* 2. AUTHENTIC 'HV' MONOGRAM EMBLEM                        */}
        {/* ======================================================== */}
        <g fill="url(#hv-monogram-grad)">
          {/* A. LEFT STEM OF 'H' WITH TOP-LEFT SPEED SLASH & CROSSBAR */}
          <path d="
            M 188 104
            L 226 92
            L 206 166
            L 256 154
            L 248 184
            L 201 196
            L 180 274
            L 136 290
            L 168 138
            L 116 140
            L 170 131
            Z
          " />

          {/* B. RIGHT STEM OF 'H' */}
          <path d="
            M 266 92
            L 304 80
            L 264 230
            L 226 242
            Z
          " />

          {/* C. 'V' LIGHTNING BOLT MONOGRAM WITH ELECTRIC DISCHARGE SPIKES */}
          {/* - Pierces through top-right hexagon border at (374, 62) */}
          {/* - Horizontal spikes at middle-right (370, 186) and lower-right (376, 244) */}
          {/* - Connects at sharp bottom 'V' vertex at (260, 335) */}
          <path d="
            M 238 230
            L 260 335
            L 292 262
            L 376 244
            L 298 248
            L 304 220
            L 370 186
            L 284 202
            L 256 232
            L 374 62
            L 290 176
            L 256 304
            Z
          " />
        </g>
      </g>

      {/* ======================================================== */}
      {/* 3. 'Hexa volt' TYPOGRAPHY (MATCHING LOGO WORDMARK)       */}
      {/* ======================================================== */}
      {showText && (
        <g id="hexavolt-brand-wordmark">
          <text
            x="260"
            y="418"
            textAnchor="middle"
            fontFamily="'Oxanium', 'Chakra Petch', 'Orbitron', 'Montserrat', -apple-system, sans-serif"
            fontWeight="700"
            fontSize="48"
            letterSpacing="0.045em"
            fill="url(#hv-text-grad)"
          >
            Hexa volt
          </text>
        </g>
      )}
    </svg>
  );
};

export default HexavoltLogo;

