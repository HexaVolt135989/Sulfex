import React from 'react';
import { X, Zap, Cpu, Sparkles, CheckCircle2, Shield, Code2, Globe } from 'lucide-react';
import { HexavoltLogo } from './HexavoltLogo';

interface HexavoltDevModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const HexavoltDevModal: React.FC<HexavoltDevModalProps> = ({
  isOpen,
  onClose,
}) => {
  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/65 backdrop-blur-md animate-fade-in select-none">
      <div
        className="relative w-full max-w-lg bg-white rounded-3xl shadow-[0_25px_60px_rgba(0,0,0,0.25)] border border-slate-200 overflow-hidden text-slate-900 animate-scale-up"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Subtle Ambient Background Gradient */}
        <div className="absolute -top-24 -right-24 w-64 h-64 bg-indigo-500/10 rounded-full blur-3xl pointer-events-none" />
        <div className="absolute -bottom-24 -left-24 w-64 h-64 bg-purple-500/10 rounded-full blur-3xl pointer-events-none" />

        {/* Close Button */}
        <button
          id="hexavolt-modal-close-btn"
          type="button"
          onClick={onClose}
          className="absolute top-4 right-4 z-20 w-9 h-9 rounded-full bg-slate-100 hover:bg-slate-200 text-slate-600 hover:text-slate-950 flex items-center justify-center transition-all cursor-pointer shadow-xs"
          aria-label="Close modal"
        >
          <X className="w-5 h-5" />
        </button>

        {/* Main Content Body */}
        <div className="p-6 sm:p-8 flex flex-col items-center text-center">
          {/* Hexavolt Official Brand Logo Showcase */}
          <div className="relative mb-4 flex flex-col items-center">
            <div className="relative p-5 sm:p-6 rounded-3xl bg-white border border-purple-100/90 shadow-[0_10px_35px_rgba(124,58,237,0.08)] flex items-center justify-center">
              <HexavoltLogo size={175} showText={true} className="drop-shadow-xs" />
            </div>

            {/* Developer Attribution Tag */}
            <div className="inline-flex items-center gap-1.5 px-3.5 py-1 mt-3 rounded-full bg-purple-100/80 text-purple-900 border border-purple-200/80 text-xs font-bold uppercase tracking-wider shadow-2xs">
              <Zap className="w-3.5 h-3.5 text-purple-700 fill-purple-700" />
              <span>Developed by Hexavolt</span>
            </div>
          </div>

          {/* Description */}
          <p className="text-sm sm:text-base text-slate-600 leading-relaxed max-w-sm mt-2 mb-6">
            Pioneering smart industrial safety systems, intelligent environmental dosimeters, and cutting-edge sensor telemetry software.
          </p>

          {/* Tech & Capabilities Matrix */}
          <div className="w-full grid grid-cols-2 gap-2.5 text-left mb-6">
            <div className="p-3 rounded-2xl bg-slate-50 border border-slate-200/70 flex items-start gap-2.5">
              <div className="w-7 h-7 rounded-xl bg-purple-100 text-purple-700 flex items-center justify-center shrink-0 mt-0.5">
                <Cpu className="w-4 h-4" />
              </div>
              <div>
                <h4 className="text-xs font-bold text-slate-900 font-mono">CV Vision Engine</h4>
                <p className="text-[11px] text-slate-500">Photometric colorimetric analysis</p>
              </div>
            </div>

            <div className="p-3 rounded-2xl bg-slate-50 border border-slate-200/70 flex items-start gap-2.5">
              <div className="w-7 h-7 rounded-xl bg-indigo-100 text-indigo-700 flex items-center justify-center shrink-0 mt-0.5">
                <Shield className="w-4 h-4" />
              </div>
              <div>
                <h4 className="text-xs font-bold text-slate-900 font-mono">H₂S Dosimetry</h4>
                <p className="text-[11px] text-slate-500">Fick&apos;s diffusion modeling</p>
              </div>
            </div>

            <div className="p-3 rounded-2xl bg-slate-50 border border-slate-200/70 flex items-start gap-2.5">
              <div className="w-7 h-7 rounded-xl bg-blue-100 text-blue-700 flex items-center justify-center shrink-0 mt-0.5">
                <Sparkles className="w-4 h-4" />
              </div>
              <div>
                <h4 className="text-xs font-bold text-slate-900 font-mono">Real-time Telemetry</h4>
                <p className="text-[11px] text-slate-500">Zero-power sensor syncing</p>
              </div>
            </div>

            <div className="p-3 rounded-2xl bg-slate-50 border border-slate-200/70 flex items-start gap-2.5">
              <div className="w-7 h-7 rounded-xl bg-emerald-100 text-emerald-700 flex items-center justify-center shrink-0 mt-0.5">
                <Code2 className="w-4 h-4" />
              </div>
              <div>
                <h4 className="text-xs font-bold text-slate-900 font-mono">High-FPS UI</h4>
                <p className="text-[11px] text-slate-500">Mobile-optimized GPU rendering</p>
              </div>
            </div>
          </div>

          {/* Action Button */}
          <button
            id="hexavolt-modal-dismiss-btn"
            type="button"
            onClick={onClose}
            className="w-full py-3 px-6 rounded-2xl bg-gradient-to-r from-purple-600 via-indigo-600 to-blue-600 hover:from-purple-700 hover:to-blue-700 text-white font-mono font-bold text-sm tracking-wider uppercase shadow-lg shadow-indigo-500/25 active:scale-[0.98] transition-all cursor-pointer"
          >
            Continue
          </button>
        </div>
      </div>
    </div>
  );
};

export default HexavoltDevModal;
