import React, { useState, useRef } from 'react';
import {
  Sliders,
  AlertTriangle,
  Download,
  Upload,
  RotateCcw,
  Save,
  Plus,
  Trash2,
  Sparkles,
  Layers,
  Thermometer,
  ShieldAlert,
  Info,
  CheckCircle2,
  ArrowLeft,
} from 'lucide-react';
import {
  LineChart,
  Line,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
} from 'recharts';
import { AdminCalibrationConfig, CalibrationPoint } from '../types';
import { storageService } from '../services/storageService';
import { SpecularButton } from './SpecularButton';

interface AdminCalibrationViewProps {
  config: AdminCalibrationConfig;
  onSaveConfig: (newConfig: AdminCalibrationConfig) => void;
  onResetConfig: () => void;
  onBack?: () => void;
}

export const AdminCalibrationView: React.FC<AdminCalibrationViewProps> = ({
  config,
  onSaveConfig,
  onResetConfig,
  onBack,
}) => {
  const [localConfig, setLocalConfig] = useState<AdminCalibrationConfig>({ ...config });
  const [saveSuccess, setSaveSuccess] = useState(false);
  const [isResetConfirmOpen, setIsResetConfirmOpen] = useState(false);
  const fileInputRef = useRef<HTMLInputElement | null>(null);

  const handlePointChange = (index: number, field: 'colorIndex' | 'dose', value: number) => {
    const updated = [...localConfig.calibrationPoints];
    updated[index] = { ...updated[index], [field]: value };
    setLocalConfig({ ...localConfig, calibrationPoints: updated });
  };

  const handleAddPoint = () => {
    const lastPoint = localConfig.calibrationPoints[localConfig.calibrationPoints.length - 1];
    const newPoint: CalibrationPoint = {
      colorIndex: parseFloat((lastPoint.colorIndex + 0.1).toFixed(3)),
      dose: lastPoint.dose + 10,
    };
    setLocalConfig({
      ...localConfig,
      calibrationPoints: [...localConfig.calibrationPoints, newPoint],
    });
  };

  const handleDeletePoint = (index: number) => {
    if (localConfig.calibrationPoints.length <= 2) {
      alert('At least two calibration points are required for piecewise interpolation.');
      return;
    }
    const updated = localConfig.calibrationPoints.filter((_, i) => i !== index);
    setLocalConfig({ ...localConfig, calibrationPoints: updated });
  };

  const handleSave = () => {
    const sorted = [...localConfig.calibrationPoints].sort((a, b) => a.colorIndex - b.colorIndex);
    const finalConfig = { ...localConfig, calibrationPoints: sorted, lastUpdated: new Date().toISOString() };
    onSaveConfig(finalConfig);
    setSaveSuccess(true);
    setTimeout(() => setSaveSuccess(false), 2500);
  };

  const handleExportCsv = () => {
    const csv = storageService.exportCalibrationCsv();
    const blob = new Blob([csv], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.setAttribute('href', url);
    link.setAttribute('download', `H2S_Calibration_Curve_${new Date().toISOString().slice(0, 10)}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  const handleImportCsv = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = (event) => {
      const text = event.target?.result as string;
      const res = storageService.importCalibrationFromCsv(text);
      if (res.success) {
        const updatedConfig = storageService.getConfig();
        setLocalConfig(updatedConfig);
        alert(`Successfully imported ${res.count} calibration points! Click Save Changes to confirm.`);
      } else {
        alert(res.error || 'Could not parse calibration CSV. Ensure format is: colorIndex,dose');
      }
    };
    reader.readAsText(file);
  };

  // Calibration Curve Data for Chart
  const chartData = localConfig.calibrationPoints.map((p, idx) => ({
    colorIndex: p.colorIndex,
    dose: p.dose,
    label: `Point ${idx + 1}`,
  }));

  return (
    <div className="space-y-6 pb-12">
      {/* Header & Save Action */}
      <div className="bg-white/80 backdrop-blur-xl border border-white/90 rounded-[28px] p-4 sm:p-5 shadow-[0_8px_30px_rgba(0,0,0,0.04)] flex flex-col sm:flex-row sm:items-center justify-between gap-3 sm:gap-4 transition-all">
        <div className="flex items-start sm:items-center gap-3 min-w-0">
          {onBack && (
            <button
              id="calibration-back-btn"
              onClick={onBack}
              className="shrink-0 p-2 sm:p-2.5 bg-white/80 hover:bg-white text-slate-800 border border-white/90 hover:border-slate-300 rounded-2xl text-xs font-bold transition-all shadow-2xs backdrop-blur-md active:scale-95 group mt-0.5 sm:mt-0 flex items-center gap-1.5 cursor-pointer"
              title="Back to Home"
            >
              <ArrowLeft className="w-4 h-4 text-black group-hover:-translate-x-0.5 transition-transform" />
              <span className="text-xs font-bold sm:hidden">Back</span>
            </button>
          )}
          <div className="min-w-0 flex-1">
            <div className="flex items-center gap-2.5">
              <div className="w-8 h-8 sm:w-9 sm:h-9 rounded-2xl bg-black border border-white/20 flex items-center justify-center shrink-0 shadow-sm ring-2 ring-white/90">
                <Sliders className="w-4 h-4 text-white" />
              </div>
              <h1 className="text-sm sm:text-lg font-bold text-slate-900 uppercase tracking-wider font-mono">
                LABORATORY CALIBRATION & OPTICAL PARAMETERS
              </h1>
            </div>
            <p className="text-[11px] sm:text-xs text-slate-500 font-medium mt-1 leading-snug">
              Configure colorimetric response curve, risk thresholds, and environmental diffusion constants
            </p>
          </div>
        </div>

        <div className="flex items-center gap-2 shrink-0">
          <SpecularButton
            id="calibration-save-btn"
            onClick={handleSave}
            size="md"
            radius={16}
            tint="#000000"
            tintOpacity={0.95}
            textColor="#ffffff"
            lineColor="#ffffff"
            baseColor="#18181b"
            intensity={1.3}
            className="w-full sm:w-auto px-5 py-2.5 font-bold text-xs shadow-xl shadow-black/20 active:scale-95 cursor-pointer"
          >
            {saveSuccess ? (
              <>
                <CheckCircle2 className="w-4 h-4 text-white" />
                <span>SAVED!</span>
              </>
            ) : (
              <>
                <Save className="w-4 h-4 text-white" />
                <span>SAVE CHANGES</span>
              </>
            )}
          </SpecularButton>
        </div>
      </div>

      {/* 1. Color Index vs Estimated Exposure Response Curve */}
      <div className="bg-white border border-slate-200 rounded-2xl p-5 shadow-xs space-y-4">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 border-b border-slate-200 pb-3">
          <div>
            <h2 className="text-sm font-bold text-slate-900 uppercase tracking-wider font-mono">
              1. Color Index (ΔE / Absorbance) to Dose (ppm·h) Mapping
            </h2>
            <p className="text-xs text-slate-500 font-medium">
              Piecewise linear interpolation curve linking photometric color index to H2S exposure
            </p>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={handleAddPoint}
              className="px-3 py-1.5 bg-slate-100 hover:bg-slate-200 text-slate-800 rounded-lg text-xs font-bold border border-slate-300 flex items-center gap-1 shadow-xs cursor-pointer"
            >
              <Plus className="w-3.5 h-3.5 text-black" />
              <span>Add Point</span>
            </button>
            <button
              onClick={handleExportCsv}
              className="px-3 py-1.5 bg-slate-100 hover:bg-slate-200 text-slate-800 rounded-lg text-xs font-bold border border-slate-300 flex items-center gap-1 shadow-xs cursor-pointer"
            >
              <Download className="w-3.5 h-3.5 text-slate-600" />
              <span>Export CSV</span>
            </button>
            <button
              onClick={() => fileInputRef.current?.click()}
              className="px-3 py-1.5 bg-slate-100 hover:bg-slate-200 text-slate-800 rounded-lg text-xs font-bold border border-slate-300 flex items-center gap-1 shadow-xs cursor-pointer"
            >
              <Upload className="w-3.5 h-3.5 text-slate-600" />
              <span>Import CSV</span>
            </button>
            <input
              ref={fileInputRef}
              type="file"
              accept=".csv"
              onChange={handleImportCsv}
              className="hidden"
            />
          </div>
        </div>

        {/* Live Calibration Response Curve Visualizer */}
        <div className="h-56 w-full pt-2">
          <ResponsiveContainer width="100%" height="100%">
            <LineChart data={chartData} margin={{ top: 10, right: 20, left: -10, bottom: 0 }}>
              <CartesianGrid strokeDasharray="3 3" stroke="#e2e8f0" opacity={0.8} />
              <XAxis
                dataKey="colorIndex"
                stroke="#64748b"
                fontSize={11}
                tickLine={false}
                label={{ value: 'Colorimetric Index (ΔE / Absorbance)', position: 'insideBottom', offset: -2, fill: '#64748b', fontSize: 10 }}
              />
              <YAxis
                stroke="#64748b"
                fontSize={11}
                tickLine={false}
                label={{ value: 'Dose (ppm·h)', angle: -90, position: 'insideLeft', fill: '#64748b', fontSize: 10 }}
              />
              <Tooltip
                contentStyle={{ backgroundColor: '#ffffff', borderColor: '#cbd5e1', borderRadius: '8px', fontSize: '12px', boxShadow: '0 4px 6px -1px rgb(0 0 0 / 0.1)' }}
                formatter={(val: any) => [`${val} ppm·h`, 'Calibrated Exposure']}
                labelFormatter={(label) => `Color Index: ${label}`}
              />
              <Line
                type="monotone"
                dataKey="dose"
                name="Calibrated Dose"
                stroke="#0f172a"
                strokeWidth={3}
                dot={{ fill: '#0f172a', r: 5 }}
              />
            </LineChart>
          </ResponsiveContainer>
        </div>

        {/* Table of Calibration Points */}
        <div className="overflow-x-auto">
          <table className="w-full text-xs text-left">
            <thead className="bg-slate-100 text-slate-700 uppercase font-mono text-[10px] font-bold">
              <tr>
                <th className="p-2.5 rounded-l-lg">Point #</th>
                <th className="p-2.5">Color Index (0.00 – 1.00)</th>
                <th className="p-2.5">Estimated Dose (ppm·h)</th>
                <th className="p-2.5 text-right rounded-r-lg">Action</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-200 font-medium">
              {localConfig.calibrationPoints.map((point, index) => (
                <tr key={index} className="hover:bg-slate-50 font-mono">
                  <td className="p-2.5 text-slate-600">{index + 1}</td>
                  <td className="p-2.5">
                    <input
                      type="number"
                      step="0.01"
                      min={0}
                      max={1.5}
                      value={point.colorIndex}
                      onChange={(e) =>
                        handlePointChange(index, 'colorIndex', parseFloat(e.target.value) || 0)
                      }
                      className="w-24 bg-white border border-slate-300 rounded p-1.5 text-slate-900 font-mono focus:border-black focus:outline-none"
                    />
                  </td>
                  <td className="p-2.5">
                    <input
                      type="number"
                      step="0.5"
                      min={0}
                      value={point.dose}
                      onChange={(e) =>
                        handlePointChange(index, 'dose', parseFloat(e.target.value) || 0)
                      }
                      className="w-28 bg-white border border-slate-300 rounded p-1.5 text-slate-900 font-mono font-bold focus:border-black focus:outline-none"
                    />
                  </td>
                  <td className="p-2.5 text-right">
                    <button
                      onClick={() => handleDeletePoint(index)}
                      className="p-1.5 text-slate-500 hover:text-rose-600 hover:bg-rose-50 rounded transition-colors"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* 2. Risk Thresholds & Environmental Diffusion Settings */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {/* Risk Thresholds */}
        <div className="bg-white border border-slate-200 rounded-2xl p-5 shadow-xs space-y-4">
          <div className="flex items-center gap-2 border-b border-slate-200 pb-2.5">
            <ShieldAlert className="w-4 h-4 text-amber-600" />
            <h2 className="text-xs font-bold text-slate-900 uppercase tracking-wider font-mono">
              2. Prototype Risk Classification Thresholds
            </h2>
          </div>

          <div className="space-y-3 text-xs">
            <div>
              <label className="block text-slate-700 font-bold mb-1 flex items-center justify-between">
                <span>Low Risk Max Ceiling (ppm·h)</span>
                <span className="text-emerald-700 font-mono font-bold">&lt; {localConfig.riskThresholds.lowMax} ppm·h</span>
              </label>
              <input
                type="number"
                value={localConfig.riskThresholds.lowMax}
                onChange={(e) =>
                  setLocalConfig({
                    ...localConfig,
                    riskThresholds: { ...localConfig.riskThresholds, lowMax: parseFloat(e.target.value) || 10 },
                  })
                }
                className="w-full bg-slate-50 border border-slate-300 rounded-lg p-2.5 text-slate-900 font-mono font-medium focus:border-black focus:outline-none"
              />
            </div>

            <div>
              <label className="block text-slate-700 font-bold mb-1 flex items-center justify-between">
                <span>Moderate Risk Ceiling (ppm·h)</span>
                <span className="text-amber-700 font-mono font-bold">&lt; {localConfig.riskThresholds.moderateMax} ppm·h</span>
              </label>
              <input
                type="number"
                value={localConfig.riskThresholds.moderateMax}
                onChange={(e) =>
                  setLocalConfig({
                    ...localConfig,
                    riskThresholds: { ...localConfig.riskThresholds, moderateMax: parseFloat(e.target.value) || 25 },
                  })
                }
                className="w-full bg-slate-50 border border-slate-300 rounded-lg p-2.5 text-slate-900 font-mono font-medium focus:border-black focus:outline-none"
              />
            </div>

            <div className="p-3 bg-rose-50 rounded-lg border border-rose-200 text-[11px] text-rose-900">
              <span className="text-rose-700 font-bold">High Risk:</span> Any estimated exposure above{' '}
              <strong className="font-mono text-rose-900">{localConfig.riskThresholds.moderateMax} ppm·h</strong>
            </div>
          </div>
        </div>

        {/* Environmental Diffusion & Thermal Correction Settings */}
        <div className="bg-white border border-slate-200 rounded-2xl p-5 shadow-xs space-y-4">
          <div className="flex items-center gap-2 border-b border-slate-200 pb-2.5">
            <Thermometer className="w-4 h-4 text-cyan-600" />
            <h2 className="text-xs font-bold text-slate-900 uppercase tracking-wider font-mono">
              3. Diffusion Physics & Ambient Temperature
            </h2>
          </div>

          <div className="space-y-3 text-xs">
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <div>
                <label className="block text-slate-700 font-bold mb-1">Temp Coeff (%/°C)</label>
                <input
                  type="number"
                  step="0.001"
                  value={localConfig.tempCoefficient}
                  onChange={(e) =>
                    setLocalConfig({
                      ...localConfig,
                      tempCoefficient: parseFloat(e.target.value) || 0.018,
                    })
                  }
                  className="w-full bg-slate-50 border border-slate-300 rounded-lg p-2.5 text-slate-900 font-mono font-medium focus:border-black focus:outline-none"
                />
              </div>

              <div>
                <label className="block text-slate-700 font-bold mb-1">Humidity Coeff (%/%RH)</label>
                <input
                  type="number"
                  step="0.001"
                  value={localConfig.humidityCoefficient}
                  onChange={(e) =>
                    setLocalConfig({
                      ...localConfig,
                      humidityCoefficient: parseFloat(e.target.value) || 0.004,
                    })
                  }
                  className="w-full bg-slate-50 border border-slate-300 rounded-lg p-2.5 text-slate-900 font-mono font-medium focus:border-black focus:outline-none"
                />
              </div>
            </div>

            <div className="p-3 bg-cyan-50 rounded-lg border border-cyan-200 text-[11px] text-cyan-900">
              <span className="text-cyan-800 font-bold">Ambient Correction:</span> Adjusts colorimetric sensor response dynamically for plant temperatures deviating from reference 25°C and 50% RH.
            </div>
          </div>
        </div>
      </div>

      {/* 3. Reference Color Targets Display */}
      <div className="bg-white border border-slate-200 rounded-2xl p-5 shadow-xs space-y-3">
        <div className="flex items-center justify-between border-b border-slate-200 pb-2.5">
          <div className="flex items-center gap-2">
            <Layers className="w-4 h-4 text-black" />
            <h2 className="text-xs font-bold text-slate-900 uppercase tracking-wider font-mono">
              4. Printed Reference Color Calibration Targets
            </h2>
          </div>
          <span className="text-[11px] text-slate-500 font-medium">D65 Standard Illuminant</span>
        </div>

        <div className="grid grid-cols-2 sm:grid-cols-5 gap-3">
          {localConfig.referenceColors.map((ref, idx) => (
            <div key={idx} className="bg-slate-50 p-3 rounded-xl border border-slate-200 space-y-2 text-center">
              <span className="text-xs font-bold text-slate-800 block">{ref.name}</span>
              <div
                className="w-full h-10 rounded-lg border border-slate-300 shadow-inner mx-auto"
                style={{ backgroundColor: ref.hex }}
              />
              <div className="text-[10px] font-mono text-slate-500 space-y-0.5">
                <div>RGB: [{ref.expectedRgb.join(', ')}]</div>
                <div className="text-slate-900 font-bold">{ref.hex}</div>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Reset to Factory Defaults */}
      <div className="pt-2 flex justify-end">
        <SpecularButton
          id="calibration-reset-defaults-btn"
          onClick={() => setIsResetConfirmOpen(true)}
          size="sm"
          radius={12}
          tint="#f8fafc"
          tintOpacity={1}
          textColor="#475569"
          lineColor="#f43f5e"
          baseColor="#cbd5e1"
          className="px-4 py-2.5 font-bold text-xs border border-slate-300 shadow-xs"
        >
          <RotateCcw className="w-4 h-4 text-slate-500" />
          <span>RESET TO FACTORY DEFAULTS</span>
        </SpecularButton>
      </div>

      {/* Modal: Confirm Reset Defaults */}
      {isResetConfirmOpen && (
        <div className="fixed inset-0 z-50 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white border border-slate-200 rounded-2xl max-w-sm w-full p-6 space-y-4 shadow-2xl animate-in fade-in zoom-in duration-150">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-xl bg-rose-100 text-rose-600 flex items-center justify-center shrink-0">
                <RotateCcw className="w-5 h-5" />
              </div>
              <div>
                <h3 className="text-base font-bold text-slate-900 font-mono">
                  RESET TO DEFAULTS?
                </h3>
                <p className="text-xs text-slate-500 font-medium">
                  Factory Calibration & Thresholds
                </p>
              </div>
            </div>

            <p className="text-xs text-slate-600 leading-relaxed">
              Reset all calibration curves, exposure thresholds, and optical parameters to factory calibration values?
            </p>

            <div className="flex gap-3 pt-2">
              <button
                type="button"
                onClick={() => setIsResetConfirmOpen(false)}
                className="flex-1 py-2.5 bg-slate-100 hover:bg-slate-200 text-slate-700 font-bold rounded-xl border border-slate-300 text-xs transition-colors"
              >
                Cancel
              </button>
              <button
                type="button"
                id="confirm-reset-calibration-btn"
                onClick={() => {
                  onResetConfig();
                  setLocalConfig({ ...storageService.getConfig() });
                  setIsResetConfirmOpen(false);
                }}
                className="flex-1 py-2.5 bg-rose-600 hover:bg-rose-700 text-white font-bold rounded-xl text-xs shadow-md shadow-rose-600/20 active:scale-95 transition-all"
              >
                Reset Defaults
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
