import React, { useState } from 'react';
import { ArrowRight, Sparkles, Zap } from 'lucide-react';
import { motion } from 'motion/react';
import Strands from './Strands';
import { DoseGuardLogo } from './DoseGuardLogo';
import { VintageDoseGuardText } from './VintageDoseGuardText';
import { HexavoltDevModal } from './HexavoltDevModal';

interface LandingHeroProps {
  onGetStarted: () => void;
  onOpenAbout?: () => void;
  onOpenFeatures?: () => void;
  onOpenDev?: () => void;
}

export const LandingHero: React.FC<LandingHeroProps> = ({
  onGetStarted,
  onOpenAbout,
  onOpenDev,
}) => {
  const [isDevModalOpen, setIsDevModalOpen] = useState(false);

  const handleDevClick = () => {
    if (onOpenDev) {
      onOpenDev();
    } else {
      setIsDevModalOpen(true);
    }
  };

  return (
    <div className="relative w-full h-screen min-h-screen bg-white text-slate-900 flex flex-col items-center justify-between overflow-hidden select-none font-sans py-4 sm:py-8">
      {/* Hexavolt Developer Modal */}
      <HexavoltDevModal
        isOpen={isDevModalOpen}
        onClose={() => setIsDevModalOpen(false)}
      />

      {/* Dynamic Background: WebGL Strands in Orange & Gold Spectrum */}
      <div className="absolute inset-0 z-0 opacity-90 pointer-events-none">
        <Strands
          colors={['#EA580C', '#F97316', '#FB923C', '#F59E0B', '#FFA500']}
          count={3}
          speed={0.45}
          amplitude={0.65}
          waviness={0.9}
          thickness={1.1}
          glow={2.6}
          taper={3.0}
          spread={0.95}
          intensity={0.9}
          saturation={1.8}
          opacity={0.95}
          scale={1.35}
          glass={false}
          className="w-full h-full"
        />
      </div>

      {/* Ambient White & Radiant Glow Gradients */}
      <div className="absolute inset-0 z-0 bg-radial from-transparent via-white/30 to-white/80 pointer-events-none" />
      <div className="absolute top-0 inset-x-0 h-40 bg-gradient-to-b from-white via-white/60 to-transparent pointer-events-none" />
      <div className="absolute bottom-0 inset-x-0 h-48 bg-gradient-to-t from-white via-white/80 to-transparent pointer-events-none" />

      {/* Floating Glass Top Bar */}
      <motion.nav
        initial={{ opacity: 0, y: -16 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.6, ease: [0.16, 1, 0.3, 1] }}
        className="relative z-20 w-full max-w-4xl px-4 sm:px-6 pt-1 sm:pt-2"
      >
        <div className="w-full mx-auto px-4 sm:px-6 py-2 sm:py-2.5 rounded-full bg-slate-900/10 sm:bg-slate-900/8 hover:bg-slate-900/15 backdrop-blur-2xl border border-white/80 shadow-[0_10px_35px_rgba(0,0,0,0.06),inset_0_1px_2px_rgba(255,255,255,0.9)] flex items-center justify-between transition-all duration-300">
          {/* Brand: Logo + H2S */}
          <div className="flex items-center gap-2 sm:gap-2.5">
            <div className="w-7 h-7 sm:w-8 sm:h-8 rounded-full bg-white/90 backdrop-blur-md flex items-center justify-center p-0.5 shadow-2xs border border-orange-200/80 shrink-0">
              <DoseGuardLogo size={24} className="w-5 h-5 sm:w-6 sm:h-6 drop-shadow-xs" />
            </div>
            <span className="text-sm sm:text-base font-black tracking-tight text-slate-900 font-sans">
              Sulfex
            </span>
          </div>

          {/* Links & DEV Button */}
          <div className="flex items-center gap-3 sm:gap-5">
            <button
              id="topbar-about-btn"
              type="button"
              onClick={onOpenAbout}
              className="text-xs sm:text-sm font-medium text-slate-800 hover:text-orange-600 transition-colors cursor-pointer"
            >
              About
            </button>
            <button
              id="topbar-dev-btn"
              type="button"
              onClick={handleDevClick}
              className="inline-flex items-center gap-1.5 py-1.5 px-4 sm:px-5 rounded-full bg-gradient-to-r from-purple-600 via-indigo-600 to-blue-600 hover:from-purple-700 hover:to-blue-700 text-white font-mono font-bold text-xs sm:text-sm tracking-wider uppercase shadow-[0_4px_14px_rgba(124,58,237,0.35)] hover:shadow-[0_6px_20px_rgba(124,58,237,0.45)] active:scale-95 transition-all duration-200 cursor-pointer"
            >
              <Zap className="w-3.5 h-3.5 text-yellow-300 fill-yellow-300" />
              <span>DEV</span>
            </button>
          </div>
        </div>
      </motion.nav>

      {/* Top Header: Welcome Typography & Vintage 3D Script Text Effect */}
      <header className="relative z-10 w-full max-w-2xl px-6 flex flex-col items-center text-center mt-1 sm:mt-2">
        <motion.div
          initial={{ opacity: 0, y: -15 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6, delay: 0.1, ease: [0.16, 1, 0.3, 1] }}
          className="flex flex-col items-center w-full"
        >
          {/* Clean WELCOME TO Typography */}
          <div className="inline-flex items-center gap-2 mb-1 sm:mb-2">
            <Sparkles className="w-4 h-4 sm:w-5 sm:h-5 text-orange-600 animate-pulse shrink-0" />
            <span className="text-xs sm:text-sm md:text-base font-mono font-black tracking-widest text-orange-600 uppercase drop-shadow-2xs">
              WELCOME TO
            </span>
          </div>

          {/* Clear Smooth 3D Text Effect for DoseGuard in Orange, White and Black */}
          <div className="w-full flex items-center justify-center my-0 sm:my-1 transform hover:scale-[1.03] transition-transform duration-300">
            <VintageDoseGuardText size="responsive" />
          </div>

          {/* Subtitle */}
          <p className="text-xs sm:text-sm md:text-base font-semibold text-slate-800 tracking-wide max-w-md mt-1">
            Smart H₂S Exposure Monitoring &amp; Safety
          </p>
        </motion.div>
      </header>

      {/* Bottom Section: Transparent Liquid Glass CTA Button */}
      <footer className="relative z-10 w-full max-w-md px-6 flex flex-col items-center justify-center mb-4 sm:mb-8">
        <motion.div
          initial={{ opacity: 0, scale: 0.92, y: 15 }}
          animate={{ opacity: 1, scale: 1, y: 0 }}
          transition={{ duration: 0.6, delay: 0.15, ease: [0.16, 1, 0.3, 1] }}
          className="w-full flex flex-col items-center justify-center"
        >
          {/* Liquid Glass Button with Orange & Black accents */}
          <button
            id="landing-get-started-btn"
            onClick={onGetStarted}
            type="button"
            className="group relative w-full sm:w-84 py-4 px-8 rounded-2xl bg-white/70 hover:bg-white/90 backdrop-blur-2xl border border-slate-300/80 hover:border-orange-500 text-slate-900 font-mono font-black text-sm sm:text-base tracking-widest uppercase shadow-[0_10px_25px_rgba(0,0,0,0.05),inset_0_1px_2px_rgba(255,255,255,1)] hover:shadow-[0_12px_30px_rgba(249,115,22,0.2)] hover:scale-[1.02] active:scale-[0.97] transition-all duration-200 flex items-center justify-center gap-3 transform-gpu cursor-pointer"
          >
            <span className="relative z-10 text-slate-950 font-black tracking-widest">
              GET STARTED
            </span>
            <ArrowRight className="relative z-10 w-4 h-4 sm:w-5 sm:h-5 text-orange-600 group-hover:translate-x-1.5 transition-transform duration-200" />
          </button>
        </motion.div>
      </footer>
    </div>
  );
};

export default LandingHero;
