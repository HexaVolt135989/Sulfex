import React, { useState } from 'react';
import {
  ScanLine,
  Activity,
  Users,
  Search,
  SlidersHorizontal,
  Zap,
  FolderCheck,
  Shield,
  ArrowRight,
  Lock,
  ChevronRight,
  BarChart3,
} from 'lucide-react';
import { ActiveTab, ExposureScanRecord, WorkerProfile } from '../types';
import { SAMPLE_BADGES, SampleBadgeSpec } from '../services/sampleWristbandGenerator';

interface HomeScreenProps {
  setActiveTab: (tab: ActiveTab) => void;
  workers: WorkerProfile[];
  scans: ExposureScanRecord[];
  onSelectSampleBadge: (badge: SampleBadgeSpec) => void;
}

export const HomeScreen: React.FC<HomeScreenProps> = React.memo(({
  setActiveTab,
  workers,
  scans,
  onSelectSampleBadge,
}) => {
  const [searchQuery, setSearchQuery] = useState('');

  const displayWorkers = workers;

  const filteredWorkers = displayWorkers.filter((w) => {
    const q = searchQuery.toLowerCase();
    const name = (w.name || '').toLowerCase();
    const dept = (w.department || '').toLowerCase();
    const badge = (w.assignedBadgeId || '').toLowerCase();
    const role = (w.role || '').toLowerCase();
    const id = (w.id || '').toLowerCase();
    return name.includes(q) || dept.includes(q) || badge.includes(q) || role.includes(q) || id.includes(q);
  });

  return (
    <div className="space-y-5 max-w-xl mx-auto pb-24">
      {/* 1. Translucent Frosted Search Bar with Filter */}
      <div className="flex items-center gap-2.5">
        <div className="flex-1 flex items-center gap-2.5 px-4 py-2.5 rounded-full bg-white/50 backdrop-blur-xl border border-white/80 shadow-xs focus-within:bg-white/80 transition-all">
          <Search className="w-4 h-4 text-slate-500 shrink-0" />
          <input
            id="home-search-input"
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="Search..."
            className="w-full bg-transparent text-sm text-slate-900 placeholder-slate-500 font-medium focus:outline-none"
          />
        </div>

        <button
          id="home-search-filter-btn"
          onClick={() => setActiveTab('history')}
          type="button"
          className="w-10 h-10 rounded-full bg-white/60 backdrop-blur-xl border border-white/80 text-slate-700 hover:text-slate-950 flex items-center justify-center shadow-xs active:scale-95 transition-all cursor-pointer"
          title="Filter and Search All Records"
        >
          <SlidersHorizontal className="w-4 h-4" />
        </button>
      </div>

      {/* Horizontal Gradient Quick Cards (Activity & Workers & Stats) */}
      <div className="grid grid-cols-3 gap-3">
        {/* Card 1: Warm Peach Card ("Activity") */}
        <div
          id="quick-card-scan"
          onClick={() => setActiveTab('scan')}
          className="group relative overflow-hidden rounded-[28px] bg-gradient-to-br from-[#FFE3D3] via-[#FED7AA] to-[#FDBA74] p-4 shadow-sm hover:shadow-md transition-all cursor-pointer flex flex-col justify-between min-h-[135px]"
        >
          <div>
            <h4 className="text-base sm:text-lg font-black text-slate-950 tracking-tight leading-tight">
              Activity
            </h4>
            <p className="text-[11px] font-bold text-amber-900/80 mt-0.5">
              Scan Station
            </p>
          </div>

          <div className="flex justify-end">
            <div className="w-9 h-9 rounded-full bg-[#EA580C] text-white flex items-center justify-center shadow-sm group-hover:scale-110 transition-transform">
              <Zap className="w-4 h-4 fill-white text-white" />
            </div>
          </div>
        </div>

        {/* Card 2: Soft Lavender Card ("Workers") */}
        <div
          id="quick-card-workers"
          onClick={() => setActiveTab('workers')}
          className="group relative overflow-hidden rounded-[28px] bg-gradient-to-br from-[#EDE9FE] via-[#DDD6FE] to-[#C4B5FD] p-4 shadow-sm hover:shadow-md transition-all cursor-pointer flex flex-col justify-between min-h-[135px]"
        >
          <div>
            <h4 className="text-base sm:text-lg font-black text-slate-950 tracking-tight leading-tight">
              Workers
            </h4>
            <p className="text-[11px] font-bold text-purple-900/80 mt-0.5">
              {workers.length || 6} Active
            </p>
          </div>

          <div className="flex justify-end">
            <div className="w-9 h-9 rounded-full bg-[#8B5CF6] text-white flex items-center justify-center shadow-sm group-hover:scale-110 transition-transform">
              <Users className="w-4 h-4 text-white" />
            </div>
          </div>
        </div>

        {/* Card 3: Soft Sky Blue Card ("Stats") */}
        <div
          id="quick-card-stats"
          onClick={() => setActiveTab('dashboard')}
          className="group relative overflow-hidden rounded-[28px] bg-gradient-to-br from-[#E0F2FE] via-[#BAE6FD] to-[#7DD3FC] p-4 shadow-sm hover:shadow-md transition-all cursor-pointer flex flex-col justify-between min-h-[135px]"
        >
          <div>
            <h4 className="text-base sm:text-lg font-black text-slate-950 tracking-tight leading-tight">
              Stats
            </h4>
            <p className="text-[11px] font-bold text-sky-950/80 mt-0.5">
              Analytics
            </p>
          </div>

          <div className="flex justify-end">
            <div className="w-9 h-9 rounded-full bg-[#0284C7] text-white flex items-center justify-center shadow-sm group-hover:scale-110 transition-transform">
              <BarChart3 className="w-4 h-4 text-white" />
            </div>
          </div>
        </div>
      </div>

      {/* 4. Section: Monitored Team */}
      <div className="space-y-2">
        <h3 className="text-xs font-black text-slate-800 tracking-wide">
          Recent Scans & Team
        </h3>

        <div className="bg-white rounded-[32px] p-2 shadow-[0_4px_24px_rgba(0,0,0,0.04)] border border-white/80 divide-y divide-slate-100">
          {filteredWorkers.length === 0 ? (
            <div className="p-4 text-center text-xs text-slate-500 font-medium">
              No workers match "{searchQuery}"
            </div>
          ) : (
            filteredWorkers.slice(0, 3).map((w, idx) => {
              const dose = w.cumulativeExposurePpmH ?? 0;
              const isHigh = dose > 25 || w.status === 'RESTRICTED';
              const isModerate = dose > 10 && dose <= 25;
              const avatarBg = idx === 0 ? 'bg-amber-100 text-amber-900' : idx === 1 ? 'bg-rose-100 text-rose-900' : 'bg-sky-100 text-sky-900';

              return (
                <div
                  key={w.id}
                  onClick={() => setActiveTab('workers')}
                  className="flex items-center justify-between p-3 rounded-2xl hover:bg-slate-50 transition-colors cursor-pointer group"
                >
                  <div className="flex items-center gap-3">
                    {/* Worker Avatar with distinct ring */}
                    <div className={`w-10 h-10 rounded-full ${avatarBg} border-2 border-white flex items-center justify-center font-black text-xs shadow-2xs shrink-0 group-hover:scale-105 transition-transform`}>
                      {w.name.split(' ').map((n) => n[0]).join('')}
                    </div>

                    <div>
                      <h4 className="text-sm font-extrabold text-slate-900 leading-tight">
                        {w.name}
                      </h4>
                      <p className="text-[11px] text-slate-500 font-medium">
                        {w.department} • {w.shift} • <span className="font-mono font-bold text-slate-800">{dose.toFixed(1)} ppm·h</span>
                      </p>
                    </div>
                  </div>

                  {/* Status Indicator */}
                  <div className="flex items-center gap-2">
                    <span className={`text-[10px] font-black uppercase tracking-wider px-2.5 py-1 rounded-full ${
                      isHigh
                        ? 'bg-rose-100 text-rose-800 border border-rose-200'
                        : isModerate
                        ? 'bg-amber-100 text-amber-900 border border-amber-200'
                        : 'bg-emerald-100 text-emerald-900 border border-emerald-200'
                    }`}>
                      {isHigh ? 'High' : isModerate ? 'Caution' : 'Safe'}
                    </span>
                    <ChevronRight className="w-4 h-4 text-slate-300 group-hover:translate-x-0.5 transition-transform" />
                  </div>
                </div>
              );
            })
          )}
        </div>
      </div>

      {/* 5. Section: Safety Surveillance */}
      <div className="space-y-2">
        <h3 className="text-xs font-black text-slate-800 tracking-wide">
          Safety Surveillance
        </h3>

        <div className="bg-white rounded-[32px] p-3 shadow-[0_4px_24px_rgba(0,0,0,0.04)] border border-white/80">
          <div
            onClick={() => setActiveTab('dashboard')}
            className="flex items-center justify-between p-2 rounded-2xl hover:bg-slate-50 transition-colors cursor-pointer group"
          >
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-2xl bg-slate-100 flex items-center justify-center text-slate-800 shrink-0">
                <Lock className="w-4 h-4 text-slate-700" />
              </div>

              <div>
                <h4 className="text-sm font-extrabold text-slate-900 leading-tight">
                  Zone A - Hydrocarbon Reformer
                </h4>
                <p className="text-[11px] text-slate-500 font-medium">
                  Optical normalizer active • 28°C ambient
                </p>
              </div>
            </div>

            {/* Black Pill Badge "2" */}
            <div className="w-5 h-5 rounded-full bg-black text-white flex items-center justify-center text-[11px] font-black shadow-2xs">
              2
            </div>
          </div>
        </div>
      </div>

      {/* 6. FEED CARD (Swapped here where Field Operations was!) */}
      <div className="space-y-2">
        <div className="flex items-center justify-between">
          <h3 className="text-xs font-black text-slate-800 tracking-wide">
            Feed
          </h3>
          <button
            onClick={() => setActiveTab('history')}
            className="text-[11px] font-bold text-slate-600 hover:text-slate-900 transition-colors cursor-pointer"
          >
            See all ({scans.length})
          </button>
        </div>

        {/* Soft Mint Gradient Card (Matching Image 2 exactly) */}
        <div
          id="quick-card-history"
          onClick={() => setActiveTab('history')}
          className="group relative overflow-hidden rounded-[32px] bg-gradient-to-br from-[#D1FAE5] via-[#A7F3D0] to-[#6EE7B7] p-5 shadow-sm hover:shadow-md transition-all cursor-pointer flex items-center justify-between"
        >
          <div>
            <h4 className="text-lg sm:text-xl font-black text-slate-950 tracking-tight leading-tight">
              Feed
            </h4>
            <p className="text-xs font-bold text-emerald-950/90 mt-0.5">
              {scans.length} Scans
            </p>
            <p className="text-[11px] text-emerald-900/80 font-medium mt-1">
              Tap to view exposure audit logs & PDF reports
            </p>
          </div>

          <div className="flex items-center gap-3">
            <div className="w-11 h-11 rounded-full bg-[#10B981] text-white flex items-center justify-center shadow-sm group-hover:scale-110 transition-transform">
              <FolderCheck className="w-5 h-5 text-white" />
            </div>
            <ArrowRight className="w-4 h-4 text-emerald-950 group-hover:translate-x-1 transition-transform" />
          </div>
        </div>
      </div>

      {/* 7. Quick Sample Badges Carousel for 1-Click Testing */}
      <div className="bg-white/80 backdrop-blur-md rounded-[32px] p-4 shadow-[0_4px_24px_rgba(0,0,0,0.03)] border border-white/80 space-y-3">
        <div className="flex items-center justify-between">
          <span className="text-xs font-black text-slate-900">
            Instant Sample Badges
          </span>
          <span className="text-[11px] font-semibold text-slate-400">1-click test</span>
        </div>

        <div className="grid grid-cols-2 sm:grid-cols-3 gap-2">
          {SAMPLE_BADGES.slice(0, 4).map((badge) => (
            <button
              key={badge.id}
              onClick={() => onSelectSampleBadge(badge)}
              type="button"
              className="p-2.5 rounded-2xl bg-slate-50 hover:bg-amber-50/60 border border-slate-200/80 hover:border-amber-300 transition-all text-left flex items-center justify-between group active:scale-95 cursor-pointer"
            >
              <div className="flex items-center gap-2 min-w-0">
                <div
                  className="w-5 h-5 rounded-md shrink-0 shadow-inner border border-black/10"
                  style={{ backgroundColor: `rgb(${badge.stripColorRgb.join(',')})` }}
                />
                <div className="truncate">
                  <p className="text-xs font-bold text-slate-800 group-hover:text-amber-950 truncate">
                    {badge.name}
                  </p>
                  <p className="text-[10px] text-slate-400 font-mono">
                    {badge.dosePpmH > 0 ? `${badge.dosePpmH} ppm·h` : 'Baseline'}
                  </p>
                </div>
              </div>
              <ArrowRight className="w-3.5 h-3.5 text-slate-400 group-hover:text-amber-600 shrink-0 ml-1" />
            </button>
          ))}
        </div>
      </div>
    </div>
  );
});
