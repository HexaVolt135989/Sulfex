import React, { useState } from 'react';
import { Sparkles, Download, ArrowRight, X, Sliders, Shield, Sun, Eye } from 'lucide-react';
import {
  SAMPLE_BADGES,
  SampleBadgeSpec,
  generateSampleBadgeDataUrl,
} from '../services/sampleWristbandGenerator';
import { SpecularButton } from './SpecularButton';

interface BadgeGeneratorModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSelectBadgeForScan: (spec: SampleBadgeSpec) => void;
}

export const BadgeGeneratorModal: React.FC<BadgeGeneratorModalProps> = ({
  isOpen,
  onClose,
  onSelectBadgeForScan,
}) => {
  const [selectedPreset, setSelectedPreset] = useState<SampleBadgeSpec>(SAMPLE_BADGES[2]);
  const [customDose, setCustomDose] = useState<number>(13.5);
  const [isLowLight, setIsLowLight] = useState<boolean>(false);
  const [isGlare, setIsGlare] = useState<boolean>(false);
  const [isExpired, setIsExpired] = useState<boolean>(false);

  if (!isOpen) return null;

  // Build active spec
  const activeSpec: SampleBadgeSpec = {
    ...selectedPreset,
    dosePpmH: customDose,
    lightingArtifact: isLowLight ? 'low_light' : isGlare ? 'glare' : 'normal',
    expiryStatus: isExpired ? 'EXPIRED' : 'VALID',
    expiryColorRgb: isExpired ? [239, 68, 68] : [34, 197, 94],
    // Compute dynamic strip color based on dose
    stripColorRgb: [
      Math.max(45, Math.round(245 - (customDose / 50) * 175)),
      Math.max(35, Math.round(238 - (customDose / 50) * 180)),
      Math.max(25, Math.round(220 - (customDose / 50) * 180)),
    ],
  };

  const previewDataUrl = generateSampleBadgeDataUrl(activeSpec);

  const handleDownload = () => {
    const link = document.createElement('a');
    link.download = `H2S_Dosimeter_Badge_${customDose}ppmh.png`;
    link.href = previewDataUrl;
    link.click();
  };

  const handleSendToScanner = () => {
    onSelectBadgeForScan(activeSpec);
      onClose();
  };

  const getBadgeLabels = (badge: SampleBadgeSpec) => {
    if (badge.id === 'sample_expired') return { main: 'Expired Badge', sub: 'Control Degraded' };
    if (badge.id === 'sample_low_light') return { main: 'Low-Light Demo', sub: 'Shadow / Dim' };
    const parts = badge.name.split('—');
    return {
      main: `${badge.dosePpmH.toFixed(1)} ppm·h`,
      sub: parts[1] ? parts[1].trim().replace(/\(.*\)/, '').trim() : badge.description,
    };
  };

  return (
    <div className="fixed inset-0 z-50 bg-slate-900/60 backdrop-blur-xs overflow-y-auto p-2.5 sm:p-4 md:p-6 flex justify-center items-start sm:items-center">
      <div className="bg-white border border-slate-200 rounded-2xl max-w-2xl w-full p-4 sm:p-6 space-y-4 sm:space-y-5 shadow-2xl my-2 sm:my-6">
        {/* Header */}
        <div className="flex items-start justify-between border-b border-slate-200 pb-3 gap-2.5">
          <div className="flex items-start sm:items-center gap-2.5 min-w-0 flex-1">
            <div className="w-8 h-8 rounded-xl bg-black text-white flex items-center justify-center shrink-0 mt-0.5 sm:mt-0 shadow-sm">
              <Sparkles className="w-4 h-4 text-white" />
            </div>
            <div className="min-w-0 flex-1">
              <div className="flex flex-wrap items-center gap-1.5">
                <h3 className="text-xs sm:text-base font-bold text-slate-900 font-mono tracking-tight">
                  SYNTHETIC DOSIMETER GENERATOR
                </h3>
                <span className="text-[10px] font-bold uppercase bg-black text-white border border-black/20 px-2 py-0.5 rounded-full shadow-2xs">
                  DEMO MODE
                </span>
              </div>
              <p className="text-[11px] sm:text-xs text-slate-500 font-medium mt-0.5 leading-tight">
                Generate and test simulated colorimetric dosimeter wristbands under varied lighting
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 sm:p-2 text-slate-500 hover:text-slate-900 bg-slate-100 hover:bg-slate-200 border border-slate-300 rounded-xl transition-colors shrink-0 cursor-pointer"
            title="Close modal"
          >
            <X className="w-4 h-4 sm:w-5 sm:h-5" />
          </button>
        </div>

        {/* Presets Row */}
        <div>
          <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-2">
            Calibration Level Presets
          </label>
          <div className="grid grid-cols-2 sm:grid-cols-3 gap-2">
            {SAMPLE_BADGES.map((badge) => {
              const labels = getBadgeLabels(badge);
              const isSelected = selectedPreset.id === badge.id;
              return (
                <button
                  key={badge.id}
                  onClick={() => {
                    setSelectedPreset(badge);
                    setCustomDose(badge.dosePpmH);
                    setIsExpired(badge.expiryStatus === 'EXPIRED');
                    setIsLowLight(badge.lightingArtifact === 'low_light');
                    setIsGlare(badge.lightingArtifact === 'glare');
                  }}
                  className={`p-2 sm:p-2.5 rounded-xl text-left border transition-all flex items-center gap-2 min-w-0 cursor-pointer ${
                    isSelected
                      ? 'bg-black border-black text-white font-bold shadow-xs'
                      : 'bg-slate-50 border-slate-200 text-slate-700 hover:bg-slate-100 hover:text-slate-950 font-medium'
                  }`}
                >
                  <div
                    className="w-3.5 h-3.5 sm:w-4 sm:h-4 rounded border border-slate-300 shrink-0 shadow-2xs"
                    style={{ backgroundColor: `rgb(${badge.stripColorRgb.join(',')})` }}
                  />
                  <div className="min-w-0 flex-1 leading-tight">
                    <span className={`block font-bold font-mono text-[11px] sm:text-xs truncate ${isSelected ? 'text-white' : 'text-slate-900'}`}>
                      {labels.main}
                    </span>
                    <span className={`block text-[9.5px] sm:text-[10.5px] font-medium truncate ${isSelected ? 'text-slate-300' : 'text-slate-500'}`}>
                      {labels.sub}
                    </span>
                  </div>
                </button>
              );
            })}
          </div>
        </div>

        {/* Live Preview Image & Controls Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
          {/* Visual Badge Preview */}
          <div className="space-y-2">
            <span className="text-xs font-bold text-slate-600 uppercase tracking-wider block">
              Rendered Wristband Preview
            </span>
            <div className="aspect-[4/3] rounded-xl overflow-hidden bg-slate-900 border border-slate-300 shadow-inner flex items-center justify-center p-2">
              <img
                src={previewDataUrl}
                alt="Simulated Dosimeter Wristband"
                className="w-full h-full object-contain"
              />
            </div>
            <div className="text-xs text-slate-600 flex justify-between px-1 font-medium">
              <span>Resolution: 640 x 480 px</span>
              <span className="font-mono text-slate-900 font-bold">{customDose.toFixed(1)} ppm·h</span>
            </div>
          </div>

          {/* Realtime Adjustment Controls */}
          <div className="space-y-4 text-xs">
            {/* Custom Dose Slider */}
            <div>
              <div className="flex justify-between font-bold text-slate-800 mb-1">
                <span>H2S Exposure Dose:</span>
                <span className="font-mono text-slate-900 font-bold">{customDose.toFixed(1)} ppm·h</span>
              </div>
              <input
                type="range"
                min={0}
                max={50}
                step={0.5}
                value={customDose}
                onChange={(e) => setCustomDose(parseFloat(e.target.value))}
                className="w-full accent-black cursor-pointer"
              />
              <div className="flex justify-between text-[10px] text-slate-500 font-mono font-semibold">
                <span>0.0 (Clean)</span>
                <span>25.0 (Moderate)</span>
                <span>50.0 (High Danger)</span>
              </div>
            </div>

            {/* Environmental / Optical Noise Toggles */}
            <div className="space-y-2 pt-2 border-t border-slate-200">
              <span className="font-bold text-slate-800 block text-xs uppercase tracking-wider">
                Lighting & Condition Simulator
              </span>

              <label className="flex items-center gap-2.5 p-2.5 bg-slate-50 rounded-lg border border-slate-200 cursor-pointer hover:bg-slate-100 transition-colors">
                <input
                  type="checkbox"
                  checked={isLowLight}
                  onChange={(e) => {
                    setIsLowLight(e.target.checked);
                    if (e.target.checked) setIsGlare(false);
                  }}
                  className="rounded text-black focus:ring-0 w-4 h-4"
                />
                <span className="text-slate-800 font-medium">Simulate Dim / Low-Light Environment</span>
              </label>

              <label className="flex items-center gap-2.5 p-2.5 bg-slate-50 rounded-lg border border-slate-200 cursor-pointer hover:bg-slate-100 transition-colors">
                <input
                  type="checkbox"
                  checked={isGlare}
                  onChange={(e) => {
                    setIsGlare(e.target.checked);
                    if (e.target.checked) setIsLowLight(false);
                  }}
                  className="rounded text-black focus:ring-0 w-4 h-4"
                />
                <span className="text-slate-800 font-medium">Simulate Flash Glare / Optical Reflection</span>
              </label>

              <label className="flex items-center gap-2.5 p-2.5 bg-slate-50 rounded-lg border border-slate-200 cursor-pointer hover:bg-slate-100 transition-colors">
                <input
                  type="checkbox"
                  checked={isExpired}
                  onChange={(e) => setIsExpired(e.target.checked)}
                  className="rounded text-black focus:ring-0 w-4 h-4"
                />
                <span className="text-slate-800 font-medium">Simulate Degraded Control Reagent Patch</span>
              </label>
            </div>
          </div>
        </div>

        {/* Action Buttons */}
        <div className="flex flex-col sm:flex-row gap-3 pt-2">
          <SpecularButton
            onClick={handleDownload}
            size="sm"
            radius={14}
            tint="#ffffff"
            tintOpacity={0.9}
            textColor="#1e293b"
            lineColor="#ffffff"
            baseColor="#e2e8f0"
            className="px-4 py-3 font-bold text-xs border border-slate-200 shadow-2xs backdrop-blur-md"
          >
            <Download className="w-4 h-4 text-slate-700" />
            <span>Download PNG</span>
          </SpecularButton>

          <SpecularButton
            id="modal-send-to-scanner-btn"
            onClick={handleSendToScanner}
            size="md"
            radius={16}
            tint="#000000"
            tintOpacity={0.95}
            textColor="#ffffff"
            lineColor="#ffffff"
            baseColor="#18181b"
            intensity={1.3}
            className="flex-1 py-3.5 font-bold text-xs sm:text-sm shadow-xl shadow-black/20"
          >
            <span>SEND TO SCANNER & ANALYZE</span>
            <ArrowRight className="w-4 h-4 text-white" />
          </SpecularButton>
        </div>
      </div>
    </div>
  );
};
