import React, { useState, useEffect } from 'react';
import {
  ShieldCheck,
  AlertTriangle,
  AlertOctagon,
  Save,
  RotateCcw,
  History,
  Activity,
  Calendar,
  Clock,
  User,
  Thermometer,
  Droplets,
  ChevronDown,
  ChevronUp,
  Download,
  Share2,
  CheckCircle2,
  ExternalLink,
} from 'lucide-react';
import confetti from 'canvas-confetti';
import { ColorimetricAnalysis, ExposureScanRecord } from '../types';
import { ImageAnalysisOverlay } from './ImageAnalysisOverlay';
import { SpecularButton } from './SpecularButton';
import { DoseGuardLogo } from './DoseGuardLogo';

interface ResultCardProps {
  scanResult: ExposureScanRecord;
  onSave: () => void;
  onScanAgain: () => void;
  onViewHistory: () => void;
  isAlreadySaved?: boolean;
}

export const ResultCard: React.FC<ResultCardProps> = ({
  scanResult,
  onSave,
  onScanAgain,
  onViewHistory,
  isAlreadySaved = false,
}) => {
  const [showSpectralDetails, setShowSpectralDetails] = useState(false);
  const [saved, setSaved] = useState(isAlreadySaved);

  useEffect(() => {
    if (scanResult.riskLevel === 'LOW' && scanResult.badgeValidity === 'VALID') {
      confetti({
        particleCount: 40,
        spread: 60,
        origin: { y: 0.7 },
        colors: ['#10b981', '#f59e0b', '#38bdf8'],
      });
    }
  }, [scanResult]);

  const handleSave = () => {
    if (!saved) {
      onSave();
      setSaved(true);
    }
  };

  const isSafe = scanResult.riskLevel === 'LOW';
  const isDanger = scanResult.riskLevel === 'HIGH';

  const riskBadgeStyles = {
    LOW: {
      bg: 'bg-emerald-50 border-emerald-300 text-emerald-900',
      badgeBg: 'bg-emerald-600 text-white',
      glow: 'shadow-emerald-500/20 ring-2 ring-emerald-400',
      statusText: 'SAFE — LOW EXPOSURE',
      icon: ShieldCheck,
      desc: 'Lead strip color test PASSED. Reagent shows minimal color change (within safe baseline limits).',
    },
    MODERATE: {
      bg: 'bg-amber-50 border-amber-300 text-amber-900',
      badgeBg: 'bg-amber-500 text-slate-950',
      glow: 'shadow-amber-500/20 ring-2 ring-amber-400',
      statusText: 'CAUTION — MODERATE EXPOSURE',
      icon: AlertTriangle,
      desc: 'Lead strip shows visible darkening. Approaching occupational safety limit. Re-evaluate area ventilation.',
    },
    HIGH: {
      bg: 'bg-rose-50 border-rose-300 text-rose-900',
      badgeBg: 'bg-rose-600 text-white',
      glow: 'shadow-rose-500/20 ring-2 ring-rose-400',
      statusText: 'DANGER — HIGH EXPOSURE',
      icon: AlertOctagon,
      desc: 'Lead strip has darkened significantly (Lead Sulfide PbS reaction). Immediate supervisor & safety notification mandatory!',
    },
  }[scanResult.riskLevel];

  const RiskIcon = riskBadgeStyles.icon;

  const formattedDate = new Date(scanResult.timestamp).toLocaleString('en-GB', {
    day: '2-digit',
    month: 'short',
    year: 'numeric',
    hour: '2-digit',
    minute: '2-digit',
    second: '2-digit',
  });

  const stripRgb: [number, number, number] = 
    scanResult.analysisDetails?.sensingStrip?.normalizedRgb ||
    scanResult.analysisDetails?.sensingStrip?.rawRgb ||
    [240, 230, 210];
  const deltaE = 
    scanResult.analysisDetails?.sensingStrip?.deltaEFromBaseline !== undefined
      ? scanResult.analysisDetails.sensingStrip.deltaEFromBaseline.toFixed(2)
      : '0.00';

  return (
    <div className="max-w-xl mx-auto space-y-5 pb-8">
      {/* Prominent Safe / Danger Banner */}
      <div className={`p-4 sm:p-5 rounded-2xl border-2 flex items-center justify-between gap-4 shadow-md ${riskBadgeStyles.bg}`}>
        <div className="flex items-center gap-3.5">
          <div className={`w-12 h-12 rounded-xl flex items-center justify-center text-white shrink-0 shadow-sm ${
            isSafe ? 'bg-emerald-600' : isDanger ? 'bg-rose-600' : 'bg-amber-500'
          }`}>
            <RiskIcon className="w-7 h-7" />
          </div>
          <div>
            <div className="text-[11px] font-black uppercase tracking-widest text-slate-600 font-mono">
              LEAD STRIP COLOR ANALYSIS
            </div>
            <div className={`text-lg sm:text-xl font-black font-mono ${
              isSafe ? 'text-emerald-800' : isDanger ? 'text-rose-800' : 'text-amber-800'
            }`}>
              {riskBadgeStyles.statusText}
            </div>
          </div>
        </div>

        <div className={`px-3 py-1.5 rounded-xl font-black font-mono text-xs uppercase tracking-wider border shadow-xs ${
          isSafe
            ? 'bg-emerald-100 text-emerald-800 border-emerald-300'
            : isDanger
            ? 'bg-rose-100 text-rose-800 border-rose-300'
            : 'bg-amber-100 text-amber-900 border-amber-300'
        }`}>
          {isSafe ? 'STATUS: SAFE' : isDanger ? 'STATUS: DANGER' : 'STATUS: CAUTION'}
        </div>
      </div>

      {/* Top Card */}
      <div className={`rounded-2xl border bg-white shadow-xl overflow-hidden transition-all ${riskBadgeStyles.glow} border-slate-200`}>
        {/* Header Ribbon */}
        <div className="bg-slate-50 px-5 py-4 border-b border-slate-200 flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-lg bg-white border border-orange-200/80 flex items-center justify-center p-0.5 shadow-2xs">
              <DoseGuardLogo size={24} className="w-full h-full drop-shadow-xs" />
            </div>
            <div>
              <h2 className="text-sm font-black tracking-wider uppercase text-slate-900 font-mono">
                H2S EXPOSURE DOSIMETRY
              </h2>
              <p className="text-[11px] text-slate-500 font-mono font-medium">
                ID: {scanResult.id}
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            {scanResult.isDemo && (
              <span className="px-2.5 py-0.5 rounded bg-purple-100 text-purple-800 border border-purple-300 text-[10px] font-bold tracking-wider uppercase">
                DEMO DATA
              </span>
            )}
            <span className={`px-2.5 py-1 rounded-md text-xs font-bold uppercase tracking-wider ${
              scanResult.badgeValidity === 'VALID'
                ? 'bg-emerald-100 text-emerald-800 border border-emerald-300'
                : 'bg-rose-100 text-rose-800 border border-rose-300'
            }`}>
              BADGE: {scanResult.badgeValidity}
            </span>
          </div>
        </div>

        {/* Primary Exposure Value Spotlight */}
        <div className="p-6 text-center space-y-3 bg-gradient-to-b from-slate-50/70 to-white border-b border-slate-200">
          <span className="text-xs font-bold uppercase tracking-widest text-slate-500">
            Estimated Cumulative Exposure
          </span>

          <div className="flex items-baseline justify-center gap-2">
            <span className="text-5xl sm:text-6xl font-black font-mono tracking-tight text-slate-900">
              {scanResult.estimatedDose.toFixed(1)}
            </span>
            <span className="text-lg sm:text-xl font-bold font-mono text-orange-600">
              ppm·h
            </span>
          </div>

          {/* Lead Acetate Color Swatch Comparison */}
          <div className="py-2 px-3 bg-slate-50 rounded-xl border border-slate-200 inline-flex items-center gap-4 text-xs">
            <div className="flex items-center gap-2">
              <span className="text-slate-500 font-medium">Baseline (Clean):</span>
              <div
                className="w-5 h-5 rounded border border-slate-300 bg-[#fdf8e2] shadow-inner"
                title="Baseline Unexposed Lead Acetate Strip"
              />
            </div>
            <span className="text-slate-300 font-bold">→</span>
            <div className="flex items-center gap-2">
              <span className="text-slate-700 font-bold">Scanned Strip Color:</span>
              <div
                className="w-5 h-5 rounded border border-slate-400 shadow-inner"
                style={{ backgroundColor: `rgb(${stripRgb.join(',')})` }}
                title="Analyzed Sensing Strip Color"
              />
              <span className="font-mono font-bold text-slate-900 text-[11px]">
                ΔE: {deltaE}
              </span>
            </div>
          </div>

          <p className="text-xs text-slate-600 max-w-md mx-auto pt-1 leading-relaxed font-medium">
            {riskBadgeStyles.desc}
          </p>
        </div>

        {/* Worker & Analysis Attributes Grid */}
        <div className="p-5 grid grid-cols-2 sm:grid-cols-3 gap-3 text-xs bg-white">
          <div className="bg-slate-50 p-3 rounded-xl border border-slate-200">
            <div className="text-[10px] text-slate-500 uppercase font-bold flex items-center gap-1 mb-1">
              <User className="w-3.5 h-3.5 text-slate-500" />
              Worker
            </div>
            <div className="font-bold text-slate-900 font-mono text-sm">{scanResult.workerId}</div>
            <div className="text-[11px] text-slate-600 font-medium truncate">{scanResult.workerName}</div>
          </div>

          <div className="bg-slate-50 p-3 rounded-xl border border-slate-200">
            <div className="text-[10px] text-slate-500 uppercase font-bold flex items-center gap-1 mb-1">
              <Clock className="w-3.5 h-3.5 text-slate-500" />
              Shift & Dept
            </div>
            <div className="font-bold text-slate-900 text-sm">{scanResult.shift}</div>
            <div className="text-[11px] text-slate-600 font-medium truncate">{scanResult.department}</div>
          </div>

          <div className="bg-slate-50 p-3 rounded-xl border border-slate-200">
            <div className="text-[10px] text-slate-500 uppercase font-bold flex items-center gap-1 mb-1">
              <ShieldCheck className="w-3.5 h-3.5 text-cyan-600" />
              Confidence
            </div>
            <div className="font-bold text-cyan-700 font-mono text-sm">{scanResult.confidence}%</div>
            <div className="text-[11px] text-slate-500 font-medium">Photometric fit</div>
          </div>

          <div className="bg-slate-50 p-3 rounded-xl border border-slate-200">
            <div className="text-[10px] text-slate-500 uppercase font-bold flex items-center gap-1 mb-1">
              <Activity className="w-3.5 h-3.5 text-emerald-600" />
              Image Quality
            </div>
            <div className={`font-bold text-sm ${
              scanResult.imageQuality === 'GOOD' ? 'text-emerald-700' :
              scanResult.imageQuality === 'MODERATE' ? 'text-amber-700' : 'text-rose-700'
            }`}>
              {scanResult.imageQuality}
            </div>
            <div className="text-[10px] text-slate-500 font-medium">Lighting normalized</div>
          </div>

          <div className="bg-slate-50 p-3 rounded-xl border border-slate-200">
            <div className="text-[10px] text-slate-500 uppercase font-bold flex items-center gap-1 mb-1">
              <Thermometer className="w-3.5 h-3.5 text-amber-600" />
              Temp / RH
            </div>
            <div className="font-bold text-slate-900 text-sm font-mono">
              {scanResult.temperature ?? 25}°C
            </div>
            <div className="text-[11px] text-slate-600 font-mono font-medium">
              {scanResult.humidity ?? 50}% RH comp.
            </div>
          </div>

          <div className="bg-slate-50 p-3 rounded-xl border border-slate-200">
            <div className="text-[10px] text-slate-500 uppercase font-bold flex items-center gap-1 mb-1">
              <Calendar className="w-3.5 h-3.5 text-slate-500" />
              Timestamp
            </div>
            <div className="font-semibold text-slate-900 text-[11px] font-mono leading-tight">
              {formattedDate}
            </div>
          </div>
        </div>

        {/* Disclaimers Footer */}
        <div className="px-5 py-3.5 bg-amber-50/80 border-t border-amber-200 text-xs text-amber-950 space-y-1.5 font-medium">
          <p className="flex items-start gap-2 leading-relaxed">
            <AlertTriangle className="w-4 h-4 text-amber-600 shrink-0 mt-0.5" />
            <span>
              <strong>Prototype classification</strong> — replace with validated occupational limits. This value is an experimental estimate based on colorimetric calibration and should not replace a certified personal H2S gas detector.
            </span>
          </p>
          <p className="text-amber-800/80 text-[11px]">
            Badge validity is independent from H2S exposure reading.
          </p>
        </div>
      </div>

      {/* Accordion: Detailed Spectral & Colorimetry Breakdown */}
      {scanResult.analysisDetails && (
        <div className="space-y-2">
          <button
            id="result-toggle-spectral-btn"
            onClick={() => setShowSpectralDetails(!showSpectralDetails)}
            className="w-full py-3 px-4 rounded-xl bg-white hover:bg-slate-50 border border-slate-300 text-slate-800 text-xs font-bold flex items-center justify-between transition-colors shadow-sm"
          >
            <span className="flex items-center gap-2">
              <Activity className="w-4 h-4 text-orange-600" />
              {showSpectralDetails ? 'Hide Optical Calibration Details' : 'View Optical Calibration Details (ΔE, Gains, Lab)'}
            </span>
            {showSpectralDetails ? <ChevronUp className="w-4 h-4 text-slate-600" /> : <ChevronDown className="w-4 h-4 text-slate-600" />}
          </button>

          {showSpectralDetails && (
            <ImageAnalysisOverlay analysis={scanResult.analysisDetails} />
          )}
        </div>
      )}

      {/* Action Buttons as specified in requirements */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
        <SpecularButton
          id="result-save-btn"
          onClick={handleSave}
          disabled={saved}
          size="md"
          radius={16}
          tint={saved ? '#10b981' : '#000000'}
          tintOpacity={0.95}
          textColor="#ffffff"
          lineColor="#ffffff"
          baseColor={saved ? '#059669' : '#18181b'}
          intensity={1.3}
          className={`px-4 py-3.5 font-bold text-sm shadow-xl transition-all ${
            saved ? 'bg-emerald-600 border border-emerald-400 text-white' : 'shadow-black/20'
          }`}
        >
          {saved ? (
            <>
              <CheckCircle2 className="w-5 h-5 text-white" />
              <span>RESULT SAVED</span>
            </>
          ) : (
            <>
              <Save className="w-5 h-5 text-white" />
              <span>SAVE RESULT</span>
            </>
          )}
        </SpecularButton>

        <SpecularButton
          id="result-scan-again-btn"
          onClick={onScanAgain}
          size="md"
          radius={16}
          tint="#ffffff"
          tintOpacity={0.95}
          textColor="#0f172a"
          lineColor="#ffffff"
          baseColor="#f8fafc"
          intensity={1.0}
          className="px-4 py-3.5 font-bold text-sm border border-slate-300 shadow-sm"
        >
          <RotateCcw className="w-5 h-5 text-slate-800" />
          <span>SCAN AGAIN</span>
        </SpecularButton>

        <SpecularButton
          id="result-view-history-btn"
          onClick={onViewHistory}
          size="md"
          radius={16}
          tint="#ffffff"
          tintOpacity={0.95}
          textColor="#0f172a"
          lineColor="#ffffff"
          baseColor="#f8fafc"
          intensity={1.0}
          className="px-4 py-3.5 font-bold text-sm border border-slate-300 shadow-sm"
        >
          <History className="w-5 h-5 text-slate-800" />
          <span>VIEW HISTORY</span>
        </SpecularButton>
      </div>
    </div>
  );
};
