import React from 'react';

interface DoseGuardLogoProps {
  className?: string;
  size?: number | string;
  showText?: boolean;
}

export const DoseGuardLogo: React.FC<DoseGuardLogoProps> = ({
  className = '',
  size = 32,
  showText = false,
}) => {
  return (
    <svg
      viewBox="0 0 400 400"
      width={size}
      height={size}
      className={`inline-block shrink-0 select-none ${className}`}
      fill="none"
      xmlns="http://www.w3.org/2000/svg"
      role="img"
      aria-label="Sulfex Logo"
    >
      <defs>
        {/* Shield Outer Glow / Shadow */}
        <filter id="dg-shadow" x="-10%" y="-10%" width="120%" height="120%">
          <feDropShadow dx="0" dy="8" stdDeviation="12" floodColor="#ea580c" floodOpacity="0.18" />
        </filter>
        {/* Shield Inner Gradient */}
        <linearGradient id="dg-shield-bg" x1="200" y1="20" x2="200" y2="340" gradientUnits="userSpaceOnUse">
          <stop stopColor="#ffffff" />
          <stop offset="0.85" stopColor="#fffaf5" />
          <stop offset="1" stopColor="#fed7aa" stopOpacity="0.35" />
        </linearGradient>
        {/* Droplet Gradient */}
        <linearGradient id="dg-drop-grad" x1="190" y1="165" x2="190" y2="270" gradientUnits="userSpaceOnUse">
          <stop stopColor="#fb923c" />
          <stop offset="1" stopColor="#ea580c" />
        </linearGradient>
      </defs>

      {/* Main Shield Outline & Background */}
      <path
        d="M200 28 C265 65 315 72 315 180 C315 255 255 310 200 338 C145 310 85 255 85 180 C85 72 135 65 200 28 Z"
        fill="url(#dg-shield-bg)"
        stroke="#f97316"
        strokeWidth="16"
        strokeLinejoin="round"
        strokeLinecap="round"
      />

      {/* Internal Inner Border Accent */}
      <path
        d="M200 42 C255 76 298 83 298 180 C298 245 245 295 200 320 C155 295 102 245 102 180 C102 83 145 76 200 42 Z"
        stroke="#ffedd5"
        strokeWidth="3"
        fill="none"
      />

      {/* Top Text: H₂S */}
      <g id="logo-h2s-text">
        <text
          x="132"
          y="125"
          fontFamily="system-ui, -apple-system, sans-serif"
          fontWeight="900"
          fontSize="68"
          fill="#0f172a"
          letterSpacing="-1"
        >
          H
        </text>
        <text
          x="184"
          y="138"
          fontFamily="system-ui, -apple-system, sans-serif"
          fontWeight="900"
          fontSize="46"
          fill="#f97316"
        >
          2
        </text>
        <text
          x="215"
          y="125"
          fontFamily="system-ui, -apple-system, sans-serif"
          fontWeight="900"
          fontSize="68"
          fill="#0f172a"
          letterSpacing="-1"
        >
          S
        </text>
      </g>

      {/* Colorimetric Exposure Spectrum Bar (6 Steps) */}
      <g id="logo-spectrum-bar" transform="translate(108, 142)">
        {/* Step 1: Safe / Light Yellow */}
        <rect x="0" y="0" width="28" height="19" rx="3" fill="#fde047" />
        {/* Step 2: Very Low / Yellow */}
        <rect x="31" y="0" width="28" height="19" rx="3" fill="#facc15" />
        {/* Step 3: Low / Yellow-Amber */}
        <rect x="62" y="0" width="28" height="19" rx="3" fill="#fbbf24" />
        {/* Step 4: Moderate / Amber */}
        <rect x="93" y="0" width="28" height="19" rx="3" fill="#f59e0b" />
        {/* Step 5: Elevated / Orange */}
        <rect x="124" y="0" width="28" height="19" rx="3" fill="#ea580c" />
        {/* Step 6: Critical / Deep Red-Orange */}
        <rect x="155" y="0" width="28" height="19" rx="3" fill="#dc2626" />
      </g>

      {/* Chemical Droplet with Atomic Molecule */}
      <g id="logo-droplet" transform="translate(142, 172)">
        {/* Teardrop Outline & Fill */}
        <path
          d="M50 0 C50 0 10 50 10 74 C10 98 28 114 50 114 C72 114 90 98 90 74 C90 50 50 0 50 0 Z"
          fill="url(#dg-drop-grad)"
        />

        {/* Inner Molecule Atomic Structure */}
        {/* Molecule Bond Lines */}
        <line x1="50" y1="48" x2="50" y2="76" stroke="#0f172a" strokeWidth="6" strokeLinecap="round" />
        <line x1="50" y1="76" x2="28" y2="92" stroke="#0f172a" strokeWidth="6" strokeLinecap="round" />
        <line x1="50" y1="76" x2="72" y2="92" stroke="#0f172a" strokeWidth="6" strokeLinecap="round" />

        {/* Atom Nodes */}
        <circle cx="50" cy="48" r="9" fill="#0f172a" />
        <circle cx="50" cy="76" r="10" fill="#0f172a" />
        <circle cx="28" cy="92" r="9" fill="#0f172a" />
        <circle cx="72" cy="92" r="9" fill="#0f172a" />
      </g>

      {/* Smartwatch Alarm Device */}
      <g id="logo-smartwatch" transform="translate(254, 168)">
        {/* Top & Bottom Straps */}
        <rect x="23" y="2" width="42" height="16" rx="4" fill="#1e293b" />
        <rect x="23" y="128" width="42" height="18" rx="4" fill="#1e293b" />

        {/* Watch Crown / Button */}
        <rect x="85" y="56" width="6" height="18" rx="2" fill="#ea580c" />

        {/* Watch Outer Bezel */}
        <rect x="6" y="14" width="76" height="92" rx="22" fill="#0f172a" stroke="#ea580c" strokeWidth="6" />

        {/* Watch Display Screen */}
        <rect x="12" y="20" width="64" height="80" rx="16" fill="#ffffff" />

        {/* Sound Waves / Vibration Rings */}
        <path d="M22 52 C19 57 19 63 22 68" stroke="#ea580c" strokeWidth="4" strokeLinecap="round" />
        <path d="M66 52 C69 57 69 63 66 68" stroke="#ea580c" strokeWidth="4" strokeLinecap="round" />

        {/* Alarm Bell Icon */}
        <path
          d="M44 38 C40 38 34 42 34 54 L30 63 C29 65 31 67 33 67 L55 67 C57 67 59 65 58 63 L54 54 C54 42 48 38 44 38 Z"
          fill="#ea580c"
        />
        {/* Bell Clapper */}
        <circle cx="44" cy="71" r="3.5" fill="#ea580c" />
      </g>

      {/* Bottom Text & Emblem (Optional / Full Mode) */}
      {showText && (
        <g id="logo-footer-text">
          <text
            x="115"
            y="370"
            fontFamily="system-ui, -apple-system, sans-serif"
            fontWeight="900"
            fontSize="44"
            fill="#0f172a"
            letterSpacing="0.8"
          >
            SULF<tspan fill="#f97316">EX</tspan>
          </text>
          {/* Base Divider & Shield Checkmark */}
          <line x1="40" y1="388" x2="160" y2="388" stroke="#f97316" strokeWidth="2.5" strokeLinecap="round" />
          <line x1="240" y1="388" x2="360" y2="388" stroke="#f97316" strokeWidth="2.5" strokeLinecap="round" />
          <path
            d="M200 378 L212 384 C212 393 206 399 200 402 C194 399 188 393 188 384 Z"
            fill="#ffffff"
            stroke="#f97316"
            strokeWidth="2"
          />
          <path
            d="M194 389 L198 393 L206 385"
            stroke="#f97316"
            strokeWidth="2.5"
            strokeLinecap="round"
            strokeLinejoin="round"
          />
        </g>
      )}
    </svg>
  );
};

export const SulfexLogo = DoseGuardLogo;
export default DoseGuardLogo;
