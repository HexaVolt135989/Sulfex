import React from 'react';
import { Home, History, ScanLine, LayoutDashboard, Users, Sliders } from 'lucide-react';
import { ActiveTab } from '../types';

interface BottomNavigationProps {
  activeTab: ActiveTab;
  setActiveTab: (tab: ActiveTab) => void;
}

export const BottomNavigation: React.FC<BottomNavigationProps> = ({ activeTab, setActiveTab }) => {
  const tabs: { id: ActiveTab; label: string; icon: React.ComponentType<{ className?: string }> }[] = [
    { id: 'home', label: 'Home', icon: Home },
    { id: 'scan', label: 'Scan', icon: ScanLine },
    { id: 'history', label: 'Feed', icon: History },
    { id: 'dashboard', label: 'Stats', icon: LayoutDashboard },
    { id: 'workers', label: 'Workers', icon: Users },
    { id: 'calibration', label: 'Config', icon: Sliders },
  ];

  return (
    <nav
      id="floating-bottom-dock"
      aria-label="Bottom Navigation Dock"
      className="fixed bottom-5 left-1/2 -translate-x-1/2 z-50 flex items-center gap-1.5 p-1.5 rounded-full bg-white/95 backdrop-blur-2xl border border-slate-200/90 shadow-[0_16px_40px_rgba(76,29,149,0.15),0_2px_8px_rgba(0,0,0,0.04)] max-w-[94vw] transition-all"
    >
      {tabs.map((tab) => {
        const Icon = tab.icon;
        const isActive = activeTab === tab.id;

        return (
          <button
            key={tab.id}
            id={`bottom-nav-${tab.id}`}
            onClick={() => setActiveTab(tab.id)}
            type="button"
            className={`relative flex items-center justify-center transition-all duration-200 cursor-pointer ${
              isActive
                ? 'bg-black text-white rounded-full px-4 py-2 font-black text-xs shadow-md scale-100'
                : 'text-slate-400 hover:text-slate-800 hover:bg-slate-100 p-2.5 rounded-full active:scale-95'
            }`}
            title={tab.label}
          >
            <Icon className={`w-4 h-4 ${isActive ? 'text-white' : 'text-slate-400'}`} />
            {isActive && (
              <span className="ml-1.5 font-bold tracking-tight text-xs whitespace-nowrap">
                {tab.label}
              </span>
            )}
          </button>
        );
      })}
    </nav>
  );
};
