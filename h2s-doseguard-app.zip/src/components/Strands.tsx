import React, { useEffect, useRef } from 'react';
import { Renderer, Program, Mesh, Color, Triangle } from 'ogl';
import './Strands.css';

const MAX_STRANDS = 6;
const MAX_COLORS = 6;

const VERT = `#version 300 es
in vec2 position;
void main() {
  gl_Position = vec4(position, 0.0, 1.0);
}
`;

const FRAG = `#version 300 es
precision mediump float;

uniform float uTime;
uniform vec2 uResolution;
uniform vec3 uColors[${MAX_COLORS}];
uniform int uColorCount;
uniform int uStrandCount;
uniform float uSpeed;
uniform float uAmplitude;
uniform float uWaviness;
uniform float uThickness;
uniform float uGlow;
uniform float uTaper;
uniform float uSpread;
uniform float uHueShift;
uniform float uIntensity;
uniform float uOpacity;
uniform float uScale;
uniform float uSaturation;

out vec4 fragColor;

const float PI = 3.14159265;

vec3 samplePalette(float t) {
  t = fract(t);
  float scaled = t * float(uColorCount);
  int idx = int(floor(scaled));
  float blend = fract(scaled);
  int nextIdx = idx + 1;
  if (nextIdx >= uColorCount) nextIdx = 0;
  return mix(uColors[idx], uColors[nextIdx], blend);
}

void main() {
  vec2 uv = (gl_FragCoord.xy - 0.5 * uResolution) / uResolution.y;
  uv /= max(uScale, 0.0001);

  float e = 0.06 + uIntensity * 0.94;
  float env = pow(max(cos(uv.x * PI * 1.3), 0.0), uTaper);

  vec3 col = vec3(0.0);

  for (int i = 0; i < ${MAX_STRANDS}; i++) {
    if (i >= uStrandCount) break;

    float fi = float(i);
    float ph = fi * 1.7 * uSpread;
    float freq = (2.0 + fi * 0.35) * uWaviness;
    float spd = 1.4 + fi * 1.2;

    float tt = uTime * uSpeed;
    float w = sin(uv.x * freq + tt * spd + ph) * 0.60
            + sin(uv.x * freq * 1.1 - tt * spd * 0.7 + ph * 1.7) * 0.40;

    float amp = (0.1 + 0.02 * e) * env * uAmplitude;
    float y = w * amp;

    float d = abs(uv.y - y);
    float thick = (0.001 + 0.05 * e) * (0.35 + env) * uThickness;
    float g = thick / (d + thick * 0.45);
    g = g * g;

    float h = fi / float(uStrandCount) + uv.x * 0.30 + uTime * 0.04 + uHueShift;
    col += samplePalette(h) * g * env;
  }

  col *= 0.45 + 0.7 * e;
  col = 1.0 - exp(-col * uGlow);

  float gray = dot(col, vec3(0.2126, 0.7152, 0.0722));
  col = max(mix(vec3(gray), col, uSaturation), 0.0);

  float lum = max(max(col.r, col.g), col.b);
  float alpha = clamp(lum, 0.0, 1.0) * uOpacity;

  fragColor = vec4(col * uOpacity, alpha);
}
`;

function parseColors(colors?: string[]): [number, number, number][] {
  const list = colors && colors.length > 0 ? colors : ['#FF4500', '#F97316', '#EAB308'];
  const palette: [number, number, number][] = [];
  for (let i = 0; i < MAX_COLORS; i++) {
    const hex = list[i % list.length];
    const c = new Color(hex);
    palette.push([c.r, c.g, c.b]);
  }
  return palette;
}

export interface StrandsProps {
  colors?: string[];
  count?: number;
  speed?: number;
  amplitude?: number;
  waviness?: number;
  thickness?: number;
  glow?: number;
  taper?: number;
  spread?: number;
  hueShift?: number;
  intensity?: number;
  saturation?: number;
  opacity?: number;
  scale?: number;
  glass?: boolean;
  refraction?: number;
  dispersion?: number;
  glassSize?: number;
  className?: string;
  style?: React.CSSProperties;
}

export default function Strands({
  colors = ['#FF4500', '#F97316', '#EAB308', '#F59E0B', '#FF8C00'],
  count = 3,
  speed = 0.45,
  amplitude = 0.65,
  waviness = 0.9,
  thickness = 0.95,
  glow = 2.2,
  taper = 3.0,
  spread = 0.95,
  hueShift = 0,
  intensity = 0.8,
  saturation = 1.6,
  opacity = 0.95,
  scale = 1.35,
  className = '',
  style,
}: StrandsProps) {
  const ctnDom = useRef<HTMLDivElement | null>(null);

  useEffect(() => {
    const ctn = ctnDom.current;
    if (!ctn) return;

    // High performance DPR clamp for silky 60-120fps on mobile
    const dpr = Math.min(typeof window !== 'undefined' ? window.devicePixelRatio || 1 : 1, 1.25);

    let renderer: Renderer | null = null;
    let gl: any = null;

    try {
      renderer = new Renderer({
        dpr,
        alpha: true,
        premultipliedAlpha: true,
        antialias: false,
        powerPreference: 'high-performance',
      });
      gl = renderer.gl;
      gl.clearColor(0, 0, 0, 0);
      gl.enable(gl.BLEND);
      gl.blendFunc(gl.ONE, gl.ONE_MINUS_SRC_ALPHA);
    } catch {
      return;
    }

    const geometry = new Triangle(gl);
    if ((geometry.attributes as { uv?: unknown }).uv) {
      delete (geometry.attributes as { uv?: unknown }).uv;
    }

    const palette = parseColors(colors);

    const program = new Program(gl, {
      vertex: VERT,
      fragment: FRAG,
      uniforms: {
        uTime: { value: 0 },
        uResolution: { value: [ctn.offsetWidth || window.innerWidth, ctn.offsetHeight || window.innerHeight] },
        uColors: { value: palette },
        uColorCount: { value: Math.min(colors.length, MAX_COLORS) },
        uStrandCount: { value: Math.min(count, MAX_STRANDS) },
        uSpeed: { value: speed },
        uAmplitude: { value: amplitude },
        uWaviness: { value: waviness },
        uThickness: { value: thickness },
        uGlow: { value: glow },
        uTaper: { value: taper },
        uSpread: { value: spread },
        uHueShift: { value: hueShift },
        uIntensity: { value: intensity },
        uOpacity: { value: opacity },
        uScale: { value: scale },
        uSaturation: { value: saturation },
      },
    });

    const mesh = new Mesh(gl, { geometry, program });
    ctn.appendChild(gl.canvas);

    let resizeRaf = 0;
    const resize = () => {
      if (!ctn || !renderer) return;
      if (resizeRaf) cancelAnimationFrame(resizeRaf);
      resizeRaf = requestAnimationFrame(() => {
        if (!ctn || !renderer) return;
        const w = ctn.offsetWidth || window.innerWidth;
        const h = ctn.offsetHeight || window.innerHeight;
        renderer.setSize(w, h);
        if (program?.uniforms?.uResolution?.value) {
          program.uniforms.uResolution.value = [w * dpr, h * dpr];
        }
      });
    };

    const ro = new ResizeObserver(resize);
    ro.observe(ctn);
    resize();

    let animateId = 0;
    let isVisible = true;
    let isIntersecting = true;

    const onVisibilityChange = () => {
      isVisible = document.visibilityState === 'visible';
    };
    document.addEventListener('visibilitychange', onVisibilityChange);

    const io = new IntersectionObserver(([entry]) => {
      isIntersecting = entry.isIntersecting;
    }, { threshold: 0.05 });
    io.observe(ctn);

    let lastTime = 0;
    const targetInterval = 1000 / 60; // 60 FPS target for mobile efficiency

    const update = (t: number) => {
      animateId = requestAnimationFrame(update);
      if (!isVisible || !isIntersecting || !renderer) return;

      // Throttle excessively fast loops on 144Hz displays to save mobile battery
      const delta = t - lastTime;
      if (delta < targetInterval * 0.9) return;
      lastTime = t;

      program.uniforms.uTime.value = t * 0.001;
      renderer.render({ scene: mesh });
    };

    animateId = requestAnimationFrame(update);

    return () => {
      cancelAnimationFrame(animateId);
      if (resizeRaf) cancelAnimationFrame(resizeRaf);
      ro.disconnect();
      io.disconnect();
      document.removeEventListener('visibilitychange', onVisibilityChange);
      if (ctn && gl?.canvas?.parentNode === ctn) {
        ctn.removeChild(gl.canvas);
      }
      gl?.getExtension('WEBGL_lose_context')?.loseContext();
    };
  }, [colors, count, speed, amplitude, waviness, thickness, glow, taper, spread, hueShift, intensity, saturation, opacity, scale]);

  return <div ref={ctnDom} className={`strands-container ${className} transform-gpu will-change-transform`} style={style} />;
}
