import React, { useState, useMemo, memo } from 'react';
import {
  Users,
  UserPlus,
  ArrowLeft,
  ChevronRight,
  Shield,
  Activity,
  History,
  Trash2,
  Calendar,
  Clock,
  Radio,
  CheckCircle2,
  AlertTriangle,
  X,
  Sparkles,
  Smile,
  Bell,
  Sliders,
  Settings,
  UserCheck,
  Thermometer,
  Droplets,
  Eye,
  ScanLine,
} from 'lucide-react';
import { ExposureScanRecord, ShiftType, WorkerProfile } from '../types';
import { ImageAnalysisOverlay } from './ImageAnalysisOverlay';

interface WorkerProfilesViewProps {
  workers: WorkerProfile[];
  scans: ExposureScanRecord[];
  onAddWorker: (worker: WorkerProfile) => void;
  onUpdateWorker: (worker: WorkerProfile) => void;
  onDeleteWorker: (id: string) => void;
  onBack?: () => void;
  envTemp?: number;
  envHumidity?: number;
  onOpenScan?: (workerId?: string) => void;
}

export const WorkerProfilesView: React.FC<WorkerProfilesViewProps> = memo(({
  workers,
  scans,
  onAddWorker,
  onUpdateWorker,
  onDeleteWorker,
  onBack,
  envTemp = 28,
  envHumidity = 55,
  onOpenScan,
}) => {
  const [isAddModalOpen, setIsAddModalOpen] = useState(false);
  const [selectedWorker, setSelectedWorker] = useState<WorkerProfile | null>(workers[0] || null);
  const [statusNote, setStatusNote] = useState('');
  const [workerToDelete, setWorkerToDelete] = useState<WorkerProfile | null>(null);
  const [selectedScanForDetails, setSelectedScanForDetails] = useState<ExposureScanRecord | null>(null);

  // New Worker Form State
  const [newId, setNewId] = useState('');
  const [newName, setNewName] = useState('');
  const [newDept, setNewDept] = useState('');
  const [newRole, setNewRole] = useState('');
  const [newShift, setNewShift] = useState<ShiftType>('Morning');
  const [newBadgeId, setNewBadgeId] = useState('');

  const handleCreateWorker = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newId || !newName) return;

    const newWorker: WorkerProfile = {
      id: newId.toUpperCase().trim(),
      name: newName.trim(),
      department: newDept.trim() || 'Operations',
      role: newRole.trim() || 'Field Operator',
      shift: newShift,
      assignedBadgeId: newBadgeId.trim() || `BDG-2026-${Math.floor(100 + Math.random() * 900)}`,
      badgeActivationDate: new Date().toISOString().slice(0, 10),
      shelfLifeDays: 365,
      totalScans: 0,
      cumulativeExposurePpmH: 0,
      status: 'ACTIVE',
    };

    onAddWorker(newWorker);
    setSelectedWorker(newWorker);
    setIsAddModalOpen(false);
    setNewId('');
    setNewName('');
    setNewDept('');
    setNewRole('');
    setNewBadgeId('');
  };

  const activeWorker = selectedWorker || workers[0];

  const workerScans = useMemo(() => {
    if (!activeWorker) return [];
    return scans
      .filter((s) => s.workerId === activeWorker.id)
      .sort((a, b) => new Date(b.timestamp).getTime() - new Date(a.timestamp).getTime());
  }, [scans, activeWorker]);

  return (
    <div className="space-y-4 max-w-xl mx-auto pb-24">
      {/* 1. Top Header (Matching Right Phone "< You" from Reference Image) */}
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-2.5">
          {onBack && (
            <button
              onClick={onBack}
              className="w-9 h-9 rounded-full bg-white/70 hover:bg-white border border-white/90 text-slate-800 flex items-center justify-center shadow-xs active:scale-95 transition-all cursor-pointer"
              title="Back"
            >
              <ArrowLeft className="w-4 h-4 text-slate-800" />
            </button>
          )}
          <h2 className="text-xl sm:text-2xl font-black text-slate-900 tracking-tight">
            Worker Directory
          </h2>
        </div>

        <button
          onClick={() => setIsAddModalOpen(true)}
          type="button"
          className="px-3.5 py-2 rounded-full bg-black text-white font-bold text-xs flex items-center gap-1.5 shadow-sm active:scale-95 transition-all cursor-pointer"
        >
          <UserPlus className="w-3.5 h-3.5 text-white" />
          <span>Add Worker</span>
        </button>
      </div>

      {/* 2. Worker Quick Selector Pills if multiple */}
      {workers.length > 1 && (
        <div className="flex items-center gap-2 overflow-x-auto no-scrollbar py-1">
          {workers.map((w) => {
            const isSelected = activeWorker?.id === w.id;
            return (
              <button
                key={w.id}
                onClick={() => setSelectedWorker(w)}
                type="button"
                className={`flex items-center gap-2 px-3.5 py-2 rounded-full text-xs font-bold transition-all shrink-0 cursor-pointer ${
                  isSelected
                    ? 'bg-black text-white shadow-sm'
                    : 'bg-white/60 hover:bg-white text-slate-700 border border-white/80'
                }`}
              >
                <div className={`w-5 h-5 rounded-full flex items-center justify-center text-[10px] font-black ${isSelected ? 'bg-white/20 text-white' : 'bg-slate-200 text-slate-700'}`}>
                  {w.name.split(' ').map((n) => n[0]).join('')}
                </div>
                <span>{w.name}</span>
              </button>
            );
          })}
        </div>
      )}

      {/* 3. Right Phone Profile Screen View */}
      {activeWorker && (
        <div className="space-y-4">
          {/* Top Profile Card: Avatar + Name + Translucent Input Pill */}
          <div className="pt-2 pb-1 text-center space-y-3">
            <div className="relative inline-block">
              <div className="w-20 h-20 rounded-full bg-gradient-to-br from-purple-200 to-amber-200 border-4 border-white shadow-md flex items-center justify-center font-black text-2xl text-slate-800 mx-auto">
                {activeWorker.name.split(' ').map((n) => n[0]).join('')}
              </div>
              <span className="absolute bottom-1 right-1 w-4 h-4 rounded-full bg-emerald-500 border-2 border-white" />
            </div>

            <div>
              <h3 className="text-xl font-black text-slate-900 tracking-tight leading-tight">
                {activeWorker.name}
              </h3>
              <p className="text-xs font-semibold text-slate-500 mt-0.5">
                Active • {activeWorker.role} ({activeWorker.department})
              </p>
            </div>

            {/* Translucent Frosted Input: "Update your status" (Matching Reference) */}
            <div className="flex items-center gap-2.5 px-4 py-2.5 rounded-full bg-white/50 backdrop-blur-xl border border-white/80 shadow-xs focus-within:bg-white/80 transition-all max-w-sm mx-auto">
              <Smile className="w-4 h-4 text-slate-400 shrink-0" />
              <input
                type="text"
                value={statusNote}
                onChange={(e) => setStatusNote(e.target.value)}
                placeholder="Update safety status & notes..."
                className="w-full bg-transparent text-xs text-slate-900 placeholder-slate-500 font-medium focus:outline-none"
              />
            </div>
          </div>

          {/* Section: "General" (Crisp White Card with Chevrons) */}
          <div className="space-y-1.5">
            <h4 className="text-xs font-black text-slate-800 uppercase tracking-wider px-2">
              General
            </h4>
            <div className="bg-white rounded-[28px] p-2 shadow-[0_4px_24px_rgba(0,0,0,0.03)] border border-white/80 divide-y divide-slate-100">
              <div className="flex items-center justify-between p-3 hover:bg-slate-50 rounded-2xl transition-colors cursor-pointer">
                <div className="flex items-center gap-3">
                  <div className="w-9 h-9 rounded-full bg-slate-100 flex items-center justify-center text-slate-700">
                    <Radio className="w-4 h-4" />
                  </div>
                  <div>
                    <h5 className="text-xs font-bold text-slate-900">Assigned Dosimeter</h5>
                    <p className="text-[11px] text-slate-500 font-mono">{activeWorker.assignedBadgeId}</p>
                  </div>
                </div>
                <div className="flex items-center gap-2">
                  <span className="text-[11px] font-extrabold text-emerald-700 bg-emerald-50 px-2 py-0.5 rounded-full">Active</span>
                  <ChevronRight className="w-4 h-4 text-slate-300" />
                </div>
              </div>

              <div className="flex items-center justify-between p-3 hover:bg-slate-50 rounded-2xl transition-colors cursor-pointer">
                <div className="flex items-center gap-3">
                  <div className="w-9 h-9 rounded-full bg-slate-100 flex items-center justify-center text-slate-700">
                    <Clock className="w-4 h-4" />
                  </div>
                  <div>
                    <h5 className="text-xs font-bold text-slate-900">Shift Schedule</h5>
                    <p className="text-[11px] text-slate-500">{activeWorker.shift} Shift (8h Duration)</p>
                  </div>
                </div>
                <div className="flex items-center gap-2">
                  <span className="text-[11px] font-bold text-slate-500">10 ppm Limit</span>
                  <ChevronRight className="w-4 h-4 text-slate-300" />
                </div>
              </div>
            </div>
          </div>

          {/* Section: "Telemetry & Dose" */}
          <div className="space-y-1.5">
            <h4 className="text-xs font-black text-slate-800 uppercase tracking-wider px-2">
              Telemetry & Exposure
            </h4>
            <div className="bg-white rounded-[28px] p-2 shadow-[0_4px_24px_rgba(0,0,0,0.03)] border border-white/80 divide-y divide-slate-100">
              <div className="flex items-center justify-between p-3 hover:bg-slate-50 rounded-2xl transition-colors cursor-pointer">
                <div className="flex items-center gap-3">
                  <div className="w-9 h-9 rounded-full bg-slate-100 flex items-center justify-center text-slate-700">
                    <Activity className="w-4 h-4" />
                  </div>
                  <div>
                    <h5 className="text-xs font-bold text-slate-900">Cumulative Exposure</h5>
                    <p className="text-[11px] text-slate-500">Total logged across all shifts</p>
                  </div>
                </div>
                <div className="flex items-center gap-2">
                  <span className="text-xs font-black font-mono text-slate-900">
                    {activeWorker.cumulativeExposurePpmH.toFixed(1)} ppm·h
                  </span>
                  <ChevronRight className="w-4 h-4 text-slate-300" />
                </div>
              </div>

              <div className="flex items-center justify-between p-3 hover:bg-slate-50 rounded-2xl transition-colors cursor-pointer">
                <div className="flex items-center gap-3">
                  <div className="w-9 h-9 rounded-full bg-slate-100 flex items-center justify-center text-slate-700">
                    <Calendar className="w-4 h-4" />
                  </div>
                  <div>
                    <h5 className="text-xs font-bold text-slate-900">Badge Registered</h5>
                    <p className="text-[11px] text-slate-500">{activeWorker.badgeActivationDate}</p>
                  </div>
                </div>
                <ChevronRight className="w-4 h-4 text-slate-300" />
              </div>

              {/* Ambient Microclimate Logged */}
              {(() => {
                const latestScan = workerScans[0];
                const latestTemp = latestScan?.temperature ?? envTemp;
                const latestHumidity = latestScan?.humidity ?? envHumidity;
                return (
                  <div className="flex items-center justify-between p-3.5 hover:bg-slate-50/70 rounded-2xl transition-colors">
                    <div className="flex items-center gap-3">
                      <div className="w-9 h-9 rounded-xl bg-slate-100 flex items-center justify-center text-slate-700">
                        <Thermometer className="w-4 h-4 text-slate-700" />
                      </div>
                      <div>
                        <h5 className="text-xs font-bold text-slate-900">Ambient Atmospheric Baseline</h5>
                        <p className="text-[11px] text-slate-500">
                          {latestScan ? 'Last logged shift microclimate' : 'Facility continuous baseline'}
                        </p>
                      </div>
                    </div>
                    <div className="text-right">
                      <div className="text-xs font-black font-mono text-slate-900 tracking-tight">
                        {Number(latestTemp).toFixed(1)}°C <span className="text-slate-300 font-normal mx-0.5">/</span> {Number(latestHumidity).toFixed(1)}% RH
                      </div>
                      <span className="text-[10px] font-semibold text-slate-400 uppercase tracking-wider block">
                        Diffusion Compensated
                      </span>
                    </div>
                  </div>
                );
              })()}
            </div>
          </div>

          {/* Section: "Workers Log / Shift Exposure & Environmental Records" */}
          <div className="space-y-2">
            <div className="flex items-center justify-between px-2">
              <div>
                <h4 className="text-xs font-black text-slate-800 uppercase tracking-wider">
                  Workers Log
                </h4>
                <p className="text-[11px] text-slate-500 font-medium">
                  Shift exposure logs with calibrated temperature & humidity
                </p>
              </div>
              <span className="text-[11px] font-black font-mono px-2.5 py-0.5 rounded-full bg-black text-white shadow-2xs">
                {workerScans.length} {workerScans.length === 1 ? 'Scan' : 'Scans'}
              </span>
            </div>

            {workerScans.length === 0 ? (
              <div className="bg-white rounded-[32px] p-6 text-center shadow-[0_4px_24px_rgba(0,0,0,0.03)] border border-white/80 space-y-4">
                <div>
                  <h5 className="text-base font-black text-slate-900 tracking-tight">
                    No Exposure Logs Recorded
                  </h5>
                  <p className="text-xs text-slate-500 mt-0.5 max-w-sm mx-auto">
                    No colorimetric dosimeter badge scans logged for {activeWorker.name} on this shift.
                  </p>
                </div>

                {/* Precision Industrial Telemetry Hardware Panel (Clean White Theme) */}
                <div className="w-full max-w-sm mx-auto rounded-2xl bg-white text-slate-900 p-4 shadow-sm border border-slate-200/90 text-left">
                  <div className="flex items-center justify-between pb-2.5 border-b border-slate-100">
                    <div className="flex items-center gap-2">
                      <span className="relative flex h-2 w-2">
                        <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-emerald-400 opacity-75"></span>
                        <span className="relative inline-flex rounded-full h-2 w-2 bg-emerald-500"></span>
                      </span>
                      <span className="uppercase tracking-wider font-mono text-[11px] text-slate-900 font-bold">
                        Facility Telemetry
                      </span>
                    </div>
                    <span className="font-mono text-[10px] text-emerald-700 font-extrabold tracking-wider uppercase bg-emerald-50 px-2 py-0.5 rounded-md border border-emerald-200/80">
                      Active Baseline
                    </span>
                  </div>

                  <div className="grid grid-cols-2 gap-3 pt-3">
                    <div>
                      <span className="text-[10px] uppercase font-bold tracking-wider text-slate-600 flex items-center gap-1">
                        <Thermometer className="w-3.5 h-3.5 text-amber-600" />
                        Temperature
                      </span>
                      <div className="flex items-baseline gap-1 mt-1">
                        <span className="text-2xl font-black font-mono tracking-tight text-slate-950">
                          {Number(envTemp).toFixed(1)}
                        </span>
                        <span className="text-xs font-bold text-slate-600">°C</span>
                      </div>
                      <span className="text-[11px] text-slate-600 font-medium block mt-0.5">
                        Diffusion standard
                      </span>
                    </div>

                    <div className="border-l border-slate-200/80 pl-3">
                      <span className="text-[10px] uppercase font-bold tracking-wider text-slate-600 flex items-center gap-1">
                        <Droplets className="w-3.5 h-3.5 text-sky-600" />
                        Rel. Humidity
                      </span>
                      <div className="flex items-baseline gap-1 mt-1">
                        <span className="text-2xl font-black font-mono tracking-tight text-slate-950">
                          {Number(envHumidity).toFixed(1)}
                        </span>
                        <span className="text-xs font-bold text-slate-600">% RH</span>
                      </div>
                      <span className="text-[11px] text-slate-600 font-medium block mt-0.5">
                        Calibrated sensor
                      </span>
                    </div>
                  </div>
                </div>

                {onOpenScan && (
                  <div className="pt-1">
                    <button
                      type="button"
                      onClick={() => onOpenScan(activeWorker.id)}
                      className="w-full max-w-sm mx-auto py-3 px-4 rounded-2xl bg-black hover:bg-slate-900 text-white text-xs font-bold shadow-md active:scale-[0.98] transition-all cursor-pointer flex items-center justify-center gap-2"
                    >
                      <ScanLine className="w-4 h-4 text-white" />
                      <span>Record Exposure Scan for {activeWorker.name.split(' ')[0]}</span>
                    </button>
                  </div>
                )}
              </div>
            ) : (
              <div className="space-y-2.5">
                {workerScans.map((scan) => {
                  const isHigh = scan.riskLevel === 'HIGH';
                  const isModerate = scan.riskLevel === 'MODERATE';
                  const scanDate = new Date(scan.timestamp).toLocaleDateString('en-GB', {
                    day: '2-digit',
                    month: 'short',
                    year: 'numeric',
                  });
                  const scanTime = new Date(scan.timestamp).toLocaleTimeString([], {
                    hour: '2-digit',
                    minute: '2-digit',
                  });

                  return (
                    <div
                      key={scan.id}
                      onClick={() => setSelectedScanForDetails(scan)}
                      className="bg-white rounded-[24px] p-4 shadow-[0_4px_20px_rgba(0,0,0,0.03)] border border-slate-100/90 hover:border-slate-300 transition-all cursor-pointer group"
                    >
                      {/* Top row: Shift, Time, and Risk Badge */}
                      <div className="flex items-center justify-between gap-2 pb-2.5 border-b border-slate-100">
                        <div className="flex items-center gap-2">
                          <span className="text-xs font-bold text-slate-900">
                            {scanDate} • {scanTime}
                          </span>
                          <span className="text-[10px] text-slate-600 font-medium bg-slate-100 px-2 py-0.5 rounded-md">
                            {scan.shift} Shift
                          </span>
                        </div>

                        <span className={`px-2.5 py-0.5 rounded-full text-[10px] font-black uppercase tracking-wider ${
                          isHigh
                            ? 'bg-rose-100 text-rose-800 border border-rose-200'
                            : isModerate
                            ? 'bg-amber-100 text-amber-900 border border-amber-200'
                            : 'bg-emerald-100 text-emerald-900 border border-emerald-200'
                        }`}>
                          {isHigh ? 'High Risk' : isModerate ? 'Moderate' : 'Safe'}
                        </span>
                      </div>

                      {/* Dose & Environmental Readout (Temperature & Humidity) */}
                      <div className="flex items-center justify-between gap-3 pt-3">
                        <div>
                          <span className="text-[10px] uppercase font-bold text-slate-400 block">
                            Cumulative Dose
                          </span>
                          <div className="flex items-baseline gap-1 mt-0.5">
                            <span className="text-xl font-black font-mono text-slate-950">
                              {scan.estimatedDose}
                            </span>
                            <span className="text-xs font-bold font-mono text-orange-600">
                              ppm·h
                            </span>
                          </div>
                        </div>

                        {/* Precision Environmental Readout */}
                        <div className="flex items-center gap-2">
                          <div className="flex items-center gap-2.5 bg-slate-50/90 px-3 py-1.5 rounded-xl border border-slate-200/80 font-mono text-xs shadow-2xs">
                            <span className="flex items-center gap-1 font-bold text-slate-900">
                              <Thermometer className="w-3.5 h-3.5 text-amber-600" />
                              {Number(scan.temperature ?? 28).toFixed(1)}°C
                            </span>
                            <span className="text-slate-300">·</span>
                            <span className="flex items-center gap-1 font-bold text-slate-900">
                              <Droplets className="w-3.5 h-3.5 text-sky-600" />
                              {Number(scan.humidity ?? 55).toFixed(1)}%
                            </span>
                          </div>

                          <div className="w-8 h-8 rounded-full bg-slate-100 group-hover:bg-black group-hover:text-white flex items-center justify-center text-slate-600 transition-colors ml-1 shrink-0 shadow-2xs">
                            <Eye className="w-3.5 h-3.5" />
                          </div>
                        </div>
                      </div>

                      {scan.notes && (
                        <p className="text-[11px] text-slate-500 font-medium mt-2 pt-2 border-t border-slate-50 truncate">
                          {scan.notes}
                        </p>
                      )}
                    </div>
                  );
                })}
              </div>
            )}
          </div>

          {/* Red Action Link (Matching "Log Out" in Reference Image) */}
          <div className="pt-2 text-center">
            <button
              onClick={() => setWorkerToDelete(activeWorker)}
              type="button"
              className="text-xs font-black text-rose-600 hover:text-rose-700 transition-colors cursor-pointer"
            >
              Archive / Remove Worker
            </button>
          </div>
        </div>
      )}

      {/* Add Worker Modal */}
      {isAddModalOpen && (
        <div className="fixed inset-0 z-50 bg-slate-900/60 backdrop-blur-xs p-4 flex justify-center items-center">
          <div className="bg-white rounded-[32px] max-w-sm w-full p-5 space-y-4 shadow-2xl border border-slate-100">
            <div className="flex items-center justify-between">
              <h4 className="text-base font-black text-slate-900">Add Worker Profile</h4>
              <button
                onClick={() => setIsAddModalOpen(false)}
                className="w-7 h-7 rounded-full bg-slate-100 flex items-center justify-center"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <form onSubmit={handleCreateWorker} className="space-y-3">
              <div>
                <label className="text-[11px] font-bold text-slate-500 block mb-1">Worker ID</label>
                <input
                  type="text"
                  required
                  placeholder="e.g. W-042"
                  value={newId}
                  onChange={(e) => setNewId(e.target.value)}
                  className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs font-medium focus:outline-none focus:border-black"
                />
              </div>

              <div>
                <label className="text-[11px] font-bold text-slate-500 block mb-1">Full Name</label>
                <input
                  type="text"
                  required
                  placeholder="e.g. Marcus Vance"
                  value={newName}
                  onChange={(e) => setNewName(e.target.value)}
                  className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs font-medium focus:outline-none focus:border-black"
                />
              </div>

              <div>
                <label className="text-[11px] font-bold text-slate-500 block mb-1">Department</label>
                <input
                  type="text"
                  placeholder="e.g. Refining Operations"
                  value={newDept}
                  onChange={(e) => setNewDept(e.target.value)}
                  className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs font-medium focus:outline-none focus:border-black"
                />
              </div>

              <div className="grid grid-cols-2 gap-2">
                <div>
                  <label className="text-[11px] font-bold text-slate-500 block mb-1">Shift</label>
                  <select
                    value={newShift}
                    onChange={(e) => setNewShift(e.target.value as ShiftType)}
                    className="w-full px-2 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs font-medium"
                  >
                    <option value="Morning">Morning</option>
                    <option value="Afternoon">Afternoon</option>
                    <option value="Night">Night</option>
                  </select>
                </div>
                <div>
                  <label className="text-[11px] font-bold text-slate-500 block mb-1">Badge ID</label>
                  <input
                    type="text"
                    placeholder="BDG-2026-X"
                    value={newBadgeId}
                    onChange={(e) => setNewBadgeId(e.target.value)}
                    className="w-full px-2 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs font-medium"
                  />
                </div>
              </div>

              <button
                type="submit"
                className="w-full py-3 bg-black text-white font-bold rounded-2xl text-xs hover:bg-slate-900 transition-colors shadow-sm mt-2 cursor-pointer"
              >
                Create Worker
              </button>
            </form>
          </div>
        </div>
      )}

      {/* Delete Confirmation */}
      {workerToDelete && (
        <div className="fixed inset-0 z-50 bg-slate-900/60 backdrop-blur-xs p-4 flex justify-center items-center">
          <div className="bg-white rounded-[32px] max-w-sm w-full p-5 space-y-3 shadow-2xl border border-slate-100">
            <h4 className="text-base font-black text-slate-900">Archive Worker?</h4>
            <p className="text-xs text-slate-600">
              Are you sure you want to remove <strong className="text-slate-900">{workerToDelete.name}</strong> from active monitoring?
            </p>
            <div className="flex gap-2 pt-2">
              <button
                type="button"
                onClick={() => setWorkerToDelete(null)}
                className="flex-1 py-2.5 rounded-full bg-slate-100 text-slate-700 font-bold text-xs"
              >
                Cancel
              </button>
              <button
                type="button"
                onClick={() => {
                  onDeleteWorker(workerToDelete.id);
                  setWorkerToDelete(null);
                  setSelectedWorker(workers[0] || null);
                }}
                className="flex-1 py-2.5 rounded-full bg-rose-600 text-white font-bold text-xs hover:bg-rose-700 shadow-sm"
              >
                Confirm
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Modal: Full Analysis Details for Worker's Scan */}
      {selectedScanForDetails && (
        <div className="fixed inset-0 z-50 bg-slate-900/60 backdrop-blur-xs overflow-y-auto p-3 sm:p-6 flex justify-center items-center">
          <div className="bg-white rounded-[32px] max-w-lg w-full p-5 sm:p-6 space-y-4 shadow-2xl border border-slate-100 animate-in fade-in zoom-in duration-150">
            <div className="flex items-center justify-between">
              <div>
                <h3 className="text-lg font-black text-slate-900">
                  Dosimeter Optical Report
                </h3>
                <p className="text-xs text-slate-500 font-medium">
                  {selectedScanForDetails.workerName} • ID {selectedScanForDetails.workerId}
                </p>
              </div>
              <button
                onClick={() => setSelectedScanForDetails(null)}
                className="w-8 h-8 rounded-full bg-slate-100 hover:bg-slate-200 text-slate-700 flex items-center justify-center transition-colors cursor-pointer"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            {selectedScanForDetails.imageDataUrl && (
              <div className="aspect-[4/3] rounded-2xl overflow-hidden bg-slate-950 border border-slate-200 flex items-center justify-center max-h-52 mx-auto">
                <img
                  src={selectedScanForDetails.imageDataUrl}
                  alt="Captured dosimeter"
                  className="w-full h-full object-contain"
                />
              </div>
            )}

            <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 text-xs">
              <div className="bg-slate-50 p-2.5 rounded-2xl border border-slate-100">
                <span className="text-[10px] text-slate-400 font-bold uppercase block">Dose</span>
                <span className="text-sm font-black text-slate-900 font-mono">{selectedScanForDetails.estimatedDose} ppm·h</span>
              </div>
              <div className="bg-slate-50 p-2.5 rounded-2xl border border-slate-100">
                <span className="text-[10px] text-slate-400 font-bold uppercase block">Risk</span>
                <span className="text-sm font-black text-slate-900 uppercase">{selectedScanForDetails.riskLevel}</span>
              </div>
              <div className="bg-amber-50/80 p-2.5 rounded-2xl border border-amber-100">
                <span className="text-[10px] text-amber-700 font-bold uppercase flex items-center gap-1">
                  <Thermometer className="w-3 h-3 text-amber-600" />
                  Temp
                </span>
                <span className="text-sm font-black text-amber-950 font-mono">{selectedScanForDetails.temperature ?? 28}°C</span>
              </div>
              <div className="bg-sky-50/80 p-2.5 rounded-2xl border border-sky-100">
                <span className="text-[10px] text-sky-700 font-bold uppercase flex items-center gap-1">
                  <Droplets className="w-3 h-3 text-sky-600" />
                  Humidity
                </span>
                <span className="text-sm font-black text-sky-950 font-mono">{selectedScanForDetails.humidity ?? 55}% RH</span>
              </div>
            </div>

            {selectedScanForDetails.analysisDetails && (
              <ImageAnalysisOverlay analysis={selectedScanForDetails.analysisDetails} />
            )}

            <button
              onClick={() => setSelectedScanForDetails(null)}
              className="w-full py-3 bg-black text-white font-bold rounded-2xl text-xs hover:bg-slate-900 transition-colors cursor-pointer"
            >
              Done
            </button>
          </div>
        </div>
      )}
    </div>
  );
});
