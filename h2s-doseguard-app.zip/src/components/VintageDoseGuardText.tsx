import React, { useState } from 'react';

export type FontVariant = 'industrial' | 'cyber' | 'modern';

interface VintageDoseGuardTextProps {
  className?: string;
  size?: 'sm' | 'md' | 'lg' | 'xl' | 'responsive';
  initialVariant?: FontVariant;
}

export const VintageDoseGuardText: React.FC<VintageDoseGuardTextProps> = ({
  className = '',
  size = 'responsive',
  initialVariant = 'industrial',
}) => {
  const [variant, setVariant] = useState<FontVariant>(initialVariant);

  const sizeClasses = {
    sm: 'w-56 h-18',
    md: 'w-72 h-24',
    lg: 'w-[420px] h-32',
    xl: 'w-[520px] h-40',
    responsive: 'w-full max-w-xl h-28 sm:h-36 md:h-44',
  }[size];

  // Font family mappings
  const fontFamilies = {
    industrial: "'Montserrat', 'Plus Jakarta Sans', -apple-system, sans-serif",
    cyber: "'Chakra Petch', 'Outfit', sans-serif",
    modern: "'Outfit', 'Plus Jakarta Sans', sans-serif",
  };

  return (
    <div className="flex flex-col items-center justify-center w-full">
      <div
        className={`relative inline-block select-none overflow-visible flex items-center justify-center ${sizeClasses} ${className}`}
        role="img"
        aria-label="Sulfex Bold 3D Industrial Typography"
      >
        <svg
          viewBox="0 0 490 180"
          className="w-full h-full overflow-visible drop-shadow-[0_16px_36px_rgba(0,0,0,0.3)]"
          xmlns="http://www.w3.org/2000/svg"
        >
          <defs>
            {/* Safety Orange Vibrant Face Gradient */}
            <linearGradient id="dg-guard-orange" x1="0%" y1="0%" x2="0%" y2="100%">
              <stop offset="0%" stopColor="#ffedd5" />
              <stop offset="25%" stopColor="#fb923c" />
              <stop offset="70%" stopColor="#f97316" />
              <stop offset="100%" stopColor="#c2410c" />
            </linearGradient>

            {/* Dose Crisp White/Silver Metallic Gradient */}
            <linearGradient id="dg-dose-white" x1="0%" y1="0%" x2="0%" y2="100%">
              <stop offset="0%" stopColor="#ffffff" />
              <stop offset="35%" stopColor="#f8fafc" />
              <stop offset="75%" stopColor="#e2e8f0" />
              <stop offset="100%" stopColor="#cbd5e1" />
            </linearGradient>

            {/* Swash Orange Glow Gradient */}
            <linearGradient id="dg-swash-grad" x1="0%" y1="0%" x2="100%" y2="0%">
              <stop offset="0%" stopColor="#ffffff" />
              <stop offset="30%" stopColor="#fb923c" />
              <stop offset="70%" stopColor="#ea580c" />
              <stop offset="100%" stopColor="#9a3412" />
            </linearGradient>

            {/* Bevel 3D Lighting Filter */}
            <filter id="dg-shadow-glow" x="-20%" y="-20%" width="140%" height="140%">
              <feDropShadow dx="0" dy="12" stdDeviation="14" floodColor="#f97316" floodOpacity="0.25" />
            </filter>
          </defs>

          <g transform="translate(18, 16)" filter="url(#dg-shadow-glow)">
            {/* ======================================================== */}
            {/* LAYER 1: 3D SOLID BLACK EXTRUSION DEPTH (ISOMETRIC DROP) */}
            {/* ======================================================== */}
            <g
              fontFamily={fontFamilies[variant]}
              fontSize="84"
              fontWeight="900"
              fontStyle={variant === 'industrial' ? 'italic' : 'normal'}
              letterSpacing={variant === 'cyber' ? '0.04em' : '-0.01em'}
            >
              {/* Deepest drop block 4 */}
              <text x="36" y="96" fill="#000000" stroke="#000000" strokeWidth="18" strokeLinejoin="miter">
                SULF<tspan fill="#000000" stroke="#000000">EX</tspan>
              </text>
              {/* Block 3 */}
              <text x="30" y="90" fill="#000000" stroke="#000000" strokeWidth="14" strokeLinejoin="miter">
                SULF<tspan fill="#000000" stroke="#000000">EX</tspan>
              </text>
              {/* Block 2 */}
              <text x="24" y="84" fill="#09090b" stroke="#09090b" strokeWidth="10" strokeLinejoin="miter">
                SULF<tspan fill="#09090b" stroke="#09090b">EX</tspan>
              </text>
              {/* Block 1: Dark Border */}
              <text x="18" y="78" fill="#18181b" stroke="#000000" strokeWidth="7" strokeLinejoin="miter">
                SULF<tspan fill="#18181b" stroke="#000000">EX</tspan>
              </text>

              {/* ======================================================== */}
              {/* LAYER 2: CRISP WHITE OUTLINE FRAME                       */}
              {/* ======================================================== */}
              <text x="18" y="78" fill="none" stroke="#ffffff" strokeWidth="6" strokeLinejoin="round">
                SULF<tspan stroke="#ffffff">EX</tspan>
              </text>

              {/* ======================================================== */}
              {/* LAYER 3: INNER BLACK KEYLINE DEFINITION                  */}
              {/* ======================================================== */}
              <text x="18" y="78" fill="none" stroke="#000000" strokeWidth="3" strokeLinejoin="round">
                SULF<tspan stroke="#000000">EX</tspan>
              </text>

              {/* ======================================================== */}
              {/* LAYER 4: FRONT FACE FILL (WHITE "SULF" + ORANGE "EX")    */}
              {/* ======================================================== */}
              <text x="18" y="78" fill="url(#dg-dose-white)">
                SULF
                <tspan fill="url(#dg-guard-orange)" dx="2">
                  EX
                </tspan>
              </text>

              {/* ======================================================== */}
              {/* LAYER 5: PRISTINE SPECULAR TOP HIGHLIGHT                 */}
              {/* ======================================================== */}
              <text
                x="18"
                y="77"
                fill="none"
                stroke="#ffffff"
                strokeWidth="1.2"
                strokeOpacity="0.8"
                className="pointer-events-none"
              >
                SULF
                <tspan stroke="#ffffff" strokeOpacity="0.9" dx="2">
                  EX
                </tspan>
              </text>
            </g>

            {/* ======================================================== */}
            {/* DYNAMIC INDUSTRIAL UNDERLINE ACCENT BAR (ORANGE & BLACK) */}
            {/* ======================================================== */}
            <g transform="translate(18, 98)">
              {/* 3D Black Base */}
              <path
                d="M 6 18 L 420 18 L 402 28 L 0 28 Z"
                fill="#000000"
                stroke="#000000"
                strokeWidth="5"
                strokeLinejoin="round"
              />
              <path
                d="M 4 10 L 418 10 L 410 18 L 0 18 Z"
                fill="#18181b"
                stroke="#000000"
                strokeWidth="2"
                strokeLinejoin="round"
              />
              {/* Crisp White Trim */}
              <path
                d="M 0 4 L 424 4 L 418 10 L 0 10 Z"
                fill="#ffffff"
                stroke="#000000"
                strokeWidth="1.5"
                strokeLinejoin="round"
              />
              {/* Top Face: Gradient Bar */}
              <path
                d="M 2 2 L 422 2 L 416 8 L 0 8 Z"
                fill="url(#dg-swash-grad)"
                stroke="#ea580c"
                strokeWidth="0.8"
              />
              {/* Mini Hazard Ticks on the bar */}
              <rect x="22" y="3" width="14" height="4" fill="#ffffff" opacity="0.9" />
              <rect x="44" y="3" width="14" height="4" fill="#ffffff" opacity="0.9" />
              <rect x="66" y="3" width="14" height="4" fill="#ffffff" opacity="0.9" />
            </g>
          </g>
        </svg>
      </div>

      {/* Font Style Quick-Selector Pill (Industrial, Cyber, Modern) */}
      <div className="mt-1 flex items-center gap-1 p-1 rounded-full bg-slate-100/80 border border-slate-200/90 shadow-2xs backdrop-blur-xs">
        <button
          id="font-select-industrial"
          type="button"
          onClick={() => setVariant('industrial')}
          className={`px-2.5 py-0.5 rounded-full text-[11px] font-bold tracking-tight transition-all cursor-pointer ${
            variant === 'industrial'
              ? 'bg-slate-900 text-white shadow-xs'
              : 'text-slate-600 hover:text-slate-950 hover:bg-white/70'
          }`}
        >
          Industrial 3D
        </button>
        <button
          id="font-select-cyber"
          type="button"
          onClick={() => setVariant('cyber')}
          className={`px-2.5 py-0.5 rounded-full text-[11px] font-bold tracking-tight transition-all cursor-pointer ${
            variant === 'cyber'
              ? 'bg-orange-600 text-white shadow-xs'
              : 'text-slate-600 hover:text-slate-950 hover:bg-white/70'
          }`}
        >
          Cyber Tech
        </button>
        <button
          id="font-select-modern"
          type="button"
          onClick={() => setVariant('modern')}
          className={`px-2.5 py-0.5 rounded-full text-[11px] font-bold tracking-tight transition-all cursor-pointer ${
            variant === 'modern'
              ? 'bg-slate-900 text-white shadow-xs'
              : 'text-slate-600 hover:text-slate-950 hover:bg-white/70'
          }`}
        >
          Bold Clean
        </button>
      </div>
    </div>
  );
};

export const SulfexVintage3DText = VintageDoseGuardText;
export default VintageDoseGuardText;
