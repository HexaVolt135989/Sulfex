import express from "express";
import path from "path";
import { createServer as createViteServer } from "vite";
import { GoogleGenAI } from "@google/genai";
import dotenv from "dotenv";

dotenv.config();

const PORT = 3000;

let aiClient: GoogleGenAI | null = null;
function getGeminiClient(): GoogleGenAI | null {
  if (!aiClient && process.env.GEMINI_API_KEY) {
    aiClient = new GoogleGenAI({
      apiKey: process.env.GEMINI_API_KEY,
      httpOptions: {
        headers: {
          "User-Agent": "aistudio-build",
        },
      },
    });
  }
  return aiClient;
}

async function startServer() {
  const app = express();

  // Increase payload limit for base64 wristband images
  app.use(express.json({ limit: "25mb" }));
  app.use(express.urlencoded({ extended: true, limit: "25mb" }));

  // Health check endpoint
  app.get("/api/health", (req, res) => {
    res.json({
      status: "ok",
      app: "H2S DoseGuard SIH26118 Server",
      timestamp: new Date().toISOString(),
      hasGeminiKey: !!process.env.GEMINI_API_KEY,
    });
  });

  // Optional Gemini Vision verification endpoint for passive colorimetric badges
  app.post("/api/gemini/analyze-badge", async (req, res) => {
    try {
      const { imageBase64, workerId, shift, temp, humidity } = req.body;

      if (!imageBase64) {
        return res.status(400).json({ error: "Missing imageBase64 in request body" });
      }

      const client = getGeminiClient();
      if (!client) {
        return res.status(503).json({
          error: "Gemini API key is not configured. Falling back to local Computer Vision engine.",
          fallbackToLocal: true,
        });
      }

      // Remove base64 header if present
      const cleanBase64 = imageBase64.replace(/^data:image\/(png|jpeg|jpg|webp);base64,/, "");

      const prompt = `You are an industrial colorimetric dosimeter analysis AI engine for problem statement SIH26118 (Passive H2S Dosimeter Wristband).
Analyze this photo of a passive colorimetric H2S exposure dosimeter wristband.
The badge layout consists of:
1. Chemical sensing strip (changes from yellow/white unexposed baseline to dark brown/black PbS lead sulfide precipitate based on cumulative H2S exposure in ppm·h).
2. Reference color scale (5 patches: White/Neutral, Cyan, Magenta, Yellow, Black).
3. Expiry indicator patch (Fresh = Green/Blue, Expired = Pink/Red).

Perform visual colorimetry evaluation:
- Detect presence and clarity of sensing strip, 5 reference patches, and expiry patch.
- Estimate color darkening index from 0.0 (pristine/unexposed) to 1.0 (fully saturated dark).
- Estimate cumulative H2S exposure in ppm·h based on a prototype calibration curve:
  * 0.0 index -> 0 ppm·h (Low Risk)
  * 0.2 index -> ~5.0 ppm·h (Low Risk)
  * 0.4 index -> ~12.5 ppm·h (Moderate Risk)
  * 0.6 index -> ~25.0 ppm·h (Moderate to High Risk)
  * 0.8 index -> ~45.0 ppm·h (High Risk)
  * 1.0 index -> ~75.0 ppm·h (High Risk)
- Assess image quality (GOOD, MODERATE, or POOR) based on focus, lighting, and glare.
- Check badge expiry patch status (VALID or EXPIRED).
- Calculate confidence score percentage (0-100%).

Worker ID: ${workerId || "Unknown"}
Shift: ${shift || "Morning"}
Ambient Temp: ${temp ?? "N/A"} °C, Humidity: ${humidity ?? "N/A"} %

IMPORTANT: Return ONLY a valid JSON object matching this schema:
{
  "colorIndex": number (between 0.0 and 1.0),
  "estimatedDose": number (in ppm·h),
  "riskLevel": "LOW" | "MODERATE" | "HIGH",
  "badgeValidity": "VALID" | "EXPIRED" | "NEAR_EXPIRY",
  "imageQuality": "GOOD" | "MODERATE" | "POOR",
  "confidence": number (integer 0-100),
  "detectedFeatures": {
    "stripDetected": boolean,
    "referenceScaleDetected": boolean,
    "expiryIndicatorDetected": boolean,
    "lightingCondition": "Good" | "Uneven" | "Too Dark" | "Glare"
  },
  "summaryNotes": string (brief industrial analysis observation),
  "disclaimer": "Prototype experimental estimate. Not a certified personal gas detector."
}`;

      let responseText = "{}";
      const candidateModels = ["gemini-2.5-flash", "gemini-2.5-flash-lite", "gemini-2.5-pro"];

      for (const model of candidateModels) {
        try {
          const response = await client.models.generateContent({
            model,
            contents: {
              parts: [
                {
                  inlineData: {
                    mimeType: "image/jpeg",
                    data: cleanBase64,
                  },
                },
                {
                  text: prompt,
                },
              ],
            },
            config: {
              responseMimeType: "application/json",
              temperature: 0.1,
            },
          });

          if (response && response.text) {
            responseText = response.text;
            break; // successfully generated
          }
        } catch {
          // Model busy, 503, or rate-limited; quietly try next model in candidate list
        }
      }

      if (!responseText || responseText === "{}") {
        return res.json({
          success: false,
          fallbackToLocal: true,
          message: "Local computer vision engine active.",
        });
      }

      let parsedData;
      try {
        parsedData = JSON.parse(responseText);
      } catch {
        return res.json({
          success: false,
          fallbackToLocal: true,
          error: "Failed to parse AI response JSON",
        });
      }

      res.json({
        success: true,
        data: parsedData,
        source: "GEMINI_VISION_AI",
      });
    } catch {
      res.json({
        success: false,
        fallbackToLocal: true,
      });
    }
  });

  // Vite middleware in dev, static files in production
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), "dist");
    app.use(express.static(distPath));
    app.get("*", (req, res) => {
      res.sendFile(path.join(distPath, "index.html"));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`H2S DoseGuard server running on http://0.0.0.0:${PORT}`);
  });
}

startServer();
